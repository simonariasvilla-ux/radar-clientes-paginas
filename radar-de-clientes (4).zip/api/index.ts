import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();

app.use(express.json({ limit: '20mb' }));

// Route to serve the downloadable project ZIP directly with proper headers and Content-Length
app.get(['/radar-de-clientes.zip', '/api/download-zip'], (_req: Request, res: Response) => {
  const zipPath = path.resolve(process.cwd(), 'public', 'radar-de-clientes.zip');
  if (fs.existsSync(zipPath)) {
    const stat = fs.statSync(zipPath);
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Length', stat.size);
    res.setHeader('Content-Disposition', 'attachment; filename="radar-de-clientes.zip"');
    res.sendFile(zipPath);
  } else {
    res.status(404).send('ZIP no encontrado');
  }
});

// Initialise Gemini with User-Agent telemetry
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Health check endpoint for testing Vercel API connectivity
app.get(['/api/health', '/health', '/api'], (_req: Request, res: Response) => {
  res.json({ status: 'ok', app: 'Radar de Clientes API', timestamp: new Date().toISOString() });
});

// Helper to extract Google Cloud API key
function getCloudApiKey(req: Request): string {
  const headerKey = req.headers['x-google-cloud-key'] as string | undefined;
  const bodyKey = req.body?.apiKey as string | undefined;
  const envKey = process.env.GOOGLE_CLOUD_API_KEY || process.env.VITE_GOOGLE_MAPS_API_KEY;
  return (headerKey || bodyKey || envKey || '').trim();
}

// 1. PLACES API (NEW) - Text Search
app.post(['/api/places/search', '/places/search'], async (req: Request, res: Response) => {
  try {
    const { textQuery, pageToken } = req.body;
    const apiKey = getCloudApiKey(req);

    if (!apiKey) {
      return res.status(400).json({
        error:
          'Falta la clave de Google Cloud API. Por favor, introdúcela en la sección de Ajustes para buscar negocios en Google Places.',
        code: 'MISSING_API_KEY',
      });
    }

    if (!textQuery || typeof textQuery !== 'string' || textQuery.trim() === '') {
      return res.status(400).json({
        error: 'El campo de búsqueda (zona y nicho) es obligatorio.',
        code: 'INVALID_QUERY',
      });
    }

    const url = 'https://places.googleapis.com/v1/places:searchText';

    const fieldMask = [
      'places.id',
      'places.displayName',
      'places.formattedAddress',
      'places.location',
      'places.nationalPhoneNumber',
      'places.internationalPhoneNumber',
      'places.websiteUri',
      'places.rating',
      'places.userRatingCount',
      'places.primaryTypeDisplayName',
      'places.types',
      'places.googleMapsUri',
      'places.businessStatus',
      'nextPageToken',
    ].join(',');

    const payload: Record<string, any> = {
      textQuery: textQuery.trim(),
      languageCode: 'es',
      regionCode: 'ES',
      pageSize: 20,
    };

    if (pageToken && typeof pageToken === 'string' && pageToken.trim() !== '') {
      payload.pageToken = pageToken.trim();
    }

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': apiKey,
        'X-Goog-FieldMask': fieldMask,
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json();

    if (!response.ok) {
      const errorMessage =
        data?.error?.message ||
        `Error de Places API (Código ${response.status}): ${response.statusText}`;
      return res.status(response.status).json({
        error: errorMessage,
        details: data?.error,
        code: 'PLACES_API_ERROR',
      });
    }

    res.json({
      places: data.places || [],
      nextPageToken: data.nextPageToken || null,
    });
  } catch (err: any) {
    console.error('Error en /api/places/search:', err);
    res.status(500).json({
      error: `Error al conectar con Google Places API: ${err.message || 'Error interno del servidor'}`,
      code: 'SERVER_ERROR',
    });
  }
});

// 2. PAGESPEED INSIGHTS V5
app.post(['/api/pagespeed/analyze', '/pagespeed/analyze'], async (req: Request, res: Response) => {
  try {
    const { url: targetUrl } = req.body;
    const apiKey = getCloudApiKey(req);

    if (!targetUrl || typeof targetUrl !== 'string') {
      return res.status(400).json({
        error: 'La URL a analizar es requerida.',
        code: 'INVALID_URL',
      });
    }

    let normalizedUrl = targetUrl.trim();
    if (!normalizedUrl.startsWith('http://') && !normalizedUrl.startsWith('https://')) {
      normalizedUrl = 'https://' + normalizedUrl;
    }

    const endpoint = new URL('https://www.googleapis.com/pagespeedonline/v5/runPagespeed');
    endpoint.searchParams.set('url', normalizedUrl);
    endpoint.searchParams.set('strategy', 'mobile');
    endpoint.searchParams.append('category', 'performance');
    endpoint.searchParams.append('category', 'seo');
    endpoint.searchParams.append('category', 'accessibility');
    endpoint.searchParams.append('category', 'best-practices');
    if (apiKey) {
      endpoint.searchParams.set('key', apiKey);
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 45000);

    const response = await fetch(endpoint.toString(), {
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    const data = await response.json();

    if (!response.ok) {
      const errorMessage =
        data?.error?.message || `Error en PageSpeed API (${response.status}): ${response.statusText}`;
      return res.status(response.status).json({
        error: errorMessage,
        code: 'PAGESPEED_ERROR',
      });
    }

    const lighthouse = data.lighthouseResult;
    const categories = lighthouse?.categories || {};

    const scores = {
      performance: Math.round((categories.performance?.score || 0) * 100),
      seo: Math.round((categories.seo?.score || 0) * 100),
      accessibility: Math.round((categories.accessibility?.score || 0) * 100),
      bestPractices: Math.round((categories['best-practices']?.score || 0) * 100),
    };

    const screenshotBase64 = lighthouse?.audits?.['final-screenshot']?.details?.data || null;

    res.json({
      success: true,
      testedUrl: normalizedUrl,
      scores,
      screenshotBase64,
      analyzedAt: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error('Error en /api/pagespeed/analyze:', err);
    res.status(500).json({
      error: `Error al ejecutar auditoría de PageSpeed: ${err.message || 'Tiempo de espera agotado o error de red'}`,
      code: 'SERVER_PAGESPEED_ERROR',
    });
  }
});

// 3. GEMINI: ANALIZAR NEGOCIO Y GENERAR BORRADORES
// 3. GEMINI: ANALIZAR NEGOCIO Y GENERAR BORRADORES (MÉTODO DEL MÉDICO - NINO MANZANO)
app.post(['/api/gemini/analyze-business', '/gemini/analyze-business'], async (req: Request, res: Response) => {
  try {
    const {
      businessName,
      category,
      address,
      phone,
      websiteUri,
      hasOwnWebsite,
      sellerProfile,
      pageSpeedScores,
      rating,
      reviewsCount,
    } = req.body;

    const sellerName = sellerProfile?.name || 'Simón';
    const agencyName = sellerProfile?.agencyName || 'Agencia de Servicios Digitales';
    const tone = sellerProfile?.defaultTone || 'consultivo';

    const systemPrompt = `Eres el mayor experto en prospección comercial de páginas web para negocios locales en España, aplicando con total rigurosidad la metodología del libro "Hoja de diagnóstico - El Método del Médico para vender páginas web a negocios locales" de Nino Manzano.

PRINCIPIOS CRÍTICOS DEL MÉTODO DEL MÉDICO QUE DEBES APLICAR SIN EXCEPCIÓN:
1. "Un médico no te ofrece pastillas nada más entrar. Primero te diagnostica, te explica qué tienes y qué te pasará si no haces nada, y entonces te receta."
2. "Da igual el canal: siempre dices lo que has visto, lo que le cuesta y una pregunta pequeña. NO dices que haces webs, NO das precios y NO enseñas nada tuyo en el primer contacto."
3. "En su idioma: clientes, llamadas y citas. Nada de diseño, nada de animaciones, nada de jerga técnica ni palabras como 'responsive', 'IA' o 'frameworks'."
4. "Un fallo no es un diagnóstico. 'No tiene botón de contacto' o 'tu web no es responsive' no le dice nada al dueño. Lo que le importa es lo que le cuesta en clientes y dinero perdido."
5. TRADUCCIÓN OBLIGATORIA DE CADA FALLO A DINERO:
   - Si no aparece en los primeros puestos: "Cuando alguien busca [servicio] en tu zona, le salen otros negocios antes que a vosotros. Esos clientes ni siquiera saben que existís."
   - Si la ficha está incompleta: "Quien os encuentra en Google no ve vuestro horario ni vuestras fotos, así que no sabe si estáis abiertos y llama al siguiente."
   - Si la ficha enlaza a Instagram: "Quien quiere ver precios o pedir cita aterriza en fotos y tiene que escribiros por privado. La gran mayoría no lo hace y se va."
   - Si no tiene web o es confusa: "En los primeros 5 segundos no queda claro qué ofrecéis ni dónde estáis, y quien no lo entiende rápido vuelve a Google."
   - Si la web es lenta (PageSpeed): "Vuestra web tarda X segundos en cargar en el móvil. Mucha gente no espera y llama a otro."
   - Si el botón de llamada no es pulsable / no hay WhatsApp: "Desde el móvil no hay forma rápida de llamaros con un solo toque, así que la mayoría se va sin pedir nada."
   - Si no hay cita fuera de horario: "Mucha gente busca por la noche desde el sofá. Si no puede reservar o pedir presupuesto en ese momento, se le olvida."
   - Si hay reseñas sin responder: "Tenéis X reseñas y ninguna respuesta. Quien os mira por primera vez piensa que no os importan vuestros clientes."

Debes responder ESTRICTAMENTE en formato JSON válido con la siguiente estructura:
{
  "businessSummary": "Resumen en 2 frases de la actividad y servicio local del negocio.",
  "checklist": {
    "hasHttps": boolean,
    "isMobileResponsive": boolean,
    "hasWhatsAppButton": boolean,
    "hasOnlineBooking": boolean,
    "hasContactForm": boolean,
    "isOutdated": boolean,
    "copyrightYear": "año detectado o estimado"
  },
  "medicalDiagnosis": {
    "symptoms": ["Síntoma 1 del PDF (ej: Más de 50 reseñas y sin web propia)", "Síntoma 2 (ej: Competencia de la zona mejor posicionada)"],
    "threeQuestions": {
      "findability": {
        "passed": boolean,
        "note": "¿Le encuentro? Posición en Google, ficha, fotos, horario y reseñas."
      },
      "understanding": {
        "passed": boolean,
        "note": "¿Le entiendo? Entra en su web y cuenta 5 segundos. Claridad y velocidad móvil."
      },
      "contactability": {
        "passed": boolean,
        "note": "¿Puedo contactarle? Botón pulsar para llamar, WhatsApp directo, reserva fuera de horario."
      }
    },
    "findingsWithCost": [
      {
        "finding": "Lo que has visto (fallo 1 visible y concreto)",
        "costInMoney": "Lo que le cuesta (traducido a clientes que se van a la competencia y dinero)"
      },
      {
        "finding": "Lo que has visto (fallo 2 visible y concreto)",
        "costInMoney": "Lo que le cuesta (traducido a clientes y dinero)"
      },
      {
        "finding": "Lo que has visto (fallo 3 visible y concreto)",
        "costInMoney": "Lo que le cuesta (traducido a clientes y dinero)"
      }
    ]
  },
  "extractedEmails": ["email@ejemplo.es"],
  "extractedSocials": ["https://instagram.com/..."],
  "painPoints": ["Fallo 1 traducido a coste", "Fallo 2 traducido a coste", "Fallo 3 traducido a coste"],
  "recommendedService": "web_moderna" | "agente_whatsapp" | "sistema_citas",
  "recommendedServiceReason": "Por qué cura exactamente el síntoma principal del negocio.",
  "salesDrafts": {
    "whatsAppMessage": "Mensaje EXACTO siguiendo el Método del Médico (Página 7 del PDF):\\nHola [nombre o responsable], soy ${sellerName}.\\n\\nHe buscado [servicio en tu zona] como lo haría un cliente, y salen [competidores/los tres primeros] antes que vosotros. Y en vuestra ficha [fallo concreto detectado traducido a fricción].\\n\\nEso son clientes que se van al siguiente sin llamaros.\\n\\n¿Te enseño en cinco minutos cómo se arregla?",
    "callScript30s": "Guion telefónico de 30 segundos del PDF (Página 7):\\nHola, ¿hablo con el responsable de [negocio]? Soy ${sellerName}, te llamo porque he visto una cosa en vuestra ficha de Google / web que os está haciendo perder clientes todos los días. ¿Tienes un minuto y te lo cuento?",
    "inPersonScript": "Guion presencial del PDF (Página 7):\\nHola, ¿eres el responsable de [negocio]? Soy ${sellerName}. Antes de venir he buscado [vuestro servicio] en Google como lo haría un cliente y he visto [fallo concreto]. Te lo enseño en el móvil, que son dos minutos.\\n(Lleva el móvil con la búsqueda ya abierta. Que lo vea él, no que te crea a ti).",
    "objectionNotInterested": "Respuesta a 'No me interesa' del PDF (Página 7):\\nPerfecto, gracias por decírmelo. Si en algún momento queréis verlo, aquí tenéis mi número guardado. ¡Que tengáis buena semana!",
    "prescription": {
      "diagnosticSummary": "Lo que hemos visto en vuestro negocio",
      "threeErrorsWithCost": [
        { "finding": "Fallo 1", "costInMoney": "Coste 1 en dinero/clientes" },
        { "finding": "Fallo 2", "costInMoney": "Coste 2 en dinero/clientes" },
        { "finding": "Fallo 3", "costInMoney": "Coste 3 en dinero/clientes" }
      ],
      "basicOption": {
        "title": "Opción básica (Arregla lo más urgente)",
        "description": "Solución a fallo 1 y fallo 2",
        "estimatedPrice": "390€"
      },
      "recommendedOption": {
        "title": "Opción recomendada (Arregla los tres fallos)",
        "description": "Solución integral a los tres fallos + Revisión mensual con informe de llamadas y visitas",
        "estimatedPrice": "690€",
        "monthlyFee": "49€/mes"
      },
      "theMathDone": {
        "avgTicketPerClient": 150,
        "extraClientsPerMonth": 2,
        "extraPerMonth": 300,
        "extraPerYear": 3600,
        "explanation": "La cuenta: si un cliente nuevo te deja 150€ y esto te trae solo 2 clientes más al mes, son 300€ al mes, 3.600€ al año."
      }
    },
    "emailPitch": {
      "subject": "Diagnóstico rápido: He buscado [servicio en la zona] y he visto un detalle en vuestra ficha",
      "body": "Cuerpo del email estructurado con el método del médico: lo que he visto, lo que os está costando y propuesta de enseñárselo en 5 minutos en el móvil."
    },
    "monthlyReviewMessage": "Hola [nombre], te paso el resumen de este mes 👇\\n[X] personas han entrado en la web, [X] te han llamado desde ella y [X] han pedido cita.\\nEste mes he optimizado la ficha y el botón de contacto. El mes que viene quiero añadir los nuevos testimonios."
  }
}`;

    const userPrompt = `Datos del negocio a prospectar con el Método del Médico:
- Nombre del negocio: ${businessName || 'Negocio Local'}
- Categoría / Actividad: ${category || 'Servicio local'}
- Dirección / Zona: ${address || 'España'}
- Teléfono: ${phone || 'No registrado'}
- Web: ${websiteUri || 'SIN PÁGINA WEB PROPIA'}
- Tiene web propia: ${hasOwnWebsite ? 'Sí' : 'No (o tiene red social como Instagram/Facebook o directorio)'}
- Valoración Google Maps: ${rating || 'Sin nota'} (${reviewsCount || 0} reseñas)
${pageSpeedScores ? `- PageSpeed Móvil real: Rendimiento ${pageSpeedScores.performance}/100, SEO ${pageSpeedScores.seo}/100, Accesibilidad ${pageSpeedScores.accessibility}/100, Buenas Prácticas ${pageSpeedScores.bestPractices}/100` : ''}

Datos del Vendedor:
- Nombre: ${sellerName}
- Agencia: ${agencyName}
- Tono: ${tone}

Analiza este negocio. Si tiene web accesible (${websiteUri}), utiliza urlContext para auditar su velocidad, botones móviles y contenido real. Si no tiene web o es un Instagram, enfócate en el dolor de que los clientes que buscan en Google se van a los 3 de arriba.
Devuelve el JSON estructurado solicitado.`;

    const config: Record<string, any> = {
      systemInstruction: systemPrompt,
      responseMimeType: 'application/json',
    };

    if (websiteUri && hasOwnWebsite && websiteUri.startsWith('http')) {
      config.tools = [{ urlContext: {} }];
    }

    let response;
    try {
      response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: userPrompt,
        config,
      });
    } catch (apiErr: any) {
      console.warn('Reintento de Gemini sin urlContext por error previo:', apiErr.message);
      response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `${userPrompt}\nNota adicional: Analiza en base a los datos suministrados y genera el JSON exacto.`,
        config: {
          systemInstruction: systemPrompt,
          responseMimeType: 'application/json',
        },
      });
    }

    const text = response.text || '{}';
    let parsedData: any;
    try {
      parsedData = JSON.parse(text);
    } catch {
      const cleanJson = text.replace(/```json/gi, '').replace(/```/g, '').trim();
      parsedData = JSON.parse(cleanJson);
    }

    res.json({
      success: true,
      audit: {
        analyzedAt: new Date().toISOString(),
        ...parsedData,
      },
    });
  } catch (err: any) {
    console.error('Error en /api/gemini/analyze-business:', err);
    res.status(500).json({
      error: `Error al analizar con Gemini AI: ${err.message || 'Error desconocido'}`,
      code: 'GEMINI_ANALYSIS_ERROR',
    });
  }
});

// 4. GEMINI: REGENERAR BORRADORES CON OTRO TONO (MÉTODO DEL MÉDICO)
app.post(['/api/gemini/regenerate-script', '/gemini/regenerate-script'], async (req: Request, res: Response) => {
  try {
    const { businessName, businessSummary, painPoints, recommendedService, sellerProfile, tone } =
      req.body;

    const sellerName = sellerProfile?.name || 'Simón';
    const agencyName = sellerProfile?.agencyName || 'Agencia de Servicios Digitales';

    const prompt = `Actúa como especialista en prospección comercial siguiendo la metodología de Nino Manzano en "El Método del Médico".
Regenera los borradores de prospección para el negocio "${businessName}" adaptándote al tono: "${tone}" (directo, consultivo, cercano o persuasivo), PERO SIN ROMPER LAS REGLAS DE ORO DEL MÉDICO:
- Siempre: 1) lo que has visto en Google, 2) lo que le cuesta en clientes perdidos, 3) una pregunta pequeña ("¿Te enseño en cinco minutos cómo se arregla?").
- NUNCA digas que haces webs, NUNCA des precios ni enseñes nada tuyo en el primer contacto.
- NADA de diseño ni tecnicismos. Habla de clientes, llamadas y citas.

Negocio:
- Nombre: ${businessName}
- Resumen: ${businessSummary}
- Fallos traducidos a coste: ${Array.isArray(painPoints) ? painPoints.join('; ') : painPoints}
- Servicio a recetar: ${recommendedService}

Vendedor:
- Nombre: ${sellerName} (${agencyName})

Devuelve únicamente un JSON con este formato exacto:
{
  "callScript30s": "Guion telefónico de 30 segundos con el nuevo tono",
  "whatsAppMessage": "Mensaje de WhatsApp exacto con el Método del Médico con el nuevo tono",
  "inPersonScript": "Guion presencial del médico con el nuevo tono",
  "objectionNotInterested": "Respuesta elegante si dice 'No me interesa'",
  "prescription": {
    "basicOption": {
      "title": "Opción básica (Arregla lo más urgente)",
      "description": "Solución a fallos más urgentes",
      "estimatedPrice": "390€"
    },
    "recommendedOption": {
      "title": "Opción recomendada (Arregla los tres fallos)",
      "description": "Solución integral + Revisión mensual con informe",
      "estimatedPrice": "690€",
      "monthlyFee": "49€/mes"
    },
    "theMathDone": {
      "avgTicketPerClient": 150,
      "extraClientsPerMonth": 2,
      "extraPerMonth": 300,
      "extraPerYear": 3600,
      "explanation": "La cuenta: si un cliente nuevo te deja 150€ y esto te trae solo 2 clientes más al mes, son 300€ al mes, 3.600€ al año."
    }
  },
  "emailPitch": {
    "subject": "Asunto directo al dolor",
    "body": "Cuerpo del correo"
  },
  "monthlyReviewMessage": "Mensaje de revisión mensual"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    let drafts: any;
    try {
      drafts = JSON.parse(text);
    } catch {
      const cleanJson = text.replace(/```json/gi, '').replace(/```/g, '').trim();
      drafts = JSON.parse(cleanJson);
    }

    res.json({ success: true, drafts });
  } catch (err: any) {
    console.error('Error en /api/gemini/regenerate-script:', err);
    res.status(500).json({
      error: `Error al regenerar borradores: ${err.message}`,
    });
  }
});

// 5. GEMINI: RADAR DE NICHOS - RANKING E INTELIGENCIA DE MERCADO
app.post(['/api/gemini/niche-radar', '/gemini/niche-radar'], async (req: Request, res: Response) => {
  try {
    const { zone, categoriesStats, sellerProfile } = req.body;

    const prompt = `Eres un estratega de desarrollo de negocio local para una agencia digital en España que vende:
1) Páginas web modernas y rápidas
2) Agentes inteligentes de WhatsApp para citas y presupuestos 24/7
3) Sistemas de reservas online

Zona analizada: "${zone}"
Datos estadísticos de cada nicho en la zona:
${JSON.stringify(categoriesStats, null, 2)}

Analiza estos datos (especialmente el % de negocios sin web propia, la valoración y volumen de reseñas que indican dinero y clientes).
Clasifica los nichos y recomienda los 3 mejores con mayor retorno potencial y menor fricción para vender.
Indica para cada uno de los 3 qué servicio concreto vender y por qué.

Responde estrictamente en formato JSON con la siguiente estructura:
{
  "recommendations": [
    {
      "niche": "Nombre del nicho",
      "rank": 1,
      "score": 95,
      "reason": "Explicación estratégica de por qué es la mejor oportunidad en esta zona",
      "recommendedService": "web_moderna" | "agente_whatsapp" | "sistema_citas",
      "actionStrategy": "Estrategia concreta de abordaje (ej. llamar por teléfono mencionando la pérdida de clientes por no tener botón de WhatsApp o web lenta)"
    }
  ]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    let parsed: any;
    try {
      parsed = JSON.parse(text);
    } catch {
      const cleanJson = text.replace(/```json/gi, '').replace(/```/g, '').trim();
      parsed = JSON.parse(cleanJson);
    }

    res.json({
      success: true,
      recommendations: parsed.recommendations || [],
    });
  } catch (err: any) {
    console.error('Error en /api/gemini/niche-radar:', err);
    res.status(500).json({
      error: `Error al evaluar nichos con Gemini: ${err.message}`,
    });
  }
});

export default app;
