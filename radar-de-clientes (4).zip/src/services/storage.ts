import { BusinessLead, UserSettings } from '../types';

const DB_NAME = 'RadarDeClientesDB';
const DB_VERSION = 1;

const STORES = {
  LEADS: 'leads',
  CACHE: 'search_cache',
  SETTINGS: 'app_settings',
} as const;

function getCurrentMonthYear(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

export const DEFAULT_SETTINGS: UserSettings = {
  googleCloudApiKey: '',
  sellerProfile: {
    name: 'Consultor Digital',
    agencyName: 'Agencia de Servicios Locales',
    servicesOffered: [
      'Páginas web modernas ultrarrápidas adaptadas a móvil',
      'Agentes inteligentes de WhatsApp para captar clientes 24/7',
      'Sistemas automáticos de reservas y citas online',
    ],
    uniqueValueProp: 'Ayudamos a negocios locales a duplicar sus solicitudes de cita y evitar que los clientes se vayan a la competencia por no responder al instante.',
    defaultTone: 'consultivo',
  },
  usageTracker: {
    monthYear: getCurrentMonthYear(),
    placesCallCount: 0,
    monthlyFreeTierLimit: 1000,
    alertThreshold: 800,
  },
};

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB no está disponible en este entorno.'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORES.LEADS)) {
        db.createObjectStore(STORES.LEADS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORES.CACHE)) {
        db.createObjectStore(STORES.CACHE, { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains(STORES.SETTINGS)) {
        db.createObjectStore(STORES.SETTINGS, { keyPath: 'id' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

// LEADS CRUD
export async function getAllLeads(): Promise<BusinessLead[]> {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.LEADS, 'readonly');
      const store = tx.objectStore(STORES.LEADS);
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error('Error al recuperar leads:', err);
    return [];
  }
}

export async function getLead(id: string): Promise<BusinessLead | undefined> {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.LEADS, 'readonly');
      const store = tx.objectStore(STORES.LEADS);
      const request = store.get(id);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.error(`Error al recuperar lead ${id}:`, err);
    return undefined;
  }
}

export async function saveLead(lead: BusinessLead): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORES.LEADS, 'readwrite');
    const store = tx.objectStore(STORES.LEADS);
    const request = store.put(lead);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function bulkSaveLeads(leads: BusinessLead[]): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORES.LEADS, 'readwrite');
    const store = tx.objectStore(STORES.LEADS);
    for (const lead of leads) {
      store.put(lead);
    }
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function deleteLead(id: string): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORES.LEADS, 'readwrite');
    const store = tx.objectStore(STORES.LEADS);
    const request = store.delete(id);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

// SEARCH CACHE
export async function getCachedSearch<T>(key: string): Promise<T | null> {
  try {
    const db = await openDatabase();
    return new Promise((resolve) => {
      const tx = db.transaction(STORES.CACHE, 'readonly');
      const store = tx.objectStore(STORES.CACHE);
      const request = store.get(key);
      request.onsuccess = () => {
        if (request.result && request.result.expiresAt > Date.now()) {
          resolve(request.result.data);
        } else {
          resolve(null);
        }
      };
      request.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

export async function setCachedSearch<T>(key: string, data: T, ttlHours = 24): Promise<void> {
  try {
    const db = await openDatabase();
    const tx = db.transaction(STORES.CACHE, 'readwrite');
    const store = tx.objectStore(STORES.CACHE);
    store.put({
      key,
      data,
      expiresAt: Date.now() + ttlHours * 3600 * 1000,
      cachedAt: new Date().toISOString(),
    });
  } catch (err) {
    console.warn('No se pudo guardar en caché:', err);
  }
}

export async function clearCache(): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORES.CACHE, 'readwrite');
    const store = tx.objectStore(STORES.CACHE);
    const request = store.clear();
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

// SETTINGS
export async function getSettings(): Promise<UserSettings> {
  try {
    // Primero intentar desde localStorage como respaldo rápido
    const local = localStorage.getItem('radar_settings');
    let loaded: UserSettings | null = null;
    if (local) {
      try {
        loaded = JSON.parse(local);
      } catch {
        // ignore
      }
    }

    const db = await openDatabase();
    const fromDb = await new Promise<UserSettings | null>((resolve) => {
      const tx = db.transaction(STORES.SETTINGS, 'readonly');
      const store = tx.objectStore(STORES.SETTINGS);
      const req = store.get('main');
      req.onsuccess = () => resolve(req.result ? req.result.settings : null);
      req.onerror = () => resolve(null);
    });

    const currentMonth = getCurrentMonthYear();
    const finalSettings: UserSettings = {
      ...DEFAULT_SETTINGS,
      ...(fromDb || loaded || {}),
      sellerProfile: {
        ...DEFAULT_SETTINGS.sellerProfile,
        ...((fromDb || loaded)?.sellerProfile || {}),
      },
      usageTracker: {
        ...DEFAULT_SETTINGS.usageTracker,
        ...((fromDb || loaded)?.usageTracker || {}),
      },
    };

    // Si ha cambiado de mes, renovar contador
    if (finalSettings.usageTracker.monthYear !== currentMonth) {
      finalSettings.usageTracker.monthYear = currentMonth;
      finalSettings.usageTracker.placesCallCount = 0;
      await saveSettings(finalSettings);
    }

    return finalSettings;
  } catch (err) {
    console.error('Error al obtener ajustes:', err);
    return DEFAULT_SETTINGS;
  }
}

export async function saveSettings(settings: UserSettings): Promise<void> {
  try {
    localStorage.setItem('radar_settings', JSON.stringify(settings));
    const db = await openDatabase();
    const tx = db.transaction(STORES.SETTINGS, 'readwrite');
    const store = tx.objectStore(STORES.SETTINGS);
    store.put({ id: 'main', settings });
  } catch (err) {
    console.error('Error al guardar ajustes:', err);
  }
}

export async function recordPlacesApiCall(count = 1): Promise<UserSettings> {
  const settings = await getSettings();
  const currentMonth = getCurrentMonthYear();
  if (settings.usageTracker.monthYear !== currentMonth) {
    settings.usageTracker.monthYear = currentMonth;
    settings.usageTracker.placesCallCount = count;
  } else {
    settings.usageTracker.placesCallCount += count;
  }
  await saveSettings(settings);
  return settings;
}

// EXPORT / IMPORT
export async function exportDatabaseToJson(): Promise<string> {
  const leads = await getAllLeads();
  const settings = await getSettings();
  const exportPayload = {
    exportedAt: new Date().toISOString(),
    version: 1,
    app: 'Radar de Clientes',
    leads,
    settings: {
      ...settings,
      // No exportamos la clave de API en backups portables por privacidad
      googleCloudApiKey: '',
    },
  };
  return JSON.stringify(exportPayload, null, 2);
}

export async function importDatabaseFromJson(jsonString: string): Promise<{ leadsImported: number }> {
  const data = JSON.parse(jsonString);
  if (!data || !Array.isArray(data.leads)) {
    throw new Error('El archivo importado no contiene una lista válida de leads.');
  }

  await bulkSaveLeads(data.leads);

  if (data.settings?.sellerProfile) {
    const current = await getSettings();
    await saveSettings({
      ...current,
      sellerProfile: {
        ...current.sellerProfile,
        ...data.settings.sellerProfile,
      },
    });
  }

  return { leadsImported: data.leads.length };
}
