import { BusinessLead, PageSpeedAudit, AiAudit, WebsiteType, ScoreBreakdownItem } from '../types';

const SOCIAL_AND_DIRECTORY_DOMAINS = [
  'facebook.com',
  'fb.com',
  'instagram.com',
  'instagr.am',
  'linktr.ee',
  'linkedin.com',
  'tiktok.com',
  'twitter.com',
  'x.com',
  'paginasamarillas.es',
  'yelp.es',
  'yelp.com',
  'qdq.com',
  'citiservi.es',
  'habitissimo.es',
  'topdoctors.es',
  'doctoralia.es',
  'tripadvisor.es',
  'tripadvisor.com',
  'milanuncios.com',
  'bodas.net',
  'guiadegym.com',
  'google.com/business',
];

export function detectWebsiteType(uri?: string): { type: WebsiteType; providerName?: string } {
  if (!uri || uri.trim() === '') {
    return { type: 'none' };
  }

  const clean = uri.toLowerCase();
  for (const domain of SOCIAL_AND_DIRECTORY_DOMAINS) {
    if (clean.includes(domain)) {
      let provider = domain.replace('.es', '').replace('.com', '').replace('.net', '');
      if (provider === 'fb') provider = 'Facebook';
      if (provider === 'paginasamarillas') provider = 'Páginas Amarillas';
      return {
        type: 'social_or_directory',
        providerName: provider.charAt(0).toUpperCase() + provider.slice(1),
      };
    }
  }

  return { type: 'own_domain' };
}

export function calculateOpportunityScore(
  lead: Partial<BusinessLead>,
  pageSpeedAudit?: PageSpeedAudit,
  aiAudit?: AiAudit
): { score: number; breakdown: ScoreBreakdownItem[]; isProvisional: boolean } {
  let score = 50; // Puntuación base neutral
  const breakdown: ScoreBreakdownItem[] = [
    { label: 'Puntuación base', points: 50, reason: 'Punto de partida neutral' },
  ];

  const websiteType = lead.websiteType || detectWebsiteType(lead.websiteUri).type;
  const reviews = lead.userRatingCount || 0;
  const rating = lead.rating || 0;
  const hasPhone = Boolean(lead.nationalPhoneNumber || lead.internationalPhoneNumber);

  // 1. FACTOR PRESENCIA WEB
  if (websiteType === 'none') {
    score += 35;
    breakdown.push({
      label: 'Sin página web registrada',
      points: 35,
      reason: 'Máxima urgencia comercial: necesitan crear su presencia digital desde cero.',
    });
  } else if (websiteType === 'social_or_directory') {
    score += 25;
    breakdown.push({
      label: 'Dependencia de red social / directorio',
      points: 25,
      reason: 'Usan Facebook, Instagram o directorio en lugar de web propia; pierden posicionamiento y control de marca.',
    });
  } else {
    // Tiene web propia
    if (pageSpeedAudit) {
      const perf = pageSpeedAudit.scores.performance;
      if (perf < 50) {
        score += 20;
        breakdown.push({
          label: 'Rendimiento móvil deficiente (<50)',
          points: 20,
          reason: `Nota de velocidad móvil de ${perf}/100. Los visitantes rebotan antes de cargar.`,
        });
      } else if (perf < 75) {
        score += 10;
        breakdown.push({
          label: 'Rendimiento móvil mejorable (50-74)',
          points: 10,
          reason: `Nota de velocidad móvil de ${perf}/100 con margen notable de optimización.`,
        });
      } else if (perf >= 85) {
        score -= 25;
        breakdown.push({
          label: 'Web móvil de alto rendimiento (>=85)',
          points: -25,
          reason: `Velocidad móvil excelente (${perf}/100); menor propensión a cambiar de desarrollador web.`,
        });
      }
    } else {
      // Si tiene web pero aún no está auditada
      breakdown.push({
        label: 'Web propia pendiente de auditar',
        points: 0,
        reason: 'Tiene web propia registrada; la nota definitiva se ajustará tras auditar PageSpeed y Gemini.',
      });
    }
  }

  // 2. FACTOR TECNOLÓGICO Y CONVERSIÓN (Si se ha analizado con IA)
  if (aiAudit) {
    if (!aiAudit.checklist.hasWhatsAppButton) {
      score += 10;
      breakdown.push({
        label: 'Sin botón directo de WhatsApp',
        points: 10,
        reason: 'Oportunidad perfecta para vender integración de WhatsApp o asistente automatizado.',
      });
    }

    if (!aiAudit.checklist.hasOnlineBooking) {
      score += 10;
      breakdown.push({
        label: 'Sin sistema de reservas / citas online',
        points: 10,
        reason: 'Pierden clientes fuera de horario; oportunidad ideal para vender sistema de reservas.',
      });
    }

    if (aiAudit.checklist.isOutdated) {
      score += 5;
      breakdown.push({
        label: 'Señales de web desactualizada o abandonada',
        points: 5,
        reason: `Copyright o diseño estancado (${aiAudit.checklist.copyrightYear || 'antiguo'}); negocio abierto a renovación.`,
      });
    }
  }

  // 3. FACTOR ACTIVIDAD COMERCIAL (Capacidad de pago y clientes reales)
  if (reviews >= 25 && rating >= 4.0) {
    score += 15;
    breakdown.push({
      label: 'Negocio con alta actividad y excelente reputación',
      points: 15,
      reason: `${reviews} reseñas con media ${rating.toFixed(1)}★. Negocio con facturación, clientes y capacidad económica.`,
    });
  } else if (reviews >= 8 && rating >= 3.8) {
    score += 8;
    breakdown.push({
      label: 'Actividad comercial moderada y sólida',
      points: 8,
      reason: `${reviews} reseñas con media ${rating.toFixed(1)}★. Negocio activo en su zona.`,
    });
  } else if (reviews < 3) {
    score -= 10;
    breakdown.push({
      label: 'Apenas tiene reseñas en Google Maps',
      points: -10,
      reason: 'Negocio con muy poca tracción verificable o de reciente apertura.',
    });
  }

  // 4. FACTOR CONTACTABILIDAD
  if (hasPhone) {
    score += 5;
    breakdown.push({
      label: 'Teléfono directo disponible',
      points: 5,
      reason: 'Permite contacto directo telefónico o por WhatsApp de inmediato.',
    });
  } else {
    score -= 10;
    breakdown.push({
      label: 'Sin teléfono público visible',
      points: -10,
      reason: 'Dificulta la prospección directa.',
    });
  }

  // Límites estrictos 0 - 100
  const finalScore = Math.max(0, Math.min(100, Math.round(score)));
  const isProvisional = websiteType === 'own_domain' && !pageSpeedAudit && !aiAudit;

  return {
    score: finalScore,
    breakdown,
    isProvisional,
  };
}
