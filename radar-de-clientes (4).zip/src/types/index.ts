export type WebsiteType = 'none' | 'social_or_directory' | 'own_domain';

export type CrmLeadStatus =
  | 'nuevo'
  | 'analizado'
  | 'contactado'
  | 'respondio'
  | 'reunion'
  | 'cliente'
  | 'descartado';

export type SalesTone = 'directo' | 'consultivo' | 'cercano' | 'persuasivo';

export type RecommendedService = 'web_moderna' | 'agente_whatsapp' | 'sistema_citas';

export interface ScoreBreakdownItem {
  label: string;
  points: number;
  reason: string;
}

export interface PageSpeedAudit {
  analyzedAt: string;
  scores: {
    performance: number;
    seo: number;
    accessibility: number;
    bestPractices: number;
  };
  screenshotBase64?: string;
  testedUrl: string;
}

export interface DiagnosticFinding {
  finding: string; // Lo que has visto (concreto y visible)
  costInMoney: string; // Lo que le cuesta (traducido a clientes y dinero perdido)
}

export interface MedicalPrescription {
  diagnosticSummary?: string;
  threeErrorsWithCost: DiagnosticFinding[];
  basicOption: {
    title: string;
    description: string;
    estimatedPrice: string;
  };
  recommendedOption: {
    title: string;
    description: string;
    estimatedPrice: string;
    monthlyFee: string;
  };
  theMathDone: {
    avgTicketPerClient: number; // Ej. 150
    extraClientsPerMonth: number; // Ej. 2
    extraPerMonth: number; // Ej. 300
    extraPerYear: number; // Ej. 3600
    explanation: string;
  };
}

export interface SalesDrafts {
  callScript30s: string;
  whatsAppMessage: string;
  inPersonScript?: string;
  objectionNotInterested?: string;
  prescription?: MedicalPrescription;
  emailPitch: {
    subject: string;
    body: string;
  };
  monthlyReviewMessage?: string;
}

export interface AiAudit {
  analyzedAt: string;
  businessSummary: string;
  checklist: {
    hasHttps: boolean;
    isMobileResponsive: boolean;
    hasWhatsAppButton: boolean;
    hasOnlineBooking: boolean;
    hasContactForm: boolean;
    isOutdated: boolean;
    copyrightYear?: string;
  };
  // Estructura Hoja de Diagnóstico (PDF Método del Médico)
  medicalDiagnosis?: {
    symptoms: string[]; // Síntomas detectados (ej: 'Muchas reseñas y sin web', 'Competencia mejor posicionada')
    threeQuestions: {
      findability: { passed: boolean; note: string }; // ¿Le encuentro?
      understanding: { passed: boolean; note: string }; // ¿Le entiendo?
      contactability: { passed: boolean; note: string }; // ¿Puedo contactarle?
    };
    findingsWithCost: DiagnosticFinding[];
  };
  extractedEmails: string[];
  extractedSocials: string[];
  painPoints: string[];
  recommendedService: RecommendedService;
  recommendedServiceReason: string;
  salesDrafts: SalesDrafts;
}

export interface BusinessLead {
  id: string; // places.id
  displayName: string;
  formattedAddress: string;
  location?: {
    latitude: number;
    longitude: number;
  };
  nationalPhoneNumber?: string;
  internationalPhoneNumber?: string;
  websiteUri?: string;
  websiteType: WebsiteType;
  socialOrDirectoryName?: string;
  rating?: number;
  userRatingCount?: number;
  primaryTypeDisplayName?: string;
  types?: string[];
  googleMapsUri: string;
  businessStatus: string;

  // Puntuación de Oportunidad (0 a 100)
  opportunityScore: number;
  scoreBreakdown: ScoreBreakdownItem[];
  isProvisionalScore: boolean;

  // Auditorías
  pageSpeedAudit?: PageSpeedAudit;
  aiAudit?: AiAudit;

  // CRM
  crm: {
    status: CrmLeadStatus;
    savedAt?: string;
    nextActionDate?: string;
    notes?: string;
  };

  // Metadatos de prospección
  searchQueryZone?: string;
  searchQueryNiche?: string;
}

export interface SellerProfile {
  name: string;
  agencyName: string;
  servicesOffered: string[];
  uniqueValueProp: string;
  defaultTone: SalesTone;
}

export interface UsageTracker {
  monthYear: string; // e.g. "2026-10"
  placesCallCount: number;
  monthlyFreeTierLimit: number; // e.g. 1000
  alertThreshold: number; // e.g. 800
}

export interface UserSettings {
  googleCloudApiKey: string;
  sellerProfile: SellerProfile;
  usageTracker: UsageTracker;
}

export interface NicheCategoryStats {
  niche: string;
  totalFound: number;
  withoutOwnWebCount: number;
  withoutOwnWebPercent: number;
  avgRating: number;
  avgReviews: number;
}

export interface NicheRecommendation {
  niche: string;
  rank: number;
  score: number;
  reason: string;
  recommendedService: RecommendedService;
  actionStrategy: string;
}

export interface NicheRadarResult {
  zone: string;
  analyzedAt: string;
  categories: NicheCategoryStats[];
  recommendations: NicheRecommendation[];
}
