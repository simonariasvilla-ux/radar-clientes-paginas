/**
 * Utilidad de WhatsApp y Guiones Comerciales para Radar de Clientes
 * Implementa estrictamente la metodología del PDF:
 * "Hoja de diagnóstico - El Método del Médico para vender páginas web a negocios locales"
 * por Nino Manzano.
 *
 * Principio rector:
 * 1. Lo que has visto (como un cliente en Google)
 * 2. Lo que le cuesta (clientes que se van al siguiente sin llamar)
 * 3. Pregunta pequeña ("¿Te enseño en cinco minutos cómo se arregla?")
 *
 * Reglas de oro del PDF:
 * - NO digas que haces webs en el primer contacto.
 * - NO des precios.
 * - NO enseñes nada tuyo.
 * - NO hables de diseño ni tecnología. Habla de llamadas, citas y clientes perdidos.
 */

import { BusinessLead } from '../types';

export function cleanPhoneNumber(rawPhone?: string): string {
  if (!rawPhone) return '';

  let cleaned = rawPhone.replace(/[\s\(\)\-\.]/g, '');

  if (cleaned.startsWith('+')) {
    cleaned = cleaned.substring(1);
  } else if (
    cleaned.length === 9 &&
    (cleaned.startsWith('6') ||
      cleaned.startsWith('7') ||
      cleaned.startsWith('8') ||
      cleaned.startsWith('9'))
  ) {
    // Prefijo telefónico España si es de 9 cifras
    cleaned = '34' + cleaned;
  }

  return cleaned.replace(/\D/g, '');
}

export function buildWhatsAppUrl(rawPhone?: string, message?: string): string | null {
  const phone = cleanPhoneNumber(rawPhone);
  if (!phone || phone.length < 7) {
    return null;
  }

  const encodedText = message ? encodeURIComponent(message) : '';
  return `https://wa.me/${phone}${encodedText ? `?text=${encodedText}` : ''}`;
}

/**
 * Genera el mensaje de WhatsApp ultra-personalizado según la estructura exacta del PDF:
 *
 * "Hola [nombre], soy [tu nombre].
 * He buscado [servicio en tu zona] como lo haría un cliente, y salen [otros tres] antes que vosotros.
 * Y en vuestra ficha [fallo concreto detectado].
 * Eso son clientes que se van al siguiente sin llamaros.
 * ¿Te enseño en cinco minutos cómo se arregla?"
 */
export function getDefaultWhatsAppTemplate(
  businessName: string,
  hasOwnWeb: boolean,
  zone?: string,
  niche?: string,
  sellerName: string = 'Simón',
  specificFinding?: string
): string {
  const safeName = businessName || 'vuestro negocio';
  const serviceStr = niche || 'vuestro servicio';
  const zoneStr = zone ? ` en ${zone}` : ' en vuestra zona';

  // Si ya tenemos un fallo concreto analizado, lo usamos
  let flawText = specificFinding;

  if (!flawText) {
    if (!hasOwnWeb) {
      flawText = 'no hay forma de ver vuestros servicios ni pedir cita, solo un teléfono fijo que muchas veces no se pulsa desde el móvil';
    } else {
      flawText = 'la web tarda más de 5 segundos en abrir en el móvil y no hay botón directo para llamar ni pedir cita sin bajar';
    }
  }

  return `Hola, ¿qué tal? Soy ${sellerName}.

He buscado ${serviceStr}${zoneStr} como lo haría un cliente, y salen otros tres negocios antes que vosotros. Y en vuestra ficha ${flawText}.

Eso son clientes que se van al siguiente sin llamaros.

¿Te enseño en cinco minutos cómo se arregla?`;
}

/**
 * Plantilla para cuando el dueño dice que no le interesa (Página 7 del PDF)
 * Regla del PDF: Agradecer, no insistir, dejar número y agendar seguimiento.
 */
export function getDoctorObjectionTemplate(sellerName: string = 'Simón'): string {
  return `Perfecto, muchas gracias por decírmelo. Si en algún momento queréis verlo sin compromiso, aquí tenéis mi número guardado. ¡Que tengáis muy buena semana!`;
}

/**
 * Guion presencial del Método del Médico (Página 7 del PDF)
 * Regla del PDF: Llevar el móvil con la búsqueda ya abierta. Que lo vea él, no que te crea a ti.
 */
export function getDoctorInPersonScript(
  businessName: string,
  niche?: string,
  zone?: string,
  sellerName: string = 'Simón',
  flaw?: string
): string {
  const service = niche || 'vuestro servicio';
  const concreteFlaw =
    flaw ||
    'que salen tres negocios de la zona antes que vosotros y en la ficha no hay botón rápido para pedir cita';

  return `Hola, ¿eres el responsable de ${businessName}? Soy ${sellerName}.

Antes de venir he buscado "${service}" en Google como lo haría un cliente y he visto una cosa: ${concreteFlaw}.

Te lo enseño un momento en la pantalla del móvil, que son dos minutos.`;
}

/**
 * Guion de llamada 30s del Método del Médico (Página 7 del PDF)
 */
export function getDoctorCallScript(
  businessName: string,
  sellerName: string = 'Simón'
): string {
  return `Hola, ¿hablo con el responsable de ${businessName}? Soy ${sellerName}, te llamo porque he visto una cosa en vuestra ficha de Google que os está haciendo perder clientes. ¿Tienes un minuto y te lo cuento?`;
}

/**
 * Mensaje de revisión mensual (Página 9 del PDF)
 */
export function getDoctorMonthlyReviewTemplate(
  businessName: string,
  monthName: string = 'este mes'
): string {
  return `Hola, te paso el resumen de ${monthName} 👇

• 148 personas han entrado en la web
• 32 te han llamado directamente desde el botón móvil
• 14 han pedido cita / presupuesto

Este mes he optimizado la velocidad de carga móvil. El mes que viene quiero añadir las fotos nuevas de los trabajos recientes.

¿Cómo lo habéis notado vosotros en el local?`;
}
