import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { SearchView } from './views/SearchView';
import { BusinessDetailView } from './views/BusinessDetailView';
import { NicheRadarView } from './views/NicheRadarView';
import { MyLeadsView } from './views/MyLeadsView';
import { SettingsView } from './views/SettingsView';
import { BusinessLead, UserSettings } from './types';
import { getAllLeads, getSettings, DEFAULT_SETTINGS } from './services/storage';

export default function App() {
  const [currentView, setCurrentView] = useState<
    'search' | 'detail' | 'radar' | 'leads' | 'settings'
  >('search');
  const [selectedLead, setSelectedLead] = useState<BusinessLead | null>(null);
  const [savedLeads, setSavedLeads] = useState<BusinessLead[]>([]);
  const [settings, setSettings] = useState<UserSettings>(DEFAULT_SETTINGS);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);

  // Load leads and settings from IndexedDB on start
  const refreshStorageData = async () => {
    try {
      const [leadsData, settingsData] = await Promise.all([getAllLeads(), getSettings()]);
      setSavedLeads(leadsData);
      setSettings(settingsData);
    } catch (err) {
      console.error('Error inicializando datos locales:', err);
    } finally {
      setIsInitializing(false);
    }
  };

  useEffect(() => {
    refreshStorageData();
  }, []);

  const savedLeadIds = new Set(savedLeads.map((l) => l.id));

  const handleSelectLead = (lead: BusinessLead) => {
    setSelectedLead(lead);
    setCurrentView('detail');
    setMobileMenuOpen(false);
  };

  const handleLeadSavedOrUpdated = (lead: BusinessLead) => {
    setSavedLeads((prev) => {
      const existsIndex = prev.findIndex((l) => l.id === lead.id);
      if (existsIndex !== -1) {
        const next = [...prev];
        next[existsIndex] = lead;
        return next;
      }
      return [lead, ...prev];
    });

    if (selectedLead && selectedLead.id === lead.id) {
      setSelectedLead(lead);
    }
  };

  const handleLeadDeleted = (id: string) => {
    setSavedLeads((prev) => prev.filter((l) => l.id !== id));
    if (selectedLead && selectedLead.id === id) {
      setSelectedLead(null);
      setCurrentView('leads');
    }
  };

  const [searchTargetZone, setSearchTargetZone] = useState('Dos Hermanas, Sevilla');
  const [searchTargetNiche, setSearchTargetNiche] = useState('talleres mecánicos');

  // Launch search from Niche Radar
  const handleExploreNicheFromRadar = (zone: string, niche: string) => {
    setSearchTargetZone(zone);
    setSearchTargetNiche(niche);
    setCurrentView('search');
  };

  if (isInitializing) {
    return (
      <div className="min-h-screen bg-neutral-950 flex items-center justify-center text-neutral-400 text-xs font-mono">
        Iniciando Radar de Clientes (IndexedDB)...
      </div>
    );
  }

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-neutral-950 text-neutral-100 antialiased">
      {/* Desktop & Mobile Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-40 transition-transform duration-200 md:relative md:translate-x-0 ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <Sidebar
          currentView={currentView}
          onNavigate={(view) => {
            setCurrentView(view);
            setMobileMenuOpen(false);
          }}
          selectedLeadId={selectedLead?.id || null}
          savedLeadsCount={savedLeads.length}
          settings={settings}
        />
      </div>

      {/* Backdrop for mobile drawer */}
      {mobileMenuOpen && (
        <div
          onClick={() => setMobileMenuOpen(false)}
          className="fixed inset-0 bg-black/60 z-30 md:hidden backdrop-blur-xs"
        />
      )}

      {/* Main View Area */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        <Header
          currentView={currentView}
          settings={settings}
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
          selectedLeadName={selectedLead?.displayName}
        />

        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          {currentView === 'search' && (
            <SearchView
              settings={settings}
              onUpdateSettings={setSettings}
              onSelectLead={handleSelectLead}
              savedLeadIds={savedLeadIds}
              onLeadSaved={handleLeadSavedOrUpdated}
              initialZone={searchTargetZone}
              initialNiche={searchTargetNiche}
            />
          )}

          {currentView === 'detail' && (
            selectedLead ? (
              <BusinessDetailView
                lead={selectedLead}
                settings={settings}
                onBack={() => setCurrentView('search')}
                onLeadUpdated={handleLeadSavedOrUpdated}
              />
            ) : (
              <div className="p-12 text-center text-neutral-400 text-xs">
                No hay ningún negocio seleccionado. Selecciona uno en Buscar o en Mis Leads.
              </div>
            )
          )}

          {currentView === 'radar' && (
            <NicheRadarView
              settings={settings}
              onUpdateSettings={setSettings}
              onExploreNiche={handleExploreNicheFromRadar}
            />
          )}

          {currentView === 'leads' && (
            <MyLeadsView
              leads={savedLeads}
              onSelectLead={handleSelectLead}
              onLeadUpdated={handleLeadSavedOrUpdated}
              onLeadDeleted={handleLeadDeleted}
              sellerName={settings.sellerProfile.name}
            />
          )}

          {currentView === 'settings' && (
            <SettingsView
              settings={settings}
              onUpdateSettings={setSettings}
              onDataImported={refreshStorageData}
            />
          )}
        </main>
      </div>
    </div>
  );
}
