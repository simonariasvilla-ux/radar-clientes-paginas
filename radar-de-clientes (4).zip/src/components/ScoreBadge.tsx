import React, { useState } from 'react';
import { ScoreBreakdownItem } from '../types';
import { Info, ChevronDown, ChevronUp } from 'lucide-react';

interface ScoreBadgeProps {
  score: number;
  isProvisional?: boolean;
  breakdown?: ScoreBreakdownItem[];
  size?: 'sm' | 'md' | 'lg';
  showDetailsToggle?: boolean;
}

export const ScoreBadge: React.FC<ScoreBadgeProps> = ({
  score,
  isProvisional = false,
  breakdown = [],
  size = 'md',
  showDetailsToggle = false,
}) => {
  const [expanded, setExpanded] = useState(false);

  // Color tokens
  const getColor = (val: number) => {
    if (val >= 75) {
      return {
        bg: 'bg-emerald-500/10',
        border: 'border-emerald-500/30',
        text: 'text-emerald-400',
        label: 'Alta Oportunidad',
      };
    }
    if (val >= 50) {
      return {
        bg: 'bg-amber-500/10',
        border: 'border-amber-500/30',
        text: 'text-amber-400',
        label: 'Oportunidad Media',
      };
    }
    return {
      bg: 'bg-rose-500/10',
      border: 'border-rose-500/30',
      text: 'text-rose-400',
      label: 'Baja Oportunidad',
    };
  };

  const color = getColor(score);

  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5',
    md: 'text-sm px-2.5 py-1',
    lg: 'text-xl font-bold px-4 py-2',
  }[size];

  return (
    <div className="inline-flex flex-col">
      <div className="inline-flex items-center gap-1.5">
        <div
          className={`inline-flex items-center gap-1.5 rounded-md border font-mono tabular-nums font-semibold ${color.bg} ${color.border} ${color.text} ${sizeClasses}`}
        >
          <span>{score}</span>
          <span className="text-[10px] font-sans font-normal opacity-70">/100</span>
        </div>

        {isProvisional && (
          <span
            title="Puntuación provisional basada en datos de Google Places. Se ajustará al auditar la web con PageSpeed y Gemini."
            className="text-[10px] px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-400 border border-neutral-700 font-sans cursor-help"
          >
            Provisional
          </span>
        )}

        {showDetailsToggle && breakdown.length > 0 && (
          <button
            onClick={() => setExpanded(!expanded)}
            className="p-1 text-neutral-400 hover:text-neutral-200 transition-colors"
            title="Ver desglose detallado de la puntuación"
          >
            {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        )}
      </div>

      {expanded && breakdown.length > 0 && (
        <div className="mt-2 p-3 bg-neutral-900 border border-neutral-800 rounded-lg text-xs space-y-2 w-full max-w-sm animate-in fade-in duration-150">
          <div className="flex items-center justify-between font-semibold text-neutral-300 border-b border-neutral-800 pb-1.5">
            <span>Desglose de Puntuación</span>
            <span className="font-mono text-emerald-400">{score} pts</span>
          </div>
          <div className="space-y-1.5 max-h-56 overflow-y-auto">
            {breakdown.map((item, idx) => (
              <div key={idx} className="flex items-start justify-between gap-2 text-[11px]">
                <div className="flex-1">
                  <div className="text-neutral-200 font-medium">{item.label}</div>
                  <div className="text-neutral-300 text-[10px]">{item.reason}</div>
                </div>
                <span
                  className={`font-mono font-medium shrink-0 ${
                    item.points > 0
                      ? 'text-emerald-400'
                      : item.points < 0
                      ? 'text-rose-400'
                      : 'text-neutral-300'
                  }`}
                >
                  {item.points > 0 ? `+${item.points}` : item.points}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
