import React from 'react';

interface PageSpeedGaugesProps {
  scores: {
    performance: number;
    seo: number;
    accessibility: number;
    bestPractices: number;
  };
}

export const PageSpeedGauges: React.FC<PageSpeedGaugesProps> = ({ scores }) => {
  const categories = [
    { key: 'performance', label: 'Rendimiento', value: scores.performance },
    { key: 'seo', label: 'SEO', value: scores.seo },
    { key: 'accessibility', label: 'Accesibilidad', value: scores.accessibility },
    { key: 'bestPractices', label: 'Buenas Prácticas', value: scores.bestPractices },
  ];

  const getColor = (value: number) => {
    if (value >= 90) return { stroke: '#10b981', text: 'text-emerald-400', bg: 'bg-emerald-500/10' };
    if (value >= 50) return { stroke: '#f59e0b', text: 'text-amber-400', bg: 'bg-amber-500/10' };
    return { stroke: '#ef4444', text: 'text-rose-400', bg: 'bg-rose-500/10' };
  };

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
      {categories.map((cat) => {
        const color = getColor(cat.value);
        const radius = 26;
        const circumference = 2 * Math.PI * radius;
        const strokeDashoffset = circumference - (cat.value / 100) * circumference;

        return (
          <div
            key={cat.key}
            className="flex flex-col items-center justify-center p-3 rounded-lg bg-neutral-900 border border-neutral-800"
          >
            <div className="relative w-16 h-16 flex items-center justify-center">
              <svg className="w-16 h-16 transform -rotate-90" viewBox="0 0 64 64">
                <circle
                  cx="32"
                  cy="32"
                  r={radius}
                  stroke="currentColor"
                  strokeWidth="4.5"
                  className="text-neutral-800"
                  fill="transparent"
                />
                <circle
                  cx="32"
                  cy="32"
                  r={radius}
                  stroke={color.stroke}
                  strokeWidth="4.5"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  fill="transparent"
                  className="transition-all duration-700 ease-out"
                />
              </svg>
              <span className={`absolute font-mono font-bold text-sm ${color.text} tabular-nums`}>
                {cat.value}
              </span>
            </div>
            <span className="mt-2 text-xs font-medium text-neutral-300 text-center">
              {cat.label}
            </span>
            <span className="text-[10px] text-neutral-400">Móvil</span>
          </div>
        );
      })}
    </div>
  );
};
