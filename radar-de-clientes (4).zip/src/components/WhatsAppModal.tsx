import React, { useState, useEffect } from 'react';
import {
  MessageSquare,
  X,
  ExternalLink,
  Copy,
  Check,
  Send,
  Sparkles,
  Phone,
  AlertCircle,
  HelpCircle,
  Stethoscope,
  ShieldAlert,
  CalendarCheck,
  Info,
} from 'lucide-react';
import { BusinessLead } from '../types';
import {
  buildWhatsAppUrl,
  cleanPhoneNumber,
  getDefaultWhatsAppTemplate,
  getDoctorObjectionTemplate,
  getDoctorMonthlyReviewTemplate,
} from '../utils/whatsapp';

interface WhatsAppModalProps {
  lead: BusinessLead;
  isOpen: boolean;
  onClose: () => void;
  onMessageSent?: (updatedStatus?: boolean) => void;
  sellerName?: string;
}

export const WhatsAppModal: React.FC<WhatsAppModalProps> = ({
  lead,
  isOpen,
  onClose,
  onMessageSent,
  sellerName = 'Simón',
}) => {
  const phone = lead.nationalPhoneNumber || lead.internationalPhoneNumber || '';
  const cleanedPhone = cleanPhoneNumber(phone);

  type TemplateType = 'diagnostico' | 'objecion' | 'revision';
  const [selectedTemplate, setSelectedTemplate] = useState<TemplateType>('diagnostico');
  const [showTips, setShowTips] = useState(false);

  // Determinar fallo visible para el diagnóstico si existe
  const specificFinding =
    lead.aiAudit?.medicalDiagnosis?.findingsWithCost?.[0]?.finding ||
    (lead.aiAudit?.painPoints?.[0] ?? undefined);

  const getTemplateContent = (type: TemplateType): string => {
    switch (type) {
      case 'diagnostico':
        return (
          lead.aiAudit?.salesDrafts?.whatsAppMessage ||
          getDefaultWhatsAppTemplate(
            lead.displayName,
            lead.websiteType === 'own_domain',
            lead.searchQueryZone,
            lead.searchQueryNiche || lead.primaryTypeDisplayName,
            sellerName,
            specificFinding
          )
        );
      case 'objecion':
        return (
          lead.aiAudit?.salesDrafts?.objectionNotInterested ||
          getDoctorObjectionTemplate(sellerName)
        );
      case 'revision':
        return (
          lead.aiAudit?.salesDrafts?.monthlyReviewMessage ||
          getDoctorMonthlyReviewTemplate(lead.displayName)
        );
    }
  };

  const [message, setMessage] = useState(() => getTemplateContent('diagnostico'));
  const [copied, setCopied] = useState(false);
  const [markAsContacted, setMarkAsContacted] = useState(true);

  // Actualizar mensaje cuando cambie la pestaña de plantilla
  const handleSelectTemplate = (type: TemplateType) => {
    setSelectedTemplate(type);
    setMessage(getTemplateContent(type));
  };

  useEffect(() => {
    if (isOpen) {
      setSelectedTemplate('diagnostico');
      setMessage(getTemplateContent('diagnostico'));
    }
  }, [isOpen, lead]);

  if (!isOpen) return null;

  const waUrl = buildWhatsAppUrl(phone, message);

  const handleOpenWhatsApp = () => {
    if (!waUrl) return;
    window.open(waUrl, '_blank', 'noopener,noreferrer');
    if (onMessageSent) {
      onMessageSent(markAsContacted);
    }
    onClose();
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(message);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-xl w-full p-5 sm:p-6 space-y-4 shadow-2xl animate-in zoom-in-95 duration-150 my-auto">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-sm text-neutral-100 flex items-center gap-2">
                <span>Mensaje Personalizado WhatsApp</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Método del Médico
                </span>
              </h3>
              <p className="text-xs text-neutral-400">
                Contacto directo con <strong className="text-neutral-200">{lead.displayName}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Contact info bar */}
        <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800/90 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs font-mono">
          <div className="flex items-center gap-2 text-neutral-300">
            <Phone className="w-3.5 h-3.5 text-neutral-400" />
            <span>{phone || 'Sin teléfono registrado en Google'}</span>
          </div>
          {cleanedPhone ? (
            <span className="text-[11px] text-emerald-400 font-sans flex items-center gap-1">
              <Check className="w-3 h-3" />
              Destino internacional: +{cleanedPhone}
            </span>
          ) : (
            <span className="text-[11px] text-rose-400 font-sans flex items-center gap-1">
              <AlertCircle className="w-3 h-3" />
              Teléfono no válido para WhatsApp directo
            </span>
          )}
        </div>

        {/* Selector de plantilla según el momento del contacto */}
        <div className="space-y-1.5">
          <div className="text-[11px] font-medium text-neutral-400 flex items-center justify-between">
            <span>Selecciona el guion a utilizar:</span>
            <button
              type="button"
              onClick={() => setShowTips(!showTips)}
              className="text-emerald-400 hover:underline inline-flex items-center gap-1 text-[11px] cursor-pointer"
            >
              <Info className="w-3 h-3" />
              <span>{showTips ? 'Ocultar consejos del PDF' : 'Ver consejos del PDF'}</span>
            </button>
          </div>

          <div className="grid grid-cols-3 gap-1.5 bg-neutral-950 p-1 rounded-xl border border-neutral-800">
            <button
              type="button"
              onClick={() => handleSelectTemplate('diagnostico')}
              className={`py-2 px-2.5 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                selectedTemplate === 'diagnostico'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shadow-xs'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
              }`}
            >
              <Stethoscope className="w-3.5 h-3.5" />
              <span className="truncate">1. Diagnóstico</span>
            </button>

            <button
              type="button"
              onClick={() => handleSelectTemplate('objecion')}
              className={`py-2 px-2.5 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                selectedTemplate === 'objecion'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shadow-xs'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span className="truncate">«No me interesa»</span>
            </button>

            <button
              type="button"
              onClick={() => handleSelectTemplate('revision')}
              className={`py-2 px-2.5 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                selectedTemplate === 'revision'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shadow-xs'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
              }`}
            >
              <CalendarCheck className="w-3.5 h-3.5" />
              <span className="truncate">Revisión mensual</span>
            </button>
          </div>
        </div>

        {/* Banner de Consejos del Método del Médico (Páginas 2, 5 y 7 del PDF) */}
        {showTips && (
          <div className="p-3.5 rounded-xl bg-neutral-950 border border-emerald-500/20 space-y-2 text-xs animate-in fade-in-50 duration-200">
            <div className="font-semibold text-emerald-400 flex items-center gap-1.5 text-xs">
              <Stethoscope className="w-4 h-4" />
              <span>Reglas de Oro del Método del Médico (PDF Nino Manzano):</span>
            </div>
            <ul className="text-neutral-300 space-y-1.5 text-[11px] leading-relaxed pl-1">
              <li className="flex items-start gap-1.5">
                <span className="text-emerald-400 font-bold shrink-0">1.</span>
                <span><strong>Lo que has visto:</strong> Explica cómo lo buscaste en Google como un cliente real y qué fallo concreto encontraste.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-emerald-400 font-bold shrink-0">2.</span>
                <span><strong>Lo que le cuesta:</strong> Tradúcelo a clientes y llamadas que se van al siguiente negocio. Nada de tecnicismos ni de diseño.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-emerald-400 font-bold shrink-0">3.</span>
                <span><strong>Pregunta pequeña:</strong> Termina siempre con un micro-compromiso: <em>«¿Te enseño en cinco minutos cómo se arregla?»</em></span>
              </li>
              <li className="flex items-start gap-1.5 text-amber-300/90 pt-0.5 border-t border-neutral-800">
                <span className="font-bold shrink-0">⚠️</span>
                <span><strong>Prohibido en el primer contacto:</strong> Decir que haces páginas web, dar precios o enseñar nada tuyo.</span>
              </li>
            </ul>
          </div>
        )}

        {/* Message editor */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <label className="font-medium text-neutral-300 flex items-center gap-1.5">
              <span>Texto del Mensaje</span>
              {lead.aiAudit && selectedTemplate === 'diagnostico' && (
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 inline-flex items-center gap-1">
                  <Sparkles className="w-2.5 h-2.5" />
                  Auditado con IA
                </span>
              )}
            </label>

            <button
              type="button"
              onClick={() => setMessage(getTemplateContent(selectedTemplate))}
              className="text-[11px] text-neutral-400 hover:text-emerald-400 underline cursor-pointer"
            >
              Restablecer borrador
            </button>
          </div>

          <textarea
            rows={7}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Escribe el mensaje..."
            className="w-full p-3.5 bg-neutral-950 border border-neutral-700 rounded-xl text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-emerald-500 leading-relaxed font-sans whitespace-pre-wrap resize-y"
          />

          <div className="flex items-center justify-between text-[11px] text-neutral-400">
            <span>{message.length} caracteres</span>
            <span className="text-emerald-400/90">Estructura del PDF respetada al enviar a WhatsApp</span>
          </div>
        </div>

        {/* CRM quick option */}
        <label className="flex items-center gap-2 text-xs text-neutral-300 cursor-pointer select-none bg-neutral-950/60 p-2.5 rounded-lg border border-neutral-800">
          <input
            type="checkbox"
            checked={markAsContacted}
            onChange={(e) => setMarkAsContacted(e.target.checked)}
            className="rounded bg-neutral-900 border-neutral-700 text-emerald-500 focus:ring-0 w-3.5 h-3.5 cursor-pointer"
          />
          <span>Marcar automáticamente este lead como «Contactado» en el CRM</span>
        </label>

        {/* Action buttons */}
        <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-neutral-800">
          <button
            type="button"
            onClick={handleCopy}
            className="px-4 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copiado</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copiar texto</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={handleOpenWhatsApp}
            disabled={!waUrl}
            className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 disabled:bg-neutral-800 disabled:text-neutral-500 text-neutral-950 font-semibold text-xs flex items-center gap-2 transition-colors cursor-pointer shadow-sm"
          >
            <Send className="w-4 h-4" />
            <span>Abrir en WhatsApp</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
