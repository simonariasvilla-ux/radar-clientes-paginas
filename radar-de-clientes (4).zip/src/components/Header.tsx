import React, { useState } from 'react';
import { ShieldCheck, AlertTriangle, Menu, Sparkles, Download, Loader2, Check } from 'lucide-react';
import { UserSettings } from '../types';

interface HeaderProps {
  currentView: 'search' | 'detail' | 'radar' | 'leads' | 'settings';
  settings: UserSettings;
  onOpenMobileMenu: () => void;
  selectedLeadName?: string;
}

const VIEW_TITLES: Record<string, { title: string; subtitle: string }> = {
  search: {
    title: 'Buscar Negocios',
    subtitle: 'Exploración directa con Google Places API (New)',
  },
  detail: {
    title: 'Ficha del Negocio',
    subtitle: 'Auditoría PageSpeed, diagnóstico Gemini y guiones de venta',
  },
  radar: {
    title: 'Radar de Nichos',
    subtitle: 'Análisis multi-sectorial comparativo e inteligencia de mercado',
  },
  leads: {
    title: 'Mis Leads',
    subtitle: 'Embudo de prospección, seguimiento comercial y exportación CSV',
  },
  settings: {
    title: 'Ajustes',
    subtitle: 'Configuración de API Keys, perfil de vendedor y cuota mensual',
  },
};

export const Header: React.FC<HeaderProps> = ({
  currentView,
  settings,
  onOpenMobileMenu,
  selectedLeadName,
}) => {
  const current = VIEW_TITLES[currentView] || VIEW_TITLES.search;
  const isNearLimit = settings.usageTracker.placesCallCount >= settings.usageTracker.alertThreshold;
  const [downloading, setDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const handleDownloadZip = async () => {
    try {
      setDownloading(true);
      const res = await fetch('/radar-de-clientes.zip');
      if (!res.ok) {
        throw new Error('No se pudo descargar el archivo');
      }
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'radar-de-clientes.zip';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3000);
    } catch (err) {
      console.error('Error al descargar ZIP:', err);
      // Fallback direct navigation
      window.location.href = '/radar-de-clientes.zip';
    } finally {
      setDownloading(false);
    }
  };

  return (
    <header className="h-16 border-b border-neutral-800 bg-neutral-900/80 backdrop-blur-md px-6 flex items-center justify-between shrink-0 no-print">
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobileMenu}
          className="md:hidden p-1.5 rounded-lg text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800"
          title="Abrir menú"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div>
          <h2 className="text-sm font-semibold text-neutral-100 flex items-center gap-2">
            <span>{currentView === 'detail' && selectedLeadName ? selectedLeadName : current.title}</span>
            {currentView === 'detail' && (
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
                Dossier
              </span>
            )}
          </h2>
          <p className="text-[11px] text-neutral-400 truncate max-w-md">{current.subtitle}</p>
        </div>
      </div>

      {/* Right zone: API usage pills & download action */}
      <div className="flex items-center gap-3">
        {/* Quick ZIP download for Vercel */}
        <button
          onClick={handleDownloadZip}
          disabled={downloading}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all shadow-sm ${
            downloadSuccess
              ? 'bg-emerald-500 text-neutral-950 font-bold'
              : 'bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40'
          }`}
          title="Descargar código completo .ZIP con vercel.json para subir a GitHub y Vercel"
        >
          {downloading ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-300" />
          ) : downloadSuccess ? (
            <Check className="w-3.5 h-3.5 text-neutral-950 stroke-[3]" />
          ) : (
            <Download className="w-3.5 h-3.5 text-emerald-400" />
          )}
          <span className="hidden sm:inline">
            {downloading ? 'Descargando...' : downloadSuccess ? '¡Descargado!' : 'Descargar ZIP (Vercel)'}
          </span>
        </button>

        <div
          className={`hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-mono tabular-nums ${
            isNearLimit
              ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
              : 'bg-neutral-950 border-neutral-800 text-neutral-300'
          }`}
          title="Consumo de llamadas a Google Places en el ciclo actual"
        >
          {isNearLimit ? (
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          ) : (
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          )}
          <span>
            Places:{' '}
            <strong className={isNearLimit ? 'text-amber-300' : 'text-neutral-100'}>
              {settings.usageTracker.placesCallCount}
            </strong>
            /{settings.usageTracker.monthlyFreeTierLimit}
          </span>
        </div>

        <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-neutral-950 border border-neutral-800 text-[11px] text-neutral-400">
          <Sparkles className="w-3 h-3 text-emerald-400" />
          <span>Gemini 3.8 Flash</span>
        </div>
      </div>
    </header>
  );
};
