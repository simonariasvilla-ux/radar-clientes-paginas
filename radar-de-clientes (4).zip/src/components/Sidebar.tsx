import React from 'react';
import {
  Search,
  Building2,
  Radar,
  Users,
  Settings,
  ShieldCheck,
  AlertTriangle,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { UserSettings } from '../types';

interface SidebarProps {
  currentView: 'search' | 'detail' | 'radar' | 'leads' | 'settings';
  onNavigate: (view: 'search' | 'detail' | 'radar' | 'leads' | 'settings') => void;
  selectedLeadId: string | null;
  savedLeadsCount: number;
  settings: UserSettings;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  selectedLeadId,
  savedLeadsCount,
  settings,
}) => {
  const { usageTracker, googleCloudApiKey } = settings;
  const isKeyConfigured = Boolean(googleCloudApiKey && googleCloudApiKey.trim().length > 5);
  const isNearLimit = usageTracker.placesCallCount >= usageTracker.alertThreshold;
  const quotaPercent = Math.min(
    100,
    Math.round((usageTracker.placesCallCount / usageTracker.monthlyFreeTierLimit) * 100)
  );

  const navItems = [
    {
      id: 'search' as const,
      label: 'Buscar Negocios',
      icon: Search,
      badge: null,
    },
    {
      id: 'detail' as const,
      label: 'Ficha del Negocio',
      icon: Building2,
      badge: selectedLeadId ? 'Activa' : null,
      disabled: !selectedLeadId,
    },
    {
      id: 'radar' as const,
      label: 'Radar de Nichos',
      icon: Radar,
      badge: 'IA',
    },
    {
      id: 'leads' as const,
      label: 'Mis Leads',
      icon: Users,
      badge: savedLeadsCount > 0 ? savedLeadsCount : null,
    },
    {
      id: 'settings' as const,
      label: 'Ajustes',
      icon: Settings,
      badge: !isKeyConfigured ? 'Clave requerida' : null,
    },
  ];

  return (
    <aside className="w-64 bg-neutral-900 border-r border-neutral-800 flex flex-col h-screen shrink-0 no-print select-none">
      {/* Brand Header */}
      <div className="h-16 px-5 border-b border-neutral-800 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold text-sm tracking-tight shadow-inner">
            RC
          </div>
          <div>
            <h1 className="font-semibold text-sm tracking-tight text-neutral-100 flex items-center gap-1.5">
              Radar de Clientes
            </h1>
            <p className="text-[11px] text-neutral-400">Prospección B2B Local</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        <div className="px-2 pb-2 text-[10px] font-semibold uppercase tracking-wider text-neutral-300">
          Operaciones
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          const isDisabled = item.disabled;

          return (
            <button
              key={item.id}
              onClick={() => !isDisabled && onNavigate(item.id)}
              disabled={isDisabled}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                isActive
                  ? 'bg-neutral-800 text-emerald-400 border border-neutral-700/80 shadow-sm'
                  : isDisabled
                  ? 'text-neutral-600 cursor-not-allowed'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Icon
                  className={`w-4 h-4 ${
                    isActive ? 'text-emerald-400' : isDisabled ? 'text-neutral-600' : 'text-neutral-400'
                  }`}
                />
                <span>{item.label}</span>
              </div>

              {item.badge && (
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${
                    item.badge === 'Clave requerida'
                      ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                      : isActive
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : 'bg-neutral-800 text-neutral-400 border border-neutral-700'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer Info & API Quota Monitor */}
      <div className="p-3 border-t border-neutral-800 space-y-3 bg-neutral-900/60">
        {/* Google Cloud Status */}
        <div className="px-3 py-2 rounded-lg bg-neutral-950/80 border border-neutral-800/80">
          <div className="flex items-center justify-between text-[11px] mb-1.5">
            <span className="text-neutral-400 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-neutral-400" />
              Places & PageSpeed
            </span>
            <span
              className={`font-medium ${
                isKeyConfigured ? 'text-emerald-400' : 'text-amber-400'
              }`}
            >
              {isKeyConfigured ? 'Conectada' : 'Sin clave'}
            </span>
          </div>

          {/* Places Calls Counter */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[10px] font-mono tabular-nums">
              <span className="text-neutral-300">Llamadas mes:</span>
              <span className={isNearLimit ? 'text-amber-400 font-semibold' : 'text-neutral-300'}>
                {usageTracker.placesCallCount} / {usageTracker.monthlyFreeTierLimit}
              </span>
            </div>
            <div className="w-full bg-neutral-800 rounded-full h-1.5 overflow-hidden">
              <div
                className={`h-full transition-all duration-300 ${
                  isNearLimit ? 'bg-amber-500' : 'bg-emerald-500'
                }`}
                style={{ width: `${quotaPercent}%` }}
              />
            </div>
          </div>

          {isNearLimit && (
            <div className="mt-2 text-[10px] text-amber-300 flex items-start gap-1">
              <AlertTriangle className="w-3 h-3 shrink-0 mt-0.5" />
              <span>Has superado el umbral de aviso ({usageTracker.alertThreshold} llamadas).</span>
            </div>
          )}

          {!isKeyConfigured && (
            <button
              onClick={() => onNavigate('settings')}
              className="mt-2 w-full text-center text-[11px] text-amber-400 hover:text-amber-300 underline underline-offset-2 flex items-center justify-center gap-1"
            >
              Configurar clave en Ajustes
              <ChevronRight className="w-3 h-3" />
            </button>
          )}
        </div>

        {/* Agency Info */}
        <div className="px-3 py-1.5 text-[11px] text-neutral-300 flex items-center justify-between">
          <span className="truncate">{settings.sellerProfile.agencyName || 'Mi Agencia'}</span>
          <span className="font-mono text-[10px] text-neutral-300">v1.0</span>
        </div>
      </div>
    </aside>
  );
};
