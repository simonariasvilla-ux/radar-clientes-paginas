import React, { useState } from 'react';
import {
  Settings,
  Key,
  Eye,
  EyeOff,
  Save,
  Check,
  AlertTriangle,
  RotateCcw,
  Download,
  Upload,
  Trash2,
  ExternalLink,
  ShieldCheck,
  Sparkles,
  User,
  Plus,
  X,
  Package,
  FileArchive,
  Loader2,
} from 'lucide-react';
import { UserSettings, SalesTone } from '../types';
import {
  saveSettings,
  exportDatabaseToJson,
  importDatabaseFromJson,
  clearCache,
} from '../services/storage';

interface SettingsViewProps {
  settings: UserSettings;
  onUpdateSettings: (s: UserSettings) => void;
  onDataImported: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  onDataImported,
}) => {
  const [apiKey, setApiKey] = useState(settings.googleCloudApiKey || '');
  const [showKey, setShowKey] = useState(false);
  const [testingKey, setTestingKey] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  // Seller Profile
  const [sellerName, setSellerName] = useState(settings.sellerProfile.name);
  const [agencyName, setAgencyName] = useState(settings.sellerProfile.agencyName);
  const [uniqueValueProp, setUniqueValueProp] = useState(settings.sellerProfile.uniqueValueProp);
  const [defaultTone, setDefaultTone] = useState<SalesTone>(settings.sellerProfile.defaultTone);
  const [services, setServices] = useState<string[]>(settings.sellerProfile.servicesOffered || []);
  const [newServiceInput, setNewServiceInput] = useState('');

  // Usage Tracker
  const [placesCalls, setPlacesCalls] = useState(settings.usageTracker.placesCallCount);
  const [freeLimit, setFreeLimit] = useState(settings.usageTracker.monthlyFreeTierLimit);
  const [alertThreshold, setAlertThreshold] = useState(settings.usageTracker.alertThreshold);

  // Feedback states
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [zipSuccess, setZipSuccess] = useState(false);

  const handleDownloadZip = async () => {
    try {
      setDownloadingZip(true);
      const res = await fetch('/radar-de-clientes.zip');
      if (!res.ok) throw new Error('Error al descargar ZIP');
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'radar-de-clientes.zip';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      setZipSuccess(true);
      setTimeout(() => setZipSuccess(false), 3000);
    } catch (err) {
      console.error('Error al descargar:', err);
      window.location.href = '/radar-de-clientes.zip';
    } finally {
      setDownloadingZip(false);
    }
  };

  const handleSaveAll = async () => {
    const updated: UserSettings = {
      ...settings,
      googleCloudApiKey: apiKey.trim(),
      sellerProfile: {
        name: sellerName.trim(),
        agencyName: agencyName.trim(),
        uniqueValueProp: uniqueValueProp.trim(),
        defaultTone,
        servicesOffered: services,
      },
      usageTracker: {
        ...settings.usageTracker,
        placesCallCount: placesCalls,
        monthlyFreeTierLimit: freeLimit,
        alertThreshold,
      },
    };

    await saveSettings(updated);
    onUpdateSettings(updated);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleTestKey = async () => {
    if (!apiKey.trim()) {
      setTestResult({
        success: false,
        message: 'Por favor, escribe primero una clave de Google Cloud.',
      });
      return;
    }

    setTestingKey(true);
    setTestResult(null);

    try {
      const response = await fetch('/api/places/search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-google-cloud-key': apiKey.trim(),
        },
        body: JSON.stringify({
          textQuery: 'talleres en Madrid',
          apiKey: apiKey.trim(),
        }),
      });

      const data = await response.json();

      if (response.ok && data.places) {
        setTestResult({
          success: true,
          message: '¡Conexión verificada con éxito! La Places API respondió correctamente.',
        });
      } else {
        setTestResult({
          success: false,
          message: data.error || 'La clave fue rechazada por Google Cloud. Revisa que tenga Places API (New) activada.',
        });
      }
    } catch (err: any) {
      setTestResult({
        success: false,
        message: `Error al probar la clave: ${err.message}`,
      });
    } finally {
      setTestingKey(false);
    }
  };

  const handleAddService = () => {
    if (!newServiceInput.trim()) return;
    setServices([...services, newServiceInput.trim()]);
    setNewServiceInput('');
  };

  const handleRemoveService = (idx: number) => {
    setServices(services.filter((_, i) => i !== idx));
  };

  const handleResetCounter = () => {
    if (window.confirm('¿Deseas reiniciar a 0 el contador de llamadas de Places de este mes?')) {
      setPlacesCalls(0);
    }
  };

  const handleExportJson = async () => {
    const jsonStr = await exportDatabaseToJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `backup_radar_clientes_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleImportJson = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const res = await importDatabaseFromJson(text);
      setImportStatus(`Copia restaurada: ${res.leadsImported} leads importados con éxito.`);
      onDataImported();
      setTimeout(() => setImportStatus(null), 4000);
    } catch (err: any) {
      setImportStatus(`Error al importar copia: ${err.message}`);
    }
  };

  const handleClearCache = async () => {
    if (window.confirm('¿Vaciar la caché de búsquedas? Las siguientes búsquedas volverán a consultar la API.')) {
      await clearCache();
      alert('Caché local vaciada correctamente.');
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-16">
      {/* Title */}
      <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between shadow-sm">
        <div>
          <h2 className="text-base font-semibold text-neutral-100 flex items-center gap-2">
            <Settings className="w-4 h-4 text-emerald-400" />
            Ajustes del Sistema y Perfil Comercial
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Configura tu clave de Google Cloud, tus datos de vendedor y el control de llamadas mensuales.
          </p>
        </div>

        <button
          onClick={handleSaveAll}
          className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-neutral-950 font-semibold rounded-lg text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
        >
          {savedSuccess ? (
            <>
              <Check className="w-4 h-4 text-neutral-950" />
              <span>¡Guardado!</span>
            </>
          ) : (
            <>
              <Save className="w-4 h-4" />
              <span>Guardar Ajustes</span>
            </>
          )}
        </button>
      </div>

      {/* 1. Google Cloud Key Config */}
      <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-4 shadow-sm">
        <div className="border-b border-neutral-800 pb-3">
          <h3 className="font-semibold text-sm text-neutral-100 flex items-center gap-2">
            <Key className="w-4 h-4 text-emerald-400" />
            Clave de Google Cloud (Places API New & PageSpeed Insights)
          </h3>
          <p className="text-xs text-neutral-400 mt-0.5">
            Se almacena únicamente en tu navegador. Gemini utiliza la clave inyectada por el entorno.
          </p>
        </div>

        <div className="space-y-3">
          <div className="space-y-1">
            <label className="text-[11px] font-medium text-neutral-300">
              API Key de Google Cloud
            </label>
            <div className="relative">
              <input
                type={showKey ? 'text' : 'password'}
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="AIzaSy..."
                className="w-full pl-3 pr-20 py-2 bg-neutral-950 border border-neutral-700 rounded-lg text-xs font-mono text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
              />
              <div className="absolute right-2 top-2 flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setShowKey(!showKey)}
                  className="p-1 text-neutral-400 hover:text-neutral-200"
                  title={showKey ? 'Ocultar clave' : 'Mostrar clave'}
                >
                  {showKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2">
            <button
              onClick={handleTestKey}
              disabled={testingKey}
              className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs rounded-lg border border-neutral-700 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {testingKey ? (
                <>
                  <RotateCcw className="w-3.5 h-3.5 animate-spin text-emerald-400" />
                  <span>Comprobando conexión...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Probar Clave Ahora</span>
                </>
              )}
            </button>

            <a
              href="https://console.cloud.google.com/apis/credentials"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[11px] text-neutral-400 hover:text-emerald-400 inline-flex items-center gap-1"
            >
              <span>Abrir consola de Google Cloud</span>
              <ExternalLink className="w-2.5 h-2.5" />
            </a>
          </div>

          {testResult && (
            <div
              className={`p-3 rounded-lg text-xs flex items-start gap-2 border ${
                testResult.success
                  ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20'
                  : 'bg-rose-500/10 text-rose-300 border-rose-500/20'
              }`}
            >
              {testResult.success ? (
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              )}
              <span>{testResult.message}</span>
            </div>
          )}
        </div>
      </div>

      {/* 2. Monthly Places Usage Counter & Threshold */}
      <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-4 shadow-sm">
        <div className="border-b border-neutral-800 pb-3">
          <h3 className="font-semibold text-sm text-neutral-100 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            Control de Cuota Mensual de Places API (New)
          </h3>
          <p className="text-xs text-neutral-400 mt-0.5">
            Google Cloud ofrece saldo gratuito mensual. El contador te avisa antes de agotar tu cupo.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="space-y-1">
            <label className="text-[11px] font-medium text-neutral-300">
              Llamadas gastadas ({settings.usageTracker.monthYear})
            </label>
            <input
              type="number"
              min="0"
              value={placesCalls}
              onChange={(e) => setPlacesCalls(Number(e.target.value))}
              className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-lg text-xs font-mono text-neutral-100 focus:outline-none"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-medium text-neutral-300">
              Umbral de Alerta Temprana
            </label>
            <input
              type="number"
              min="1"
              value={alertThreshold}
              onChange={(e) => setAlertThreshold(Number(e.target.value))}
              className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-lg text-xs font-mono text-neutral-100 focus:outline-none"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-medium text-neutral-300">
              Límite Gratuito Mensual
            </label>
            <input
              type="number"
              min="1"
              value={freeLimit}
              onChange={(e) => setFreeLimit(Number(e.target.value))}
              className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-lg text-xs font-mono text-neutral-100 focus:outline-none"
            />
          </div>
        </div>

        <div className="flex items-center justify-between pt-1">
          <div className="text-xs text-neutral-400 font-mono">
            {placesCalls >= alertThreshold ? (
              <span className="text-amber-400 font-semibold flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" />
                Has alcanzado {placesCalls} de {freeLimit} llamadas este mes.
              </span>
            ) : (
              <span className="text-emerald-400">
                Consumo seguro: {freeLimit - placesCalls} llamadas restantes antes del límite.
              </span>
            )}
          </div>

          <button
            onClick={handleResetCounter}
            className="text-xs text-neutral-400 hover:text-neutral-200 underline"
          >
            Reiniciar contador a 0
          </button>
        </div>
      </div>

      {/* 3. Seller Profile (Used by Gemini for pitches) */}
      <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-4 shadow-sm">
        <div className="border-b border-neutral-800 pb-3">
          <h3 className="font-semibold text-sm text-neutral-100 flex items-center gap-2">
            <User className="w-4 h-4 text-emerald-400" />
            Mi Perfil de Vendedor / Agencia
          </h3>
          <p className="text-xs text-neutral-400 mt-0.5">
            Gemini Flash utiliza esta información para personalizar los 3 borradores de venta (llamada, WhatsApp y correo).
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-[11px] font-medium text-neutral-300">Tu Nombre Comercial</label>
            <input
              type="text"
              value={sellerName}
              onChange={(e) => setSellerName(e.target.value)}
              placeholder="Ej. Carlos Mendoza"
              className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-lg text-xs text-neutral-100 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-medium text-neutral-300">Nombre de la Agencia</label>
            <input
              type="text"
              value={agencyName}
              onChange={(e) => setAgencyName(e.target.value)}
              placeholder="Ej. Impulso Local Studio"
              className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-lg text-xs text-neutral-100 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="sm:col-span-2 space-y-1">
            <label className="text-[11px] font-medium text-neutral-300">
              Propuesta de Valor Única (Gancho Comercial)
            </label>
            <textarea
              rows={2}
              value={uniqueValueProp}
              onChange={(e) => setUniqueValueProp(e.target.value)}
              placeholder="Ej. Aumentamos un 35% las citas y clientes cerrados sin aumentar el presupuesto en publicidad."
              className="w-full p-2.5 bg-neutral-950 border border-neutral-700 rounded-lg text-xs text-neutral-100 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-medium text-neutral-300">
              Tono de Comunicación por Defecto
            </label>
            <select
              value={defaultTone}
              onChange={(e) => setDefaultTone(e.target.value as SalesTone)}
              className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-lg text-xs text-neutral-200 focus:outline-none focus:border-emerald-500"
            >
              <option value="directo">Directo (Al grano, orientado a resultados)</option>
              <option value="consultivo">Consultivo (Auditoría desinteresada y consejo experto)</option>
              <option value="cercano">Cercano (Empatía local y tono humano de barrio)</option>
              <option value="persuasivo">Persuasivo (Foco en el coste de oportunidad y pérdida de clientes)</option>
            </select>
          </div>

          {/* Services offered tags */}
          <div className="sm:col-span-2 space-y-2">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-neutral-300 font-medium">Servicios que ofreces:</span>
              <div className="flex items-center gap-1.5">
                <input
                  type="text"
                  value={newServiceInput}
                  onChange={(e) => setNewServiceInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddService()}
                  placeholder="Añadir otro servicio..."
                  className="px-2 py-1 bg-neutral-950 border border-neutral-700 rounded text-xs text-neutral-200 focus:outline-none"
                />
                <button
                  onClick={handleAddService}
                  className="p-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {services.map((srv, idx) => (
                <span
                  key={idx}
                  className="inline-flex items-center gap-1.5 text-xs px-2.5 py-1 rounded bg-neutral-950 text-neutral-200 border border-neutral-800"
                >
                  <span>{srv}</span>
                  <button
                    onClick={() => handleRemoveService(idx)}
                    className="text-neutral-500 hover:text-rose-400"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 4. Local Database Backup & Cache Management */}
      <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-4 shadow-sm">
        <div className="border-b border-neutral-800 pb-3">
          <h3 className="font-semibold text-sm text-neutral-100 flex items-center gap-2">
            <Download className="w-4 h-4 text-emerald-400" />
            Copia de Seguridad y Mantenimiento de Datos (IndexedDB)
          </h3>
          <p className="text-xs text-neutral-400 mt-0.5">
            Exporta tus leads con sus auditorías completas a un archivo JSON o restaura datos previos.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={handleExportJson}
            className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium rounded-lg border border-neutral-700 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>Descargar Copia JSON</span>
          </button>

          <label className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium rounded-lg border border-neutral-700 flex items-center gap-1.5 transition-colors cursor-pointer">
            <Upload className="w-3.5 h-3.5 text-emerald-400" />
            <span>Restaurar Copia JSON</span>
            <input
              type="file"
              accept=".json"
              onChange={handleImportJson}
              className="hidden"
            />
          </label>

          <button
            onClick={handleClearCache}
            className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium rounded-lg border border-neutral-700 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5 text-neutral-400" />
            <span>Vaciar Caché de Búsquedas</span>
          </button>
        </div>

        {importStatus && (
          <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-emerald-300">
            {importStatus}
          </div>
        )}
      </div>

      {/* 5. Descargar Proyecto Completo para Vercel */}
      <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-4 shadow-sm">
        <div className="border-b border-neutral-800 pb-3 flex items-start justify-between gap-3">
          <div>
            <h3 className="font-semibold text-sm text-neutral-100 flex items-center gap-2">
              <Package className="w-4 h-4 text-emerald-400" />
              Descargar Carpeta Completa del Proyecto (.ZIP para Vercel)
            </h3>
            <p className="text-xs text-neutral-400 mt-0.5">
              Empaquetado listo para subir directamente a Vercel con configuración serverless (<code className="text-neutral-300">vercel.json</code> y <code className="text-neutral-300">/api</code>) incluida.
            </p>
          </div>

          <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
            Vercel Ready
          </span>
        </div>

        <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="text-xs font-semibold text-neutral-200 flex items-center gap-1.5">
                <FileArchive className="w-4 h-4 text-emerald-400" />
                <span>radar-de-clientes.zip</span>
                <span className="text-neutral-500 font-mono text-[11px]">(código fuente completo)</span>
              </div>
              <p className="text-[11px] text-neutral-400">
                Incluye todos los componentes React, el router serverless de Gemini y Places API, Tailwind v4 y Vite.
              </p>
            </div>

            <button
              onClick={handleDownloadZip}
              disabled={downloadingZip}
              className={`px-4 py-2 font-bold text-xs rounded-lg inline-flex items-center justify-center gap-2 transition-all shrink-0 shadow-sm ${
                zipSuccess
                  ? 'bg-emerald-400 text-neutral-950'
                  : 'bg-emerald-500 hover:bg-emerald-600 text-neutral-950'
              }`}
            >
              {downloadingZip ? (
                <Loader2 className="w-4 h-4 animate-spin text-neutral-950" />
              ) : zipSuccess ? (
                <Check className="w-4 h-4 stroke-[3]" />
              ) : (
                <Download className="w-4 h-4" />
              )}
              <span>{downloadingZip ? 'Descargando...' : zipSuccess ? '¡Descargado!' : 'Descargar .ZIP'}</span>
            </button>
          </div>

          <div className="pt-2 border-t border-neutral-800/80 text-[11px] text-neutral-400 space-y-1">
            <div className="font-semibold text-neutral-300">Instrucciones para Vercel:</div>
            <ol className="list-decimal list-inside space-y-0.5 pl-1">
              <li>Descomprime el archivo o súbelo a un repositorio de GitHub.</li>
              <li>En Vercel, importa el proyecto y mantén el Framework Preset en <strong>Vite</strong>.</li>
              <li>Añade la variable de entorno <code className="text-emerald-400 font-mono">GEMINI_API_KEY</code> en Vercel Settings &gt; Environment Variables.</li>
              <li>Haz clic en <strong>Deploy</strong> y estará en línea en segundos.</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
};
