import React, { useState } from 'react';
import {
  Building2,
  Phone,
  Globe,
  MapPin,
  Star,
  ExternalLink,
  RotateCw,
  Sparkles,
  CheckCircle2,
  XCircle,
  Copy,
  Check,
  Printer,
  Calendar,
  MessageSquare,
  Mail,
  Flame,
  AlertTriangle,
  FileText,
  Save,
  Clock,
  ArrowLeft,
  ChevronDown,
  Stethoscope,
  Send,
  Calculator,
  HelpCircle,
  Info,
  ShieldAlert,
  Users,
} from 'lucide-react';
import { BusinessLead, UserSettings, SalesTone, RecommendedService } from '../types';
import { calculateOpportunityScore } from '../services/scoring';
import { PageSpeedGauges } from '../components/PageSpeedGauges';
import { ScoreBadge } from '../components/ScoreBadge';
import { saveLead } from '../services/storage';
import {
  buildWhatsAppUrl,
  getDefaultWhatsAppTemplate,
  getDoctorInPersonScript,
  getDoctorCallScript,
  getDoctorObjectionTemplate,
  getDoctorMonthlyReviewTemplate,
} from '../utils/whatsapp';
import { WhatsAppModal } from '../components/WhatsAppModal';

interface BusinessDetailViewProps {
  lead: BusinessLead;
  settings: UserSettings;
  onBack: () => void;
  onLeadUpdated: (lead: BusinessLead) => void;
}

export const BusinessDetailView: React.FC<BusinessDetailViewProps> = ({
  lead,
  settings,
  onBack,
  onLeadUpdated,
}) => {
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [analysisSeconds, setAnalysisSeconds] = useState(0);

  // CRM State
  const [crmStatus, setCrmStatus] = useState(lead.crm.status || 'nuevo');
  const [crmNotes, setCrmNotes] = useState(lead.crm.notes || '');
  const [crmNextDate, setCrmNextDate] = useState(lead.crm.nextActionDate || '');
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Script tone & copying state
  const [selectedTone, setSelectedTone] = useState<SalesTone>(
    settings.sellerProfile.defaultTone || 'consultivo'
  );
  const [regeneratingTone, setRegeneratingTone] = useState(false);
  const [copiedDraft, setCopiedDraft] = useState<string | null>(null);
  const [previewScreenshot, setPreviewScreenshot] = useState(false);
  const [isWhatsAppModalOpen, setIsWhatsAppModalOpen] = useState(false);

  // Tab for Doctor Method Contact Scripts
  const [activeContactTab, setActiveContactTab] = useState<
    'whatsapp' | 'call' | 'inperson' | 'objection' | 'email' | 'monthly'
  >('whatsapp');

  // Interactive "La cuenta ya hecha" ticket
  const [avgTicket, setAvgTicket] = useState<number>(
    lead.aiAudit?.salesDrafts?.prescription?.theMathDone?.avgTicketPerClient || 150
  );

  // Direct WhatsApp open helper
  const handleDirectWhatsApp = (customText?: string) => {
    const phone = lead.nationalPhoneNumber || lead.internationalPhoneNumber;
    if (!phone) {
      alert('Este negocio no tiene teléfono registrado para contactar por WhatsApp.');
      return;
    }
    const message = customText || lead.aiAudit?.salesDrafts?.whatsAppMessage || '';
    const url = buildWhatsAppUrl(phone, message);
    if (url) {
      window.open(url, '_blank', 'noopener,noreferrer');
      // Suggest moving to contactado
      if (crmStatus === 'nuevo' || crmStatus === 'analizado') {
        setCrmStatus('contactado');
        const updated = {
          ...lead,
          crm: { ...lead.crm, status: 'contactado' as const },
        };
        saveLead(updated);
        onLeadUpdated(updated);
      }
    }
  };

  // Analyze website or generate digital proposal
  const handleAnalyzeWeb = async () => {
    setAnalyzing(true);
    setAnalysisError(null);
    setAnalysisSeconds(0);

    const timer = setInterval(() => {
      setAnalysisSeconds((sec) => sec + 1);
    }, 1000);

    try {
      let pageSpeedAudit;

      // 1. Run PageSpeed if it has an own website
      if (lead.websiteUri && lead.websiteType === 'own_domain') {
        try {
          const psResponse = await fetch('/api/pagespeed/analyze', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'x-google-cloud-key': settings.googleCloudApiKey || '',
            },
            body: JSON.stringify({
              url: lead.websiteUri,
              apiKey: settings.googleCloudApiKey,
            }),
          });

          if (psResponse.ok) {
            const psData = await psResponse.json();
            pageSpeedAudit = {
              analyzedAt: psData.analyzedAt,
              scores: psData.scores,
              screenshotBase64: psData.screenshotBase64,
              testedUrl: psData.testedUrl,
            };
          } else {
            console.warn('PageSpeed no pudo analizar el sitio');
          }
        } catch (e) {
          console.warn('Error en llamada PageSpeed:', e);
        }
      }

      // 2. Gemini Analysis with urlContext
      const geminiResponse = await fetch('/api/gemini/analyze-business', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          businessName: lead.displayName,
          category: lead.primaryTypeDisplayName || lead.searchQueryNiche,
          address: lead.formattedAddress,
          phone: lead.nationalPhoneNumber || lead.internationalPhoneNumber,
          websiteUri: lead.websiteUri,
          hasOwnWebsite: lead.websiteType === 'own_domain',
          sellerProfile: {
            ...settings.sellerProfile,
            defaultTone: selectedTone,
          },
          pageSpeedScores: pageSpeedAudit?.scores,
          rating: lead.rating,
          reviewsCount: lead.userRatingCount,
        }),
      });

      const geminiData = await geminiResponse.json();

      if (!geminiResponse.ok) {
        throw new Error(geminiData.error || 'Error al procesar el análisis de Gemini.');
      }

      const aiAudit = geminiData.audit;

      // 3. Recalculate score
      const scoreResult = calculateOpportunityScore(lead, pageSpeedAudit, aiAudit);

      const updatedLead: BusinessLead = {
        ...lead,
        pageSpeedAudit,
        aiAudit,
        opportunityScore: scoreResult.score,
        scoreBreakdown: scoreResult.breakdown,
        isProvisionalScore: scoreResult.isProvisional,
        crm: {
          ...lead.crm,
          status: lead.crm.status === 'nuevo' ? 'analizado' : lead.crm.status,
          savedAt: lead.crm.savedAt || new Date().toISOString(),
          notes: crmNotes,
          nextActionDate: crmNextDate,
        },
      };

      await saveLead(updatedLead);
      onLeadUpdated(updatedLead);
      setCrmStatus(updatedLead.crm.status);
    } catch (err: any) {
      console.error('Error al analizar negocio:', err);
      setAnalysisError(err.message || 'Error durante la auditoría del negocio.');
    } finally {
      clearInterval(timer);
      setAnalyzing(false);
    }
  };

  // Regenerate pitch with another tone
  const handleRegenerateTone = async (newTone: SalesTone) => {
    setSelectedTone(newTone);
    if (!lead.aiAudit) return;

    setRegeneratingTone(true);
    try {
      const response = await fetch('/api/gemini/regenerate-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          businessName: lead.displayName,
          businessSummary: lead.aiAudit.businessSummary,
          painPoints: lead.aiAudit.painPoints,
          recommendedService: lead.aiAudit.recommendedService,
          sellerProfile: settings.sellerProfile,
          tone: newTone,
        }),
      });

      const data = await response.json();
      if (response.ok && data.drafts) {
        const updatedLead: BusinessLead = {
          ...lead,
          aiAudit: {
            ...lead.aiAudit,
            salesDrafts: data.drafts,
          },
        };
        await saveLead(updatedLead);
        onLeadUpdated(updatedLead);
      }
    } catch (err) {
      console.error('Error al regenerar:', err);
    } finally {
      setRegeneratingTone(false);
    }
  };

  // Save CRM changes
  const handleSaveCrm = async () => {
    const updatedLead: BusinessLead = {
      ...lead,
      crm: {
        ...lead.crm,
        status: crmStatus,
        notes: crmNotes,
        nextActionDate: crmNextDate,
        savedAt: lead.crm.savedAt || new Date().toISOString(),
      },
    };
    await saveLead(updatedLead);
    onLeadUpdated(updatedLead);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  // Copy helper
  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedDraft(type);
    setTimeout(() => setCopiedDraft(null), 2000);
  };

  // Print / Export PDF
  const handlePrint = () => {
    window.print();
  };

  const serviceLabels: Record<RecommendedService, string> = {
    web_moderna: 'Página Web Moderna y Rápida',
    agente_whatsapp: 'Agente de IA para WhatsApp 24/7',
    sistema_citas: 'Sistema de Reservas y Citas Online',
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-16">
      {/* Top action bar */}
      <div className="flex items-center justify-between gap-3 no-print">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-neutral-400 hover:text-neutral-100 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Volver a la búsqueda</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrint}
            className="px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 text-neutral-200 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-neutral-400" />
            <span>Exportar ficha (PDF / Imprimir)</span>
          </button>
        </div>
      </div>

      {/* Main Business Dossier Card */}
      <div className="p-6 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-6 shadow-sm">
        {/* Header Title & Status */}
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 border-b border-neutral-800 pb-5">
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-xl font-bold text-neutral-100 tracking-tight">
                {lead.displayName}
              </h2>
              {lead.primaryTypeDisplayName && (
                <span className="text-xs px-2.5 py-0.5 rounded bg-neutral-800 text-neutral-300 border border-neutral-700">
                  {lead.primaryTypeDisplayName}
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5 text-xs text-neutral-400">
              <MapPin className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
              <span>{lead.formattedAddress}</span>
            </div>
          </div>

          {/* Opportunity score & badges */}
          <div className="flex items-center gap-3">
            <div className="text-right">
              <div className="text-[10px] uppercase tracking-wider text-neutral-400 font-medium">
                Puntuación Oportunidad
              </div>
              <ScoreBadge
                score={lead.opportunityScore}
                isProvisional={lead.isProvisionalScore}
                breakdown={lead.scoreBreakdown}
                size="lg"
                showDetailsToggle={true}
              />
            </div>
          </div>
        </div>

        {/* Contact Action Strip */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Teléfono y WhatsApp */}
          <div className="p-3 rounded-xl bg-neutral-950/70 border border-neutral-800/80 flex items-center justify-between gap-2">
            <div className="space-y-0.5 min-w-0">
              <div className="text-[10px] text-neutral-400 font-medium">Contacto Telefónico & WhatsApp</div>
              <div className="font-mono text-xs font-semibold text-neutral-200 truncate">
                {lead.nationalPhoneNumber || lead.internationalPhoneNumber || 'No disponible'}
              </div>
            </div>
            {(lead.nationalPhoneNumber || lead.internationalPhoneNumber) && (
              <div className="flex items-center gap-1.5 shrink-0">
                <a
                  href={`tel:${lead.nationalPhoneNumber || lead.internationalPhoneNumber}`}
                  className="px-2.5 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 text-xs font-medium inline-flex items-center gap-1 transition-colors"
                  title="Llamar directamente"
                >
                  <Phone className="w-3 h-3 text-neutral-300" />
                  <span className="hidden sm:inline">Llamar</span>
                </a>

                <button
                  onClick={() => setIsWhatsAppModalOpen(true)}
                  className="px-2.5 py-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30 text-xs font-medium inline-flex items-center gap-1 transition-colors cursor-pointer"
                  title="Escribir mensaje personalizado por WhatsApp"
                >
                  <MessageSquare className="w-3 h-3 text-emerald-400" />
                  <span>WhatsApp</span>
                </button>
              </div>
            )}
          </div>

          {/* Web */}
          <div className="p-3 rounded-xl bg-neutral-950/70 border border-neutral-800/80 flex items-center justify-between">
            <div className="space-y-0.5 max-w-[170px]">
              <div className="text-[10px] text-neutral-400 font-medium">Sitio Web</div>
              <div className="text-xs text-neutral-200 truncate font-mono">
                {lead.websiteUri
                  ? lead.websiteUri.replace(/^https?:\/\/(www\.)?/, '')
                  : 'Sin web registrada'}
              </div>
            </div>
            {lead.websiteUri && (
              <a
                href={lead.websiteUri}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium inline-flex items-center gap-1 transition-colors"
              >
                <Globe className="w-3 h-3 text-neutral-400" />
                <span>Visitar</span>
              </a>
            )}
          </div>

          {/* Google Maps */}
          <div className="p-3 rounded-xl bg-neutral-950/70 border border-neutral-800/80 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="text-[10px] text-neutral-400 font-medium">Google Maps</div>
              <div className="flex items-center gap-1 text-xs text-amber-400 font-mono">
                {lead.rating ? (
                  <>
                    <Star className="w-3 h-3 fill-amber-400" />
                    <span>{lead.rating.toFixed(1)}</span>
                    <span className="text-neutral-500">({lead.userRatingCount} reseñas)</span>
                  </>
                ) : (
                  <span className="text-neutral-500">Sin reseñas</span>
                )}
              </div>
            </div>
            <a
              href={lead.googleMapsUri}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium inline-flex items-center gap-1 transition-colors"
            >
              <span>Ficha</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>

        {/* Web Analysis Section (Auditoría Web & Gemini) */}
        <div className="p-5 rounded-xl bg-neutral-950/80 border border-neutral-800 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-800/80 pb-3">
            <div>
              <h3 className="font-semibold text-sm text-neutral-100 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                Auditoría Digital Integral
              </h3>
              <p className="text-xs text-neutral-400">
                PageSpeed Insights v5 (Móvil) + Gemini 3.8 Flash con URL context.
              </p>
            </div>

            <button
              onClick={handleAnalyzeWeb}
              disabled={analyzing}
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 disabled:bg-neutral-800 disabled:text-neutral-500 text-neutral-950 font-semibold rounded-lg text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shrink-0 shadow-sm"
            >
              {analyzing ? (
                <>
                  <RotateCw className="w-3.5 h-3.5 animate-spin" />
                  <span>
                    Analizando ({analysisSeconds}s / 10-30s est.)...
                  </span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{lead.aiAudit ? 'Re-analizar Web' : 'Analizar Web con IA'}</span>
                </>
              )}
            </button>
          </div>

          {analysisError && (
            <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{analysisError}</span>
            </div>
          )}

          {/* Results of Audit */}
          {lead.aiAudit ? (
            <div className="space-y-6">
              {/* Summary and Recommended Service */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2 p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-2">
                  <div className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400">
                    A qué se dedica el negocio
                  </div>
                  <p className="text-xs text-neutral-200 leading-relaxed">
                    {lead.aiAudit.businessSummary}
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/30 space-y-1.5">
                  <div className="text-[11px] font-semibold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                    <Flame className="w-3.5 h-3.5 text-emerald-400" />
                    Servicio a Ofrecer
                  </div>
                  <div className="text-sm font-bold text-neutral-100">
                    {serviceLabels[lead.aiAudit.recommendedService] || 'Página Web Moderna'}
                  </div>
                  <p className="text-[11px] text-neutral-300 leading-snug">
                    {lead.aiAudit.recommendedServiceReason}
                  </p>
                </div>
              </div>

              {/* PageSpeed Gauges & Screenshot (if available) */}
              {lead.pageSpeedAudit && (
                <div className="space-y-3">
                  <div className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400">
                    Puntuaciones Oficiales Google PageSpeed (Estrategia Móvil)
                  </div>
                  <PageSpeedGauges scores={lead.pageSpeedAudit.scores} />

                  {lead.pageSpeedAudit.screenshotBase64 && (
                    <div className="pt-2">
                      <div className="flex items-center justify-between text-xs text-neutral-400 mb-1.5">
                        <span>Captura real de pantalla capturada por Lighthouse:</span>
                        <button
                          onClick={() => setPreviewScreenshot(!previewScreenshot)}
                          className="text-emerald-400 hover:text-emerald-300 underline"
                        >
                          {previewScreenshot ? 'Ocultar vista ampliada' : 'Ver captura completa'}
                        </button>
                      </div>
                      <div className="border border-neutral-800 rounded-lg overflow-hidden bg-neutral-950 p-2 max-w-sm">
                        <img
                          src={lead.pageSpeedAudit.screenshotBase64}
                          alt={`Captura web de ${lead.displayName}`}
                          referrerPolicy="no-referrer"
                          className="w-full h-auto rounded object-cover shadow"
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Tech Checklist */}
              <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-3">
                <div className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400">
                  Lista de Comprobación Tecnológica
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
                  <div className="flex items-center gap-2">
                    {lead.aiAudit.checklist.hasHttps ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    )}
                    <span className="text-neutral-300">Conexión HTTPS Segura</span>
                  </div>

                  <div className="flex items-center gap-2">
                    {lead.aiAudit.checklist.isMobileResponsive ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    )}
                    <span className="text-neutral-300">Adaptada a Móvil</span>
                  </div>

                  <div className="flex items-center gap-2">
                    {lead.aiAudit.checklist.hasWhatsAppButton ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    )}
                    <span className="text-neutral-300">Botón Flotante WhatsApp</span>
                  </div>

                  <div className="flex items-center gap-2">
                    {lead.aiAudit.checklist.hasOnlineBooking ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    )}
                    <span className="text-neutral-300">Citas / Reservas Online</span>
                  </div>

                  <div className="flex items-center gap-2">
                    {lead.aiAudit.checklist.hasContactForm ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    )}
                    <span className="text-neutral-300">Formulario de Contacto</span>
                  </div>

                  <div className="flex items-center gap-2">
                    {lead.aiAudit.checklist.isOutdated ? (
                      <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                    ) : (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    )}
                    <span className="text-neutral-300">
                      Copyright:{' '}
                      <strong className="text-neutral-200">
                        {lead.aiAudit.checklist.copyrightYear || 'No detectado'}
                      </strong>
                    </span>
                  </div>
                </div>

                {/* Emails and Socials found */}
                {(lead.aiAudit.extractedEmails.length > 0 ||
                  lead.aiAudit.extractedSocials.length > 0) && (
                  <div className="pt-2 border-t border-neutral-800/80 flex flex-wrap gap-4 text-[11px] text-neutral-400">
                    {lead.aiAudit.extractedEmails.length > 0 && (
                      <div>
                        <span className="font-semibold text-neutral-300">Correos detectados: </span>
                        {lead.aiAudit.extractedEmails.map((email) => (
                          <a
                            key={email}
                            href={`mailto:${email}`}
                            className="text-emerald-400 hover:underline mr-2"
                          >
                            {email}
                          </a>
                        ))}
                      </div>
                    )}
                    {lead.aiAudit.extractedSocials.length > 0 && (
                      <div>
                        <span className="font-semibold text-neutral-300">Redes sociales: </span>
                        {lead.aiAudit.extractedSocials.map((soc) => (
                          <a
                            key={soc}
                            href={soc}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-emerald-400 hover:underline mr-2 truncate max-w-[150px] inline-block align-bottom"
                          >
                            {soc.replace(/^https?:\/\/(www\.)?/, '')}
                          </a>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* 3 to 5 Plain language problems */}
              <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-2.5">
                <div className="text-[11px] font-semibold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                  Problemas Detectados (Explicados en Lenguaje Llano para el Dueño)
                </div>
                <div className="space-y-2">
                  {lead.aiAudit.painPoints.map((point, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-lg bg-neutral-950/60 border border-neutral-800/80 text-xs text-neutral-300 flex items-start gap-2.5"
                    >
                      <span className="font-mono text-[11px] font-bold text-rose-400 shrink-0 mt-0.5">
                        {idx + 1}.
                      </span>
                      <span>{point}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center space-y-2 text-neutral-400">
              <p className="text-xs">
                Pulsa en «Analizar Web con IA» para medir la velocidad móvil en PageSpeed y activar a
                Gemini para diagnosticar problemas y generar los 3 borradores de venta a medida.
              </p>
              {lead.websiteType !== 'own_domain' && (
                <p className="text-[11px] text-amber-400/90 font-medium">
                  {lead.websiteType === 'none'
                    ? 'Este negocio no tiene web registrada. La IA preparará los borradores para vender su primera web profesional.'
                    : 'Este negocio utiliza un perfil social o directorio en lugar de web propia. La IA enfocará la venta en la necesidad de tener web independiente.'}
                </p>
              )}
            </div>
          )}
        </div>

        {/* Sección Método del Médico: Diagnóstico, Guiones de Contacto y Receta */}
        {lead.aiAudit && (
          <div className="space-y-6">
            {/* 1. HOJA DE DIAGNÓSTICO (MÉTODO DEL MÉDICO - NINO MANZANO) */}
            <div className="p-5 rounded-2xl bg-neutral-950/90 border border-neutral-800 space-y-4 shadow-xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-800/80 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
                    <Stethoscope className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm text-neutral-100 flex items-center gap-2">
                      <span>Hoja de Diagnóstico del Negocio</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        El Método del Médico
                      </span>
                    </h3>
                    <p className="text-xs text-neutral-400">
                      «Primero el diagnóstico, después la receta. En su idioma: clientes, llamadas y citas.»
                    </p>
                  </div>
                </div>

                {/* Tone selector */}
                <div className="flex items-center gap-2 self-start sm:self-center">
                  <span className="text-[11px] text-neutral-400">Tono de prospección:</span>
                  <select
                    value={selectedTone}
                    onChange={(e) => handleRegenerateTone(e.target.value as SalesTone)}
                    disabled={regeneratingTone}
                    className="bg-neutral-900 border border-neutral-700 text-neutral-200 text-xs rounded-lg px-2.5 py-1 focus:outline-none focus:border-emerald-500 cursor-pointer"
                  >
                    <option value="directo">Directo</option>
                    <option value="consultivo">Consultivo</option>
                    <option value="cercano">Cercano</option>
                    <option value="persuasivo">Persuasivo</option>
                  </select>
                  {regeneratingTone && (
                    <RotateCw className="w-3.5 h-3.5 animate-spin text-emerald-400" />
                  )}
                </div>
              </div>

              {/* Síntomas detectados (Página 3 del PDF) */}
              <div className="space-y-2">
                <div className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Flame className="w-3.5 h-3.5 text-amber-400" />
                  <span>Síntomas del Paciente (Por qué necesita una web y puede pagarla):</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {lead.userRatingCount && lead.userRatingCount >= 20 ? (
                    <span className="px-2.5 py-1 rounded-lg bg-neutral-900 border border-neutral-750 text-xs text-neutral-200 inline-flex items-center gap-1.5">
                      <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                      <span>{lead.userRatingCount} reseñas en Google ({lead.websiteType === 'own_domain' ? 'web lenta o mejorable' : 'sin web propia'})</span>
                    </span>
                  ) : (
                    <span className="px-2.5 py-1 rounded-lg bg-neutral-900 border border-neutral-750 text-xs text-neutral-200 inline-flex items-center gap-1.5">
                      <Star className="w-3 h-3 text-amber-400" />
                      <span>Ficha de Google activa en su zona</span>
                    </span>
                  )}

                  {lead.websiteType === 'none' && (
                    <span className="px-2.5 py-1 rounded-lg bg-rose-500/10 border border-rose-500/30 text-xs text-rose-300 font-medium">
                      ⚠️ Sin página web (Los clientes se van a los 3 primeros)
                    </span>
                  )}

                  {lead.websiteType === 'social_or_directory' && (
                    <span className="px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 font-medium">
                      ⚠️ Enlaza a redes sociales/directorio (Pierde a los que buscan precios o cita)
                    </span>
                  )}

                  {lead.pageSpeedAudit?.scores?.performance && lead.pageSpeedAudit.scores.performance < 60 && (
                    <span className="px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 font-medium">
                      ⏱️ Web lenta en móvil (PageSpeed: {lead.pageSpeedAudit.scores.performance}/100)
                    </span>
                  )}

                  <span className="px-2.5 py-1 rounded-lg bg-neutral-900 border border-neutral-800 text-xs text-neutral-300">
                    📍 {lead.searchQueryZone || lead.formattedAddress.split(',')[1]?.trim() || 'Zona local'}
                  </span>
                </div>
              </div>

              {/* Las Tres Preguntas en 10 Minutos (Página 4 del PDF) */}
              <div className="space-y-2 pt-2 border-t border-neutral-800/80">
                <div className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider flex items-center justify-between">
                  <span>Las Tres Preguntas de Diagnóstico (Página 4 del PDF):</span>
                  <span className="text-[11px] text-neutral-500 font-normal">Coge el móvil y ponte en el lugar de un cliente</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {/* Pregunta 1: ¿Le encuentro? */}
                  <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-neutral-200">1. ¿Le encuentro?</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">
                        {lead.rating ? 'Ficha activa' : 'Sin valorar'}
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-400 leading-relaxed">
                      {lead.aiAudit.medicalDiagnosis?.threeQuestions?.findability?.note ||
                        'Al buscar su servicio en Google en su zona, ¿aparece en los primeros puestos o los clientes llaman a la competencia antes?'}
                    </p>
                  </div>

                  {/* Pregunta 2: ¿Le entiendo? */}
                  <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-neutral-200">2. ¿Le entiendo?</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/15 text-amber-400 border border-amber-500/20">
                        {lead.websiteType === 'own_domain' ? 'En 5 seg.' : 'Sin web'}
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-400 leading-relaxed">
                      {lead.aiAudit.medicalDiagnosis?.threeQuestions?.understanding?.note ||
                        'Al entrar en su web y contar 5 segundos, ¿se entiende de un vistazo qué hace, dónde está y cuánto tarda en abrir?'}
                    </p>
                  </div>

                  {/* Pregunta 3: ¿Puedo contactarle? */}
                  <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-neutral-200">3. ¿Puedo contactarle?</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">
                        {lead.nationalPhoneNumber ? 'Teléfono listo' : 'Sin botón'}
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-400 leading-relaxed">
                      {lead.aiAudit.medicalDiagnosis?.threeQuestions?.contactability?.note ||
                        '¿Hay un botón pulsable directo para llamar o pedir cita por WhatsApp sin tener que bajar ni copiar el número?'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Tabla: Cómo traducir cada fallo a dinero (Página 5 del PDF) */}
              <div className="space-y-2 pt-2 border-t border-neutral-800/80">
                <div className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider flex items-center justify-between">
                  <span>Fallos Traducidos a Dinero (Página 5 del PDF):</span>
                  <span className="text-[11px] text-emerald-400 font-normal">«Un fallo no es un diagnóstico: lo que importa es lo que le cuesta»</span>
                </div>

                <div className="space-y-2">
                  {(lead.aiAudit.medicalDiagnosis?.findingsWithCost ||
                    lead.aiAudit.painPoints.map((p, idx) => ({
                      finding: `Punto débil ${idx + 1}: ${p}`,
                      costInMoney: `Clientes de la zona que buscan desde el móvil y llaman al competidor de al lado.`,
                    }))
                  ).map((item, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 grid grid-cols-1 md:grid-cols-2 gap-2 text-xs"
                    >
                      <div className="space-y-1">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 flex items-center gap-1">
                          <span className="w-4 h-4 rounded-full bg-neutral-800 flex items-center justify-center text-[10px] text-neutral-200">
                            {idx + 1}
                          </span>
                          Lo que has visto:
                        </span>
                        <p className="text-neutral-200 font-medium pl-5">{item.finding}</p>
                      </div>

                      <div className="space-y-1 border-t md:border-t-0 md:border-l border-neutral-800 pt-2 md:pt-0 md:pl-3">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400 flex items-center gap-1">
                          💸 Lo que le cuesta al negocio:
                        </span>
                        <p className="text-neutral-300 pl-1">{item.costInMoney}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* 2. GUIONES DE CONTACTO DEL MÉTODO DEL MÉDICO (PÁGINA 7 DEL PDF) */}
            <div className="p-5 rounded-2xl bg-neutral-950/90 border border-neutral-800 space-y-4 shadow-xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-800/80 pb-3">
                <div>
                  <h3 className="font-semibold text-sm text-neutral-100 flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-emerald-400" />
                    <span>Guiones de Contacto: Explica el Diagnóstico</span>
                  </h3>
                  <p className="text-xs text-neutral-400">
                    «Siempre dices lo que has visto, lo que le cuesta y una pregunta pequeña. No dices que haces webs, no das precios y no enseñas nada tuyo.»
                  </p>
                </div>

                <div className="flex items-center gap-1.5 bg-neutral-900 p-1 rounded-xl border border-neutral-800 overflow-x-auto">
                  <button
                    onClick={() => setActiveContactTab('whatsapp')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer shrink-0 ${
                      activeContactTab === 'whatsapp'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    💬 WhatsApp
                  </button>

                  <button
                    onClick={() => setActiveContactTab('call')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer shrink-0 ${
                      activeContactTab === 'call'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    📞 Teléfono (30s)
                  </button>

                  <button
                    onClick={() => setActiveContactTab('inperson')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer shrink-0 ${
                      activeContactTab === 'inperson'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    🚶 En Persona
                  </button>

                  <button
                    onClick={() => setActiveContactTab('objection')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer shrink-0 ${
                      activeContactTab === 'objection'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    🛡️ «No me interesa»
                  </button>

                  <button
                    onClick={() => setActiveContactTab('email')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer shrink-0 ${
                      activeContactTab === 'email'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    ✉️ Correo
                  </button>

                  <button
                    onClick={() => setActiveContactTab('monthly')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer shrink-0 ${
                      activeContactTab === 'monthly'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    📊 Revisión mensual
                  </button>
                </div>
              </div>

              {/* Panel de Contenido según la pestaña de contacto activa */}
              <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-4">
                {/* 1. WHATSAPP */}
                {activeContactTab === 'whatsapp' && (
                  <div className="space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-800 pb-2.5">
                      <div>
                        <div className="text-xs font-semibold text-neutral-100 flex items-center gap-2">
                          <span>Estructura Infalible de WhatsApp (Página 7 del PDF)</span>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                            Recomendado
                          </span>
                        </div>
                        <p className="text-[11px] text-neutral-400">
                          Saluda • Cuenta lo que has visto • Explica lo que le cuesta • Pregunta pequeña («¿Te enseño en cinco minutos cómo se arregla?»)
                        </p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => copyToClipboard(lead.aiAudit!.salesDrafts.whatsAppMessage, 'whatsapp')}
                          className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                        >
                          {copiedDraft === 'whatsapp' ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                              <span className="text-emerald-400">Copiado</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>Copiar</span>
                            </>
                          )}
                        </button>

                        <button
                          onClick={() => setIsWhatsAppModalOpen(true)}
                          className="px-3.5 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                        >
                          <span>Personalizar</span>
                        </button>

                        <button
                          onClick={() => handleDirectWhatsApp(lead.aiAudit?.salesDrafts?.whatsAppMessage)}
                          className="px-4 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-neutral-950 text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-sm"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>Enviar WhatsApp</span>
                        </button>
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800/80 text-xs text-neutral-200 whitespace-pre-wrap leading-relaxed font-sans shadow-inner">
                      {lead.aiAudit.salesDrafts.whatsAppMessage}
                    </div>
                  </div>
                )}

                {/* 2. LLAMADA TELEFÓNICA (30s) */}
                {activeContactTab === 'call' && (
                  <div className="space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-800 pb-2.5">
                      <div>
                        <div className="text-xs font-semibold text-neutral-100 flex items-center gap-2">
                          <Phone className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Guion de Llamada Telefónica (30 segundos)</span>
                        </div>
                        <p className="text-[11px] text-neutral-400">
                          Directo al grano, sin rodeos: «He visto una cosa en vuestra ficha que os está haciendo perder clientes. ¿Tienes un minuto?»
                        </p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => copyToClipboard(lead.aiAudit!.salesDrafts.callScript30s, 'call')}
                          className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                        >
                          {copiedDraft === 'call' ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                              <span className="text-emerald-400">Copiado</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>Copiar</span>
                            </>
                          )}
                        </button>

                        {(lead.nationalPhoneNumber || lead.internationalPhoneNumber) && (
                          <a
                            href={`tel:${lead.nationalPhoneNumber || lead.internationalPhoneNumber}`}
                            className="px-4 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-neutral-950 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                          >
                            <Phone className="w-3.5 h-3.5" />
                            <span>Llamar ahora</span>
                          </a>
                        )}
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800/80 text-xs text-neutral-200 whitespace-pre-wrap leading-relaxed font-sans shadow-inner">
                      {lead.aiAudit.salesDrafts.callScript30s}
                    </div>
                  </div>
                )}

                {/* 3. EN PERSONA (PÁGINA 7 DEL PDF) */}
                {activeContactTab === 'inperson' && (
                  <div className="space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-800 pb-2.5">
                      <div>
                        <div className="text-xs font-semibold text-neutral-100 flex items-center gap-2">
                          <Users className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Contacto Presencial (Visita al local con el móvil en la mano)</span>
                        </div>
                        <p className="text-[11px] text-emerald-400/90 font-medium">
                          💡 Consejo del PDF: Lleva el móvil con la búsqueda de Google ya abierta. Que lo vea él, no que te crea a ti.
                        </p>
                      </div>

                      <button
                        onClick={() =>
                          copyToClipboard(
                            lead.aiAudit!.salesDrafts.inPersonScript ||
                              getDoctorInPersonScript(
                                lead.displayName,
                                lead.searchQueryNiche || lead.primaryTypeDisplayName,
                                lead.searchQueryZone,
                                settings.sellerProfile.name
                              ),
                            'inperson'
                          )
                        }
                        className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium flex items-center gap-1.5 cursor-pointer self-start sm:self-center"
                      >
                        {copiedDraft === 'inperson' ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="text-emerald-400">Copiado</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copiar guion</span>
                          </>
                        )}
                      </button>
                    </div>

                    <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800/80 text-xs text-neutral-200 whitespace-pre-wrap leading-relaxed font-sans shadow-inner">
                      {lead.aiAudit.salesDrafts.inPersonScript ||
                        getDoctorInPersonScript(
                          lead.displayName,
                          lead.searchQueryNiche || lead.primaryTypeDisplayName,
                          lead.searchQueryZone,
                          settings.sellerProfile.name
                        )}
                    </div>
                  </div>
                )}

                {/* 4. SI DICE «NO ME INTERESA» (PÁGINA 7 DEL PDF) */}
                {activeContactTab === 'objection' && (
                  <div className="space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-800 pb-2.5">
                      <div>
                        <div className="text-xs font-semibold text-neutral-100 flex items-center gap-2">
                          <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                          <span>Respuesta elegante si dice «No me interesa»</span>
                        </div>
                        <p className="text-[11px] text-neutral-400">
                          Apúntalo en la ficha del CRM y vuelve a escribirle en unos meses con un nuevo diagnóstico. Muchas veces «no» significa «ahora no».
                        </p>
                      </div>

                      <button
                        onClick={() =>
                          copyToClipboard(
                            lead.aiAudit!.salesDrafts.objectionNotInterested ||
                              getDoctorObjectionTemplate(settings.sellerProfile.name),
                            'objection'
                          )
                        }
                        className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium flex items-center gap-1.5 cursor-pointer self-start sm:self-center"
                      >
                        {copiedDraft === 'objection' ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="text-emerald-400">Copiado</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copiar respuesta</span>
                          </>
                        )}
                      </button>
                    </div>

                    <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800/80 text-xs text-neutral-200 whitespace-pre-wrap leading-relaxed font-sans shadow-inner">
                      {lead.aiAudit.salesDrafts.objectionNotInterested ||
                        getDoctorObjectionTemplate(settings.sellerProfile.name)}
                    </div>
                  </div>
                )}

                {/* 5. CORREO ELECTRÓNICO */}
                {activeContactTab === 'email' && (
                  <div className="space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-800 pb-2.5">
                      <div>
                        <div className="text-xs font-semibold text-neutral-100 flex items-center gap-2">
                          <Mail className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Correo Electrónico (Estructurado con el Diagnóstico)</span>
                        </div>
                        <p className="text-[11px] text-neutral-400">
                          Asunto sin tecnicismos ni mayúsculas agresivas. Directo a lo que vio un cliente potencial.
                        </p>
                      </div>

                      <button
                        onClick={() =>
                          copyToClipboard(
                            `Asunto: ${lead.aiAudit!.salesDrafts.emailPitch.subject}\n\n${lead.aiAudit!.salesDrafts.emailPitch.body}`,
                            'email'
                          )
                        }
                        className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium flex items-center gap-1.5 cursor-pointer self-start sm:self-center"
                      >
                        {copiedDraft === 'email' ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="text-emerald-400">Copiado</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copiar Asunto y Cuerpo</span>
                          </>
                        )}
                      </button>
                    </div>

                    <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800/80 space-y-2 text-xs">
                      <div>
                        <span className="text-[10px] text-neutral-400 uppercase font-semibold">Asunto:</span>
                        <div className="text-neutral-100 font-semibold">{lead.aiAudit.salesDrafts.emailPitch.subject}</div>
                      </div>
                      <div className="border-t border-neutral-800 pt-2 text-neutral-300 whitespace-pre-wrap leading-relaxed">
                        {lead.aiAudit.salesDrafts.emailPitch.body}
                      </div>
                    </div>
                  </div>
                )}

                {/* 6. REVISIÓN MENSUAL (PÁGINA 9 DEL PDF) */}
                {activeContactTab === 'monthly' && (
                  <div className="space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-800 pb-2.5">
                      <div>
                        <div className="text-xs font-semibold text-neutral-100 flex items-center gap-2">
                          <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Mensaje de Revisión Mensual (Fidelización del Cliente)</span>
                        </div>
                        <p className="text-[11px] text-neutral-400">
                          Un repaso cada mes con números: llamadas y citas conseguidas. Es lo que hace que se quede y te recomiende.
                        </p>
                      </div>

                      <button
                        onClick={() =>
                          copyToClipboard(
                            lead.aiAudit!.salesDrafts.monthlyReviewMessage ||
                              getDoctorMonthlyReviewTemplate(lead.displayName),
                            'monthly'
                          )
                        }
                        className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium flex items-center gap-1.5 cursor-pointer self-start sm:self-center"
                      >
                        {copiedDraft === 'monthly' ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="text-emerald-400">Copiado</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copiar mensaje</span>
                          </>
                        )}
                      </button>
                    </div>

                    <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800/80 text-xs text-neutral-200 whitespace-pre-wrap leading-relaxed font-sans shadow-inner">
                      {lead.aiAudit.salesDrafts.monthlyReviewMessage ||
                        getDoctorMonthlyReviewTemplate(lead.displayName)}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* 3. LA RECETA MÉDICA & «LA CUENTA YA HECHA» (PÁGINA 8 DEL PDF) */}
            <div className="p-5 rounded-2xl bg-neutral-950/90 border border-neutral-800 space-y-4 shadow-xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-800/80 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
                    <Calculator className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm text-neutral-100 flex items-center gap-2">
                      <span>La Receta Médica & La Cuenta Ya Hecha</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        Página 8 del PDF
                      </span>
                    </h3>
                    <p className="text-xs text-neutral-400">
                      «Solo recetas lo que cura el diagnóstico. Dos opciones como mucho, y el precio SIEMPRE después de la cuenta.»
                    </p>
                  </div>
                </div>
              </div>

              {/* Opciones de la Receta */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Opción Básica */}
                <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-3 flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-neutral-200">
                        {lead.aiAudit.salesDrafts.prescription?.basicOption?.title || 'Opción básica (Arregla lo más urgente)'}
                      </span>
                      <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                        {lead.aiAudit.salesDrafts.prescription?.basicOption?.estimatedPrice || '390€'}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-300 leading-relaxed">
                      {lead.aiAudit.salesDrafts.prescription?.basicOption?.description ||
                        'Arregla los dos fallos más críticos: ficha de Google optimizada con horario, fotos y botón directo para pedir cita o llamar desde el móvil.'}
                    </p>
                  </div>
                  <div className="text-[11px] text-neutral-400 border-t border-neutral-800 pt-2">
                    Pago único • Solución rápida al sangrado de clientes
                  </div>
                </div>

                {/* Opción Recomendada */}
                <div className="p-4 rounded-xl bg-neutral-900 border border-emerald-500/30 space-y-3 flex flex-col justify-between relative overflow-hidden">
                  <div className="absolute top-0 right-0 bg-emerald-500 text-neutral-950 text-[10px] font-bold px-2.5 py-0.5 rounded-bl-lg uppercase tracking-wider">
                    Recomendada
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between pr-24">
                      <span className="text-xs font-bold text-neutral-100">
                        {lead.aiAudit.salesDrafts.prescription?.recommendedOption?.title || 'Opción recomendada (Arregla los 3 fallos)'}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-300 leading-relaxed">
                      {lead.aiAudit.salesDrafts.prescription?.recommendedOption?.description ||
                        'Arregla los tres fallos detectados + Sistema de captación local con WhatsApp + Revisión mensual con informe de llamadas y visitas.'}
                    </p>
                  </div>
                  <div className="flex items-center justify-between border-t border-neutral-800 pt-2">
                    <span className="text-xs text-neutral-300 font-medium">Inversión:</span>
                    <span className="text-xs font-mono font-bold text-emerald-400">
                      {lead.aiAudit.salesDrafts.prescription?.recommendedOption?.estimatedPrice || '690€'} + {lead.aiAudit.salesDrafts.prescription?.recommendedOption?.monthlyFee || '49€/mes'}
                    </span>
                  </div>
                </div>
              </div>

              {/* La Cuenta, ya hecha delante de él (Página 8 del PDF) */}
              <div className="p-4 rounded-xl bg-neutral-900/90 border border-emerald-500/20 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                      <Calculator className="w-4 h-4" />
                      <span>La cuenta, ya hecha delante del cliente:</span>
                    </span>
                    <p className="text-[11px] text-neutral-400">
                      Pregúntale primero cuánto le deja un cliente nuevo y haz la cuenta con su propio número:
                    </p>
                  </div>

                  <div className="flex items-center gap-2 self-start sm:self-center">
                    <label className="text-[11px] text-neutral-300 font-medium">Ticket cliente:</label>
                    <div className="relative">
                      <input
                        type="number"
                        min="10"
                        max="5000"
                        step="10"
                        value={avgTicket}
                        onChange={(e) => setAvgTicket(Math.max(10, parseInt(e.target.value) || 10))}
                        className="w-24 px-2.5 py-1 bg-neutral-950 border border-neutral-700 rounded-lg text-xs font-mono text-neutral-100 text-right pr-6 focus:outline-none focus:border-emerald-500"
                      />
                      <span className="absolute right-2 top-1 text-xs text-neutral-400">€</span>
                    </div>
                  </div>
                </div>

                {/* Resultado de la cuenta */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1 text-center font-mono">
                  <div className="p-2.5 rounded-lg bg-neutral-950 border border-neutral-800">
                    <div className="text-[10px] text-neutral-400 uppercase">Un cliente nuevo le deja</div>
                    <div className="text-sm font-bold text-neutral-100">{avgTicket} €</div>
                  </div>

                  <div className="p-2.5 rounded-lg bg-neutral-950 border border-neutral-800">
                    <div className="text-[10px] text-neutral-400 uppercase">Si trae solo 2 más al mes</div>
                    <div className="text-sm font-bold text-emerald-400">+{avgTicket * 2} € / mes</div>
                  </div>

                  <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30">
                    <div className="text-[10px] text-emerald-400 uppercase">Ingresos extra al año</div>
                    <div className="text-sm font-bold text-emerald-300">+{avgTicket * 24} € / año</div>
                  </div>
                </div>

                <div className="text-[11px] text-neutral-400 flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1 border-t border-neutral-800/80">
                  <span>
                    «Si un cliente nuevo te deja <strong>{avgTicket}€</strong> y esto te trae solo <strong>2 clientes más al mes</strong>, son <strong>{avgTicket * 2}€ al mes</strong> ({avgTicket * 24}€ al año). La web se paga sola desde el primer mes.»
                  </span>
                  <span className="text-[10px] text-neutral-500 shrink-0">Página 8: La cuenta antes del precio</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* CRM Panel (Estado, Notas y Próxima Acción) */}
        <div className="p-5 rounded-xl bg-neutral-950/80 border border-neutral-800 space-y-4 no-print">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
            <h3 className="font-semibold text-sm text-neutral-100 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-emerald-400" />
              Gestión Comercial del Lead
            </h3>
            {savedSuccess && (
              <span className="text-xs text-emerald-400 flex items-center gap-1">
                <Check className="w-3 h-3" />
                Guardado en IndexedDB
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Estado */}
            <div className="space-y-1">
              <label className="text-[11px] font-medium text-neutral-300">Fase del Embudo</label>
              <select
                value={crmStatus}
                onChange={(e) => setCrmStatus(e.target.value as any)}
                className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-neutral-100 focus:outline-none focus:border-emerald-500"
              >
                <option value="nuevo">Nuevo</option>
                <option value="analizado">Analizado</option>
                <option value="contactado">Contactado</option>
                <option value="respondio">Respondió</option>
                <option value="reunion">Reunión Agendada</option>
                <option value="cliente">Cliente Ganado</option>
                <option value="descartado">Descartado</option>
              </select>
            </div>

            {/* Fecha Próxima Acción */}
            <div className="space-y-1">
              <label className="text-[11px] font-medium text-neutral-300">
                Fecha Próximo Seguimiento
              </label>
              <input
                type="date"
                value={crmNextDate}
                onChange={(e) => setCrmNextDate(e.target.value)}
                className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-neutral-100 focus:outline-none focus:border-emerald-500"
              >
              </input>
            </div>

            {/* Guardar botón */}
            <div className="flex items-end">
              <button
                onClick={handleSaveCrm}
                className="w-full py-2 bg-neutral-800 hover:bg-emerald-500 hover:text-neutral-950 text-neutral-100 font-medium rounded-lg text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-neutral-700"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Guardar Cambios</span>
              </button>
            </div>

            {/* Notas privadas */}
            <div className="md:col-span-3 space-y-1.5">
              <div className="flex items-center justify-between text-[11px]">
                <label className="font-medium text-neutral-300">
                  Notas y Anotaciones de la Prospección
                </label>
                <span className="text-neutral-500 text-[10px]">
                  Párrafos, tabulaciones y saltos de línea se guardan íntegramente
                </span>
              </div>
              <textarea
                rows={5}
                value={crmNotes}
                onChange={(e) => setCrmNotes(e.target.value)}
                onBlur={handleSaveCrm}
                placeholder="Anotar detalles: nombre del dueño, objeciones planteadas, horario preferido para llamar, presupuesto estimado..."
                className="w-full p-3.5 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-emerald-500 whitespace-pre-wrap font-sans leading-relaxed"
              />
            </div>
          </div>
        </div>
      </div>

      {/* WhatsApp Custom Message Modal */}
      <WhatsAppModal
        lead={lead}
        isOpen={isWhatsAppModalOpen}
        onClose={() => setIsWhatsAppModalOpen(false)}
        sellerName={settings.sellerProfile.name}
        onMessageSent={(markContacted) => {
          if (markContacted) {
            setCrmStatus('contactado');
            const updated = {
              ...lead,
              crm: {
                ...lead.crm,
                status: 'contactado' as const,
                notes: crmNotes,
                nextActionDate: crmNextDate,
              },
            };
            saveLead(updated);
            onLeadUpdated(updated);
          }
        }}
      />
    </div>
  );
};
