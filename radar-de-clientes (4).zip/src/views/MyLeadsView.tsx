import React, { useState, useMemo } from 'react';
import {
  Users,
  LayoutGrid,
  Table as TableIcon,
  Search,
  Filter,
  Phone,
  Globe,
  MapPin,
  Star,
  ExternalLink,
  Trash2,
  Eye,
  Calendar,
  MessageSquare,
  FileSpreadsheet,
  Edit3,
  Check,
  Save,
  X,
  Sparkles,
  TrendingUp,
  Clock,
  AlertCircle,
} from 'lucide-react';
import { BusinessLead, CrmLeadStatus } from '../types';
import { ScoreBadge } from '../components/ScoreBadge';
import { deleteLead, saveLead } from '../services/storage';
import { WhatsAppModal } from '../components/WhatsAppModal';
import { buildWhatsAppUrl } from '../utils/whatsapp';

interface MyLeadsViewProps {
  leads: BusinessLead[];
  onSelectLead: (lead: BusinessLead) => void;
  onLeadUpdated: (lead: BusinessLead) => void;
  onLeadDeleted: (id: string) => void;
  sellerName?: string;
}

const CRM_STAGES: { id: CrmLeadStatus; label: string; color: string; badgeColor: string }[] = [
  {
    id: 'nuevo',
    label: 'Nuevo',
    color: 'border-neutral-700 bg-neutral-900/90 text-neutral-300',
    badgeColor: 'bg-neutral-800 text-neutral-300 border-neutral-700',
  },
  {
    id: 'analizado',
    label: 'Analizado',
    color: 'border-blue-500/30 bg-blue-950/20 text-blue-400',
    badgeColor: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
  },
  {
    id: 'contactado',
    label: 'Contactado',
    color: 'border-amber-500/30 bg-amber-950/20 text-amber-400',
    badgeColor: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
  },
  {
    id: 'respondio',
    label: 'Respondió',
    color: 'border-purple-500/30 bg-purple-950/20 text-purple-300',
    badgeColor: 'bg-purple-500/10 text-purple-300 border-purple-500/30',
  },
  {
    id: 'reunion',
    label: 'Reunión',
    color: 'border-cyan-500/30 bg-cyan-950/20 text-cyan-400',
    badgeColor: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
  },
  {
    id: 'cliente',
    label: 'Cliente Ganado',
    color: 'border-emerald-500/30 bg-emerald-950/20 text-emerald-400',
    badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
  },
  {
    id: 'descartado',
    label: 'Descartado',
    color: 'border-rose-500/30 bg-rose-950/20 text-rose-400',
    badgeColor: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
  },
];

export const MyLeadsView: React.FC<MyLeadsViewProps> = ({
  leads,
  onSelectLead,
  onLeadUpdated,
  onLeadDeleted,
  sellerName = 'Simón',
}) => {
  const [viewMode, setViewMode] = useState<'kanban' | 'table'>('kanban');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [zoneFilter, setZoneFilter] = useState<string>('all');
  const [nicheFilter, setNicheFilter] = useState<string>('all');

  // Modals state
  const [activeWhatsAppLead, setActiveWhatsAppLead] = useState<BusinessLead | null>(null);
  const [editingNoteLead, setEditingNoteLead] = useState<BusinessLead | null>(null);
  const [tempNoteText, setTempNoteText] = useState('');
  const [tempNextDate, setTempNextDate] = useState('');
  const [tempStatus, setTempStatus] = useState<CrmLeadStatus>('nuevo');

  // Distinct zones & niches for filters
  const distinctZones = useMemo(() => {
    const set = new Set<string>();
    leads.forEach((l) => l.searchQueryZone && set.add(l.searchQueryZone));
    return Array.from(set);
  }, [leads]);

  const distinctNiches = useMemo(() => {
    const set = new Set<string>();
    leads.forEach((l) => {
      const n = l.primaryTypeDisplayName || l.searchQueryNiche;
      if (n) set.add(n);
    });
    return Array.from(set);
  }, [leads]);

  // Key metrics
  const stats = useMemo(() => {
    const total = leads.length;
    const withPhone = leads.filter((l) => l.nationalPhoneNumber || l.internationalPhoneNumber).length;
    const analyzed = leads.filter((l) => l.aiAudit).length;
    const won = leads.filter((l) => l.crm.status === 'cliente').length;
    const avgScore =
      total > 0 ? Math.round(leads.reduce((acc, l) => acc + (l.opportunityScore || 0), 0) / total) : 0;
    return { total, withPhone, analyzed, won, avgScore };
  }, [leads]);

  // Filtered leads
  const filteredLeads = useMemo(() => {
    return leads.filter((lead) => {
      if (statusFilter !== 'all' && lead.crm.status !== statusFilter) return false;
      if (zoneFilter !== 'all' && lead.searchQueryZone !== zoneFilter) return false;
      if (
        nicheFilter !== 'all' &&
        lead.primaryTypeDisplayName !== nicheFilter &&
        lead.searchQueryNiche !== nicheFilter
      ) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = lead.displayName.toLowerCase().includes(q);
        const matchesAddress = lead.formattedAddress.toLowerCase().includes(q);
        const matchesNotes = lead.crm.notes?.toLowerCase().includes(q);
        if (!matchesName && !matchesAddress && !matchesNotes) return false;
      }
      return true;
    });
  }, [leads, statusFilter, zoneFilter, nicheFilter, searchQuery]);

  // Quick move stage
  const handleMoveStage = async (lead: BusinessLead, newStatus: CrmLeadStatus) => {
    const updated: BusinessLead = {
      ...lead,
      crm: {
        ...lead.crm,
        status: newStatus,
      },
    };
    await saveLead(updated);
    onLeadUpdated(updated);
  };

  // Delete lead
  const handleDelete = async (id: string, name: string) => {
    if (window.confirm(`¿Seguro que deseas eliminar "${name}" de tus leads guardados?`)) {
      await deleteLead(id);
      onLeadDeleted(id);
    }
  };

  // Open note modal
  const openEditNote = (lead: BusinessLead) => {
    setEditingNoteLead(lead);
    setTempNoteText(lead.crm.notes || '');
    setTempNextDate(lead.crm.nextActionDate || '');
    setTempStatus(lead.crm.status || 'nuevo');
  };

  // Save note modal
  const handleSaveNoteModal = async () => {
    if (!editingNoteLead) return;
    const updated: BusinessLead = {
      ...editingNoteLead,
      crm: {
        ...editingNoteLead.crm,
        notes: tempNoteText, // preserves spaces and line breaks verbatim
        nextActionDate: tempNextDate,
        status: tempStatus,
      },
    };
    await saveLead(updated);
    onLeadUpdated(updated);
    setEditingNoteLead(null);
  };

  // Export to CSV with UTF-8 BOM
  const handleExportCsv = () => {
    if (leads.length === 0) return;

    const headers = [
      'Nombre',
      'Teléfono',
      'Página Web',
      'Tipo de Web',
      'Dirección',
      'Valoración',
      'Número de Reseñas',
      'Puntuación Oportunidad',
      'Estado CRM',
      'Fecha Próximo Contacto',
      'Notas de Seguimiento',
      'Servicio Recomendado',
      'Enlace Google Maps',
    ];

    const rows = filteredLeads.map((l) => {
      // Escape quotes for CSV while keeping spaces and newlines intact within quotes
      const cleanNotes = (l.crm.notes || '').replace(/"/g, '""');
      return [
        `"${(l.displayName || '').replace(/"/g, '""')}"`,
        `"${(l.nationalPhoneNumber || l.internationalPhoneNumber || '').replace(/"/g, '""')}"`,
        `"${(l.websiteUri || '').replace(/"/g, '""')}"`,
        `"${l.websiteType}"`,
        `"${(l.formattedAddress || '').replace(/"/g, '""')}"`,
        l.rating || '',
        l.userRatingCount || 0,
        l.opportunityScore,
        `"${l.crm.status}"`,
        `"${l.crm.nextActionDate || ''}"`,
        `"${cleanNotes}"`,
        `"${l.aiAudit?.recommendedService || ''}"`,
        `"${l.googleMapsUri || ''}"`,
      ].join(';');
    });

    const csvContent = '\uFEFF' + [headers.join(';'), ...rows].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `radar_leads_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 pb-16 max-w-7xl mx-auto">
      {/* 1. Pipeline Metrics Header */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="p-3.5 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1">
          <div className="text-[11px] text-neutral-400 font-medium">Total en Cartera</div>
          <div className="text-xl font-bold font-mono text-neutral-100 tabular-nums">
            {stats.total}
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1">
          <div className="text-[11px] text-emerald-400 font-medium flex items-center gap-1">
            <MessageSquare className="w-3 h-3" />
            WhatsApp / Teléfono
          </div>
          <div className="text-xl font-bold font-mono text-emerald-400 tabular-nums">
            {stats.withPhone}
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1">
          <div className="text-[11px] text-blue-400 font-medium flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            Auditados con IA
          </div>
          <div className="text-xl font-bold font-mono text-blue-400 tabular-nums">
            {stats.analyzed}
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1">
          <div className="text-[11px] text-amber-400 font-medium flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            Oportunidad Media
          </div>
          <div className="text-xl font-bold font-mono text-amber-400 tabular-nums">
            {stats.avgScore}
            <span className="text-xs font-normal opacity-70">/100</span>
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1 col-span-2 sm:col-span-1">
          <div className="text-[11px] text-emerald-300 font-medium">Clientes Cerrados</div>
          <div className="text-xl font-bold font-mono text-emerald-300 tabular-nums">
            {stats.won}
          </div>
        </div>
      </div>

      {/* 2. Top Header, Search, Filters & Export */}
      <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-4 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-800 pb-3">
          <div>
            <h2 className="text-base font-semibold text-neutral-100 flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-400" />
              Gestión Comercial de Leads ({filteredLeads.length})
            </h2>
            <p className="text-xs text-neutral-400 mt-0.5">
              Organiza tus prospectos, escribe mensajes de WhatsApp en 1 clic y guarda notas estructuradas.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCsv}
              disabled={leads.length === 0}
              className="px-3.5 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 disabled:opacity-50 text-neutral-200 text-xs font-medium flex items-center gap-1.5 transition-colors border border-neutral-700 cursor-pointer shadow-xs"
              title="Exportar archivo CSV con notas completas"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              <span>Exportar CSV</span>
            </button>

            {/* View switch */}
            <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-lg border border-neutral-800">
              <button
                onClick={() => setViewMode('kanban')}
                className={`p-1.5 rounded text-xs transition-colors ${
                  viewMode === 'kanban'
                    ? 'bg-neutral-800 text-emerald-400'
                    : 'text-neutral-500 hover:text-neutral-300'
                }`}
                title="Tablero Kanban"
              >
                <LayoutGrid className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setViewMode('table')}
                className={`p-1.5 rounded text-xs transition-colors ${
                  viewMode === 'table'
                    ? 'bg-neutral-800 text-emerald-400'
                    : 'text-neutral-500 hover:text-neutral-300'
                }`}
                title="Tabla CRM"
              >
                <TableIcon className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Search & Filter Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          <div className="sm:col-span-1 relative">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar por nombre, nota o calle..."
              className="w-full pl-8 pr-3 py-1.5 bg-neutral-950 border border-neutral-700 rounded-lg text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-1.5 bg-neutral-950 border border-neutral-700 rounded-lg text-xs text-neutral-300 focus:outline-none focus:border-emerald-500"
            >
              <option value="all">Todas las fases</option>
              {CRM_STAGES.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <select
              value={zoneFilter}
              onChange={(e) => setZoneFilter(e.target.value)}
              className="w-full px-3 py-1.5 bg-neutral-950 border border-neutral-700 rounded-lg text-xs text-neutral-300 focus:outline-none focus:border-emerald-500"
            >
              <option value="all">Todas las zonas</option>
              {distinctZones.map((z) => (
                <option key={z} value={z}>
                  {z}
                </option>
              ))}
            </select>
          </div>

          <div>
            <select
              value={nicheFilter}
              onChange={(e) => setNicheFilter(e.target.value)}
              className="w-full px-3 py-1.5 bg-neutral-950 border border-neutral-700 rounded-lg text-xs text-neutral-300 focus:outline-none focus:border-emerald-500"
            >
              <option value="all">Todos los sectores</option>
              {distinctNiches.map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main Content: Kanban or Table */}
      {leads.length === 0 ? (
        <div className="p-16 text-center rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3">
          <div className="w-12 h-12 rounded-xl bg-neutral-800 border border-neutral-700 flex items-center justify-center mx-auto text-neutral-400">
            <Users className="w-6 h-6" />
          </div>
          <h3 className="font-semibold text-neutral-200 text-sm">
            Aún no tienes ningún lead guardado
          </h3>
          <p className="text-xs text-neutral-400 max-w-sm mx-auto">
            Ve a «Buscar Negocios», localiza comercios en tu zona y pulsa el botón de guardar para
            incorporarlos a tu pipeline comercial.
          </p>
        </div>
      ) : viewMode === 'kanban' ? (
        /* Highly Structured Kanban Board */
        <div className="grid grid-cols-1 md:grid-cols-7 gap-3.5 overflow-x-auto pb-4 items-start">
          {CRM_STAGES.map((stage) => {
            const stageLeads = filteredLeads.filter((l) => l.crm.status === stage.id);

            return (
              <div
                key={stage.id}
                className="flex flex-col bg-neutral-900/90 border border-neutral-800 rounded-2xl min-w-[240px] shadow-sm"
              >
                {/* Stage Header */}
                <div className="p-3.5 border-b border-neutral-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-neutral-200">{stage.label}</span>
                  </div>
                  <span className="font-mono text-[11px] font-semibold px-2 py-0.5 rounded-full bg-neutral-800 text-neutral-300">
                    {stageLeads.length}
                  </span>
                </div>

                {/* Cards Container */}
                <div className="p-2.5 space-y-3 flex-1 min-h-[320px]">
                  {stageLeads.map((lead) => {
                    const phone = lead.nationalPhoneNumber || lead.internationalPhoneNumber;

                    return (
                      <div
                        key={lead.id}
                        className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 hover:border-neutral-700/80 transition-all space-y-2.5 shadow-sm"
                      >
                        {/* 1. Title & Score */}
                        <div className="flex items-start justify-between gap-1.5">
                          <div className="min-w-0 flex-1">
                            <button
                              onClick={() => onSelectLead(lead)}
                              className="font-bold text-xs text-neutral-100 hover:text-emerald-400 text-left line-clamp-1 transition-colors block"
                              title={lead.displayName}
                            >
                              {lead.displayName}
                            </button>
                            {lead.primaryTypeDisplayName && (
                              <span className="text-[10px] text-neutral-400 truncate block mt-0.5">
                                {lead.primaryTypeDisplayName}
                              </span>
                            )}
                          </div>
                          <ScoreBadge score={lead.opportunityScore} size="sm" />
                        </div>

                        {/* 2. Address */}
                        <div className="text-[10px] text-neutral-400 line-clamp-1 flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-neutral-500 shrink-0" />
                          <span>{lead.formattedAddress}</span>
                        </div>

                        {/* 3. Direct Contact Strip (Phone + WhatsApp) */}
                        <div className="pt-1.5 border-t border-neutral-800/80 flex items-center justify-between gap-1">
                          {phone ? (
                            <div className="flex items-center gap-1.5">
                              <a
                                href={`tel:${phone}`}
                                className="px-2 py-1 rounded bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-800 text-[10px] font-mono flex items-center gap-1"
                                title="Llamar"
                              >
                                <Phone className="w-2.5 h-2.5 text-neutral-400" />
                                <span className="truncate max-w-[85px]">{phone}</span>
                              </a>

                              {/* WhatsApp direct button */}
                              <button
                                onClick={() => setActiveWhatsAppLead(lead)}
                                className="px-2 py-1 rounded bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30 text-[10px] font-medium flex items-center gap-1 cursor-pointer"
                                title="Escribir mensaje personalizado por WhatsApp"
                              >
                                <MessageSquare className="w-2.5 h-2.5" />
                                <span>WhatsApp</span>
                              </button>
                            </div>
                          ) : (
                            <span className="text-[10px] text-neutral-500 italic">Sin teléfono</span>
                          )}

                          {lead.websiteUri && (
                            <a
                              href={lead.websiteUri}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="p-1 text-neutral-400 hover:text-neutral-200"
                              title="Visitar web"
                            >
                              <Globe className="w-3 h-3" />
                            </a>
                          )}
                        </div>

                        {/* 4. Next scheduled date badge */}
                        {lead.crm.nextActionDate && (
                          <div className="text-[10px] px-2 py-1 rounded bg-amber-500/10 border border-amber-500/20 text-amber-300 font-mono flex items-center gap-1.5">
                            <Calendar className="w-3 h-3 text-amber-400 shrink-0" />
                            <span>Acción: {lead.crm.nextActionDate}</span>
                          </div>
                        )}

                        {/* 5. Structured Notes Box with whitespace preserved */}
                        <div className="p-2.5 rounded-lg bg-neutral-900/90 border border-neutral-800/90 space-y-1">
                          <div className="flex items-center justify-between text-[10px]">
                            <span className="font-semibold text-neutral-400 uppercase tracking-wider">
                              Notas de Seguimiento
                            </span>
                            <button
                              onClick={() => openEditNote(lead)}
                              className="text-emerald-400 hover:text-emerald-300 inline-flex items-center gap-0.5"
                              title="Editar notas"
                            >
                              <Edit3 className="w-2.5 h-2.5" />
                              <span>Editar</span>
                            </button>
                          </div>

                          {lead.crm.notes ? (
                            <div className="text-[11px] text-neutral-300 font-sans whitespace-pre-wrap leading-relaxed line-clamp-4 break-words">
                              {lead.crm.notes}
                            </div>
                          ) : (
                            <div
                              onClick={() => openEditNote(lead)}
                              className="text-[10px] text-neutral-500 italic cursor-pointer hover:text-neutral-400"
                            >
                              + Añadir nota (horarios, objeciones, presupuesto)...
                            </div>
                          )}
                        </div>

                        {/* 6. Bottom actions & stage selector */}
                        <div className="pt-2 border-t border-neutral-800/80 flex items-center justify-between gap-1">
                          <select
                            value={lead.crm.status}
                            onChange={(e) =>
                              handleMoveStage(lead, e.target.value as CrmLeadStatus)
                            }
                            className="bg-neutral-900 text-[10px] text-neutral-300 rounded px-2 py-1 border border-neutral-800 focus:outline-none focus:border-emerald-500 max-w-[120px]"
                          >
                            {CRM_STAGES.map((s) => (
                              <option key={s.id} value={s.id}>
                                {s.label}
                              </option>
                            ))}
                          </select>

                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => onSelectLead(lead)}
                              className="p-1 text-neutral-400 hover:text-emerald-400 transition-colors"
                              title="Ver Ficha y Auditoría Completa"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDelete(lead.id, lead.displayName)}
                              className="p-1 text-neutral-400 hover:text-rose-400 transition-colors"
                              title="Eliminar lead"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}

                  {stageLeads.length === 0 && (
                    <div className="h-28 flex flex-col items-center justify-center text-[11px] text-neutral-600 border border-dashed border-neutral-800/70 rounded-xl">
                      <span>Sin prospectos</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Structured CRM Table View */
        <div className="rounded-xl border border-neutral-800 bg-neutral-900 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-neutral-800 text-[11px] uppercase tracking-wider text-neutral-400 bg-neutral-950/60">
                  <th className="py-3 px-4 font-semibold">Negocio</th>
                  <th className="py-3 px-4 font-semibold">Contacto & WhatsApp</th>
                  <th className="py-3 px-4 font-semibold">Web</th>
                  <th className="py-3 px-4 font-semibold text-center">Oportunidad</th>
                  <th className="py-3 px-4 font-semibold">Fase CRM</th>
                  <th className="py-3 px-4 font-semibold">Próx. Acción</th>
                  <th className="py-3 px-4 font-semibold min-w-[200px]">Notas de Prospección</th>
                  <th className="py-3 px-4 font-semibold text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/80">
                {filteredLeads.map((lead) => {
                  const phone = lead.nationalPhoneNumber || lead.internationalPhoneNumber;

                  return (
                    <tr key={lead.id} className="hover:bg-neutral-800/40 transition-colors">
                      {/* Negocio */}
                      <td className="py-3 px-4">
                        <button
                          onClick={() => onSelectLead(lead)}
                          className="font-bold text-neutral-100 hover:text-emerald-400 text-left block transition-colors"
                        >
                          {lead.displayName}
                        </button>
                        <div className="text-[11px] text-neutral-400 truncate max-w-xs mt-0.5">
                          {lead.formattedAddress}
                        </div>
                      </td>

                      {/* Contacto & WhatsApp */}
                      <td className="py-3 px-4">
                        {phone ? (
                          <div className="space-y-1">
                            <a
                              href={`tel:${phone}`}
                              className="text-neutral-200 hover:text-emerald-300 font-mono text-[11px] block"
                            >
                              {phone}
                            </a>

                            <button
                              onClick={() => setActiveWhatsAppLead(lead)}
                              className="px-2 py-0.5 rounded bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30 text-[10px] font-medium inline-flex items-center gap-1 cursor-pointer"
                              title="Escribir mensaje personalizado"
                            >
                              <MessageSquare className="w-2.5 h-2.5" />
                              <span>Escribir por WhatsApp</span>
                            </button>
                          </div>
                        ) : (
                          <span className="text-neutral-500 italic text-[11px]">Sin teléfono</span>
                        )}
                      </td>

                      {/* Web */}
                      <td className="py-3 px-4">
                        {lead.websiteUri ? (
                          <a
                            href={lead.websiteUri}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-neutral-300 hover:text-emerald-300 truncate max-w-[140px] inline-block font-mono text-[11px]"
                          >
                            {lead.websiteUri.replace(/^https?:\/\/(www\.)?/, '')}
                          </a>
                        ) : (
                          <span className="text-rose-400 text-[11px]">Sin web</span>
                        )}
                      </td>

                      {/* Oportunidad */}
                      <td className="py-3 px-4 text-center">
                        <ScoreBadge score={lead.opportunityScore} size="sm" />
                      </td>

                      {/* Fase */}
                      <td className="py-3 px-4">
                        <select
                          value={lead.crm.status}
                          onChange={(e) =>
                            handleMoveStage(lead, e.target.value as CrmLeadStatus)
                          }
                          className="bg-neutral-950 text-neutral-200 border border-neutral-700 text-xs rounded px-2 py-1 focus:outline-none"
                        >
                          {CRM_STAGES.map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.label}
                            </option>
                          ))}
                        </select>
                      </td>

                      {/* Próx Acción */}
                      <td className="py-3 px-4 font-mono text-[11px] text-neutral-300 whitespace-nowrap">
                        {lead.crm.nextActionDate || '-'}
                      </td>

                      {/* Notas estructuradas con preservación de espacios */}
                      <td className="py-3 px-4">
                        <div
                          onClick={() => openEditNote(lead)}
                          className="cursor-pointer group p-1.5 rounded hover:bg-neutral-950/60"
                        >
                          {lead.crm.notes ? (
                            <div className="text-[11px] text-neutral-300 whitespace-pre-wrap font-sans leading-relaxed line-clamp-3">
                              {lead.crm.notes}
                            </div>
                          ) : (
                            <span className="text-neutral-500 italic text-[11px] group-hover:text-emerald-400">
                              + Añadir nota
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Acciones */}
                      <td className="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
                        <button
                          onClick={() => openEditNote(lead)}
                          className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200"
                          title="Editar notas y fecha"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onSelectLead(lead)}
                          className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200"
                          title="Ver Ficha y Auditoría"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDelete(lead.id, lead.displayName)}
                          className="p-1.5 rounded-lg bg-neutral-800 hover:bg-rose-500/20 text-neutral-400 hover:text-rose-400"
                          title="Eliminar"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. Dedicated Structured Note Editing Modal */}
      {editingNoteLead && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl animate-in zoom-in-95 duration-150">
            <div className="flex items-start justify-between border-b border-neutral-800 pb-3">
              <div>
                <h3 className="font-semibold text-sm text-neutral-100 flex items-center gap-1.5">
                  <Edit3 className="w-4 h-4 text-emerald-400" />
                  Editar Notas y Seguimiento
                </h3>
                <p className="text-xs text-neutral-400">{editingNoteLead.displayName}</p>
              </div>
              <button
                onClick={() => setEditingNoteLead(null)}
                className="p-1 rounded text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick status & next action date */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-medium text-neutral-300">Fase del Embudo</label>
                <select
                  value={tempStatus}
                  onChange={(e) => setTempStatus(e.target.value as CrmLeadStatus)}
                  className="w-full px-3 py-1.5 bg-neutral-950 border border-neutral-700 rounded-lg text-xs text-neutral-200 focus:outline-none focus:border-emerald-500"
                >
                  {CRM_STAGES.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-medium text-neutral-300">Próxima Acción</label>
                <input
                  type="date"
                  value={tempNextDate}
                  onChange={(e) => setTempNextDate(e.target.value)}
                  className="w-full px-3 py-1.5 bg-neutral-950 border border-neutral-700 rounded-lg text-xs text-neutral-200 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            {/* Textarea with full whitespace preservation */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px]">
                <label className="font-medium text-neutral-300">Anotaciones del Negocio</label>
                <span className="text-[10px] text-neutral-500">
                  Saltos de línea y párrafos se guardan exactamente como los escribas
                </span>
              </div>
              <textarea
                rows={7}
                value={tempNoteText}
                onChange={(e) => setTempNoteText(e.target.value)}
                placeholder="Escribe detalles del contacto:
- Nombre del interlocutor
- Servicios que le interesaron
- Horarios para llamar
- Presupuesto aproximado..."
                className="w-full p-3.5 bg-neutral-950 border border-neutral-700 rounded-xl text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-emerald-500 whitespace-pre-wrap font-sans leading-relaxed resize-y"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-800">
              <button
                onClick={() => setEditingNoteLead(null)}
                className="px-3.5 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-medium transition-colors"
              >
                Cancelar
              </button>

              <button
                onClick={handleSaveNoteModal}
                className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-neutral-950 font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Guardar Notas</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4. WhatsApp Direct Message Modal */}
      {activeWhatsAppLead && (
        <WhatsAppModal
          lead={activeWhatsAppLead}
          isOpen={Boolean(activeWhatsAppLead)}
          onClose={() => setActiveWhatsAppLead(null)}
          sellerName={sellerName}
          onMessageSent={(markContacted) => {
            if (markContacted) {
              handleMoveStage(activeWhatsAppLead, 'contactado');
            }
          }}
        />
      )}
    </div>
  );
};
