import React, { useState } from 'react';
import {
  Radar,
  MapPin,
  Play,
  RotateCw,
  Plus,
  Trash2,
  AlertTriangle,
  Award,
  ArrowRight,
  TrendingUp,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { UserSettings, NicheCategoryStats, NicheRecommendation } from '../types';
import { detectWebsiteType } from '../services/scoring';
import { recordPlacesApiCall, getCachedSearch, setCachedSearch } from '../services/storage';

interface NicheRadarViewProps {
  settings: UserSettings;
  onUpdateSettings: (s: UserSettings) => void;
  onExploreNiche: (zone: string, niche: string) => void;
}

const INITIAL_NICHES = [
  'talleres mecánicos',
  'clínicas dentales',
  'fisioterapeutas',
  'peluquerías',
  'centros de estética',
  'restaurantes',
  'gimnasios',
  'academias',
  'inmobiliarias',
  'reformas',
  'veterinarios',
  'autoescuelas',
  'ópticas',
  'gestorías',
];

export const NicheRadarView: React.FC<NicheRadarViewProps> = ({
  settings,
  onUpdateSettings,
  onExploreNiche,
}) => {
  const [zone, setZone] = useState('Dos Hermanas, Sevilla');
  const [niches, setNiches] = useState<string[]>(INITIAL_NICHES);
  const [newNicheInput, setNewNicheInput] = useState('');
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  // Execution state
  const [isScanning, setIsScanning] = useState(false);
  const [currentScanningNiche, setCurrentScanningNiche] = useState<string | null>(null);
  const [scanProgress, setScanProgress] = useState<{ current: number; total: number } | null>(null);

  // Results
  const [categoriesStats, setCategoriesStats] = useState<NicheCategoryStats[]>([]);
  const [recommendations, setRecommendations] = useState<NicheRecommendation[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleAddNiche = () => {
    if (!newNicheInput.trim()) return;
    const clean = newNicheInput.trim().toLowerCase();
    if (!niches.includes(clean)) {
      setNiches([...niches, clean]);
    }
    setNewNicheInput('');
  };

  const handleRemoveNiche = (target: string) => {
    setNiches(niches.filter((n) => n !== target));
  };

  const startRadarScan = async () => {
    setShowConfirmModal(false);
    setIsScanning(true);
    setErrorMessage(null);
    setCategoriesStats([]);
    setRecommendations([]);

    const resultsList: NicheCategoryStats[] = [];

    try {
      for (let i = 0; i < niches.length; i++) {
        const currentNiche = niches[i];
        setCurrentScanningNiche(currentNiche);
        setScanProgress({ current: i + 1, total: niches.length });

        const query = `${currentNiche} en ${zone.trim()}`;
        const cacheKey = `niche_stat_${query.toLowerCase()}`;

        let placesRaw = [];
        const cached = await getCachedSearch<any[]>(cacheKey);

        if (cached) {
          placesRaw = cached;
        } else {
          const response = await fetch('/api/places/search', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'x-google-cloud-key': settings.googleCloudApiKey || '',
            },
            body: JSON.stringify({
              textQuery: query,
              apiKey: settings.googleCloudApiKey,
            }),
          });

          const data = await response.json();
          if (!response.ok) {
            throw new Error(data.error || `Error al escanear "${currentNiche}".`);
          }

          placesRaw = data.places || [];
          await setCachedSearch(cacheKey, placesRaw);

          const updatedSettings = await recordPlacesApiCall(1);
          onUpdateSettings(updatedSettings);
        }

        // Calculate statistics
        const total = placesRaw.length;
        let withoutOwnWebCount = 0;
        let sumRating = 0;
        let countRating = 0;
        let sumReviews = 0;

        for (const p of placesRaw) {
          const webType = detectWebsiteType(p.websiteUri).type;
          if (webType !== 'own_domain') {
            withoutOwnWebCount++;
          }
          if (p.rating) {
            sumRating += p.rating;
            countRating++;
          }
          if (p.userRatingCount) {
            sumReviews += p.userRatingCount;
          }
        }

        const stat: NicheCategoryStats = {
          niche: currentNiche,
          totalFound: total,
          withoutOwnWebCount,
          withoutOwnWebPercent: total > 0 ? Math.round((withoutOwnWebCount / total) * 100) : 0,
          avgRating: countRating > 0 ? Number((sumRating / countRating).toFixed(1)) : 0,
          avgReviews: total > 0 ? Math.round(sumReviews / total) : 0,
        };

        resultsList.push(stat);
        setCategoriesStats([...resultsList]);
      }

      // Step 2: Call Gemini to rank and recommend top 3 niches
      setCurrentScanningNiche('Gemini analizando la mejor oportunidad comercial...');
      const geminiRes = await fetch('/api/gemini/niche-radar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          zone,
          categoriesStats: resultsList,
          sellerProfile: settings.sellerProfile,
        }),
      });

      const geminiData = await geminiRes.json();
      if (geminiRes.ok && geminiData.recommendations) {
        setRecommendations(geminiData.recommendations);
      }
    } catch (err: any) {
      console.error('Error en radar de nichos:', err);
      setErrorMessage(err.message || 'Error durante el análisis de nichos.');
    } finally {
      setIsScanning(false);
      setCurrentScanningNiche(null);
      setScanProgress(null);
    }
  };

  const serviceLabels: Record<string, string> = {
    web_moderna: 'Página Web Moderna',
    agente_whatsapp: 'Agente de IA para WhatsApp 24/7',
    sistema_citas: 'Sistema de Reservas y Citas Online',
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-16">
      {/* Header and Zone Input */}
      <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-4 shadow-sm">
        <div className="border-b border-neutral-800 pb-3">
          <h2 className="text-base font-semibold text-neutral-100 flex items-center gap-2">
            <Radar className="w-4 h-4 text-emerald-400" />
            Radar de Nichos con IA
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Compara múltiples sectores en tu ciudad para identificar dónde hay menos competencia web, más volumen de clientes y mayor facilidad de cierre.
          </p>
        </div>

        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="md:col-span-8 space-y-1">
            <label className="text-[11px] font-medium text-neutral-300">
              Zona a Explorar (Ciudad o Comarca)
            </label>
            <div className="relative">
              <MapPin className="w-4 h-4 text-neutral-500 absolute left-3 top-2.5" />
              <input
                type="text"
                value={zone}
                onChange={(e) => setZone(e.target.value)}
                placeholder="Ej. Dos Hermanas, Sevilla"
                className="w-full pl-9 pr-3 py-2 bg-neutral-950 border border-neutral-700 rounded-lg text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-emerald-500/80"
              />
            </div>
          </div>

          <div className="md:col-span-4 flex items-end">
            <button
              onClick={() => setShowConfirmModal(true)}
              disabled={isScanning || !zone.trim() || niches.length === 0}
              className="w-full py-2 px-4 bg-emerald-500 hover:bg-emerald-600 disabled:bg-neutral-800 disabled:text-neutral-500 text-neutral-950 font-semibold rounded-lg text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-sm"
            >
              {isScanning ? (
                <>
                  <RotateCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Escaneando nichos...</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5" />
                  <span>Ejecutar Radar ({niches.length} nichos)</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Editable Niches Pool */}
        <div className="space-y-2 pt-2 border-t border-neutral-800/80">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-neutral-300 font-medium">
              Categorías a comparar ({niches.length}):
            </span>
            <div className="flex items-center gap-1.5">
              <input
                type="text"
                value={newNicheInput}
                onChange={(e) => setNewNicheInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddNiche()}
                placeholder="Añadir nicho..."
                className="px-2 py-1 bg-neutral-950 border border-neutral-700 rounded text-[11px] text-neutral-200 focus:outline-none focus:border-emerald-500"
              />
              <button
                onClick={handleAddNiche}
                className="p-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200"
                title="Añadir categoría"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto">
            {niches.map((n) => (
              <span
                key={n}
                className="inline-flex items-center gap-1.5 text-[11px] px-2.5 py-1 rounded bg-neutral-950 text-neutral-300 border border-neutral-800"
              >
                <span>{n}</span>
                <button
                  onClick={() => handleRemoveNiche(n)}
                  className="text-neutral-500 hover:text-rose-400"
                  title="Eliminar de la lista"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Confirmation Modal before spending calls */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-xl animate-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 text-amber-400">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5 text-amber-400" />
              </div>
              <div>
                <h3 className="font-semibold text-neutral-100 text-sm">
                  Confirmación de cuota Google Places
                </h3>
                <p className="text-xs text-neutral-400">Control de gasto de API</p>
              </div>
            </div>

            <p className="text-xs text-neutral-300 leading-relaxed">
              Vas a analizar <strong className="text-emerald-400">{niches.length} categorías</strong> en{' '}
              <strong className="text-neutral-100">"{zone}"</strong>. Esta operación consumirá hasta{' '}
              <strong className="font-mono text-amber-300">{niches.length} llamadas</strong> a Places API
              (aquellas que no estén en caché local).
            </p>

            <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 text-[11px] space-y-1">
              <div className="flex justify-between text-neutral-400">
                <span>Llamadas gastadas este mes:</span>
                <span className="font-mono text-neutral-200">
                  {settings.usageTracker.placesCallCount} / {settings.usageTracker.monthlyFreeTierLimit}
                </span>
              </div>
              <div className="flex justify-between text-neutral-400">
                <span>Límite gratuito restante:</span>
                <span className="font-mono text-emerald-400">
                  {Math.max(
                    0,
                    settings.usageTracker.monthlyFreeTierLimit - settings.usageTracker.placesCallCount
                  )}{' '}
                  llamadas
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-medium transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={startRadarScan}
                className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-neutral-950 font-semibold text-xs transition-colors cursor-pointer"
              >
                Confirmar y Analizar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Scanning Progress Banner */}
      {isScanning && (
        <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-neutral-300 flex items-center gap-2">
              <RotateCw className="w-3.5 h-3.5 animate-spin text-emerald-400" />
              <span>{currentScanningNiche || 'Analizando...'}</span>
            </span>
            <span className="font-mono text-emerald-400 tabular-nums">
              {scanProgress?.current} de {scanProgress?.total}
            </span>
          </div>
          <div className="w-full bg-neutral-950 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-emerald-500 h-full transition-all duration-300"
              style={{
                width: `${
                  scanProgress ? (scanProgress.current / scanProgress.total) * 100 : 0
                }%`,
              }}
            />
          </div>
        </div>
      )}

      {/* Error Message */}
      {errorMessage && (
        <div className="p-3.5 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Gemini Recommendations: Top 3 Podiums */}
      {recommendations.length > 0 && (
        <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-4 shadow-sm">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
            <div>
              <h3 className="font-semibold text-sm text-neutral-100 flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-400" />
                Los 3 Mejores Nichos Recomendados por Gemini Flash
              </h3>
              <p className="text-xs text-neutral-400">
                Ordenados por mayor potencial de cierre comercial y menor resistencia del cliente.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {recommendations.slice(0, 3).map((rec, idx) => (
              <div
                key={rec.niche}
                className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 hover:border-emerald-500/40 transition-colors flex flex-col justify-between space-y-3"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="w-6 h-6 rounded-md bg-amber-500/10 border border-amber-500/20 text-amber-400 font-mono font-bold text-xs flex items-center justify-center">
                      #{idx + 1}
                    </span>
                    <span className="font-mono text-xs font-semibold text-emerald-400">
                      {rec.score}/100 Oportunidad
                    </span>
                  </div>

                  <h4 className="font-bold text-sm text-neutral-100 capitalize">
                    {rec.niche}
                  </h4>

                  <div className="p-2 rounded bg-neutral-900 border border-neutral-800/80 space-y-0.5">
                    <span className="text-[10px] uppercase font-semibold text-emerald-400">
                      Servicio recomendado:
                    </span>
                    <div className="text-xs font-medium text-neutral-200">
                      {serviceLabels[rec.recommendedService] || rec.recommendedService}
                    </div>
                  </div>

                  <p className="text-xs text-neutral-300 leading-relaxed">
                    {rec.reason}
                  </p>

                  <div className="text-[11px] text-neutral-400 border-t border-neutral-800/80 pt-2">
                    <span className="font-semibold text-neutral-300">Estrategia: </span>
                    {rec.actionStrategy}
                  </div>
                </div>

                <button
                  onClick={() => onExploreNiche(zone, rec.niche)}
                  className="w-full py-2 bg-neutral-900 hover:bg-emerald-500 hover:text-neutral-950 text-neutral-200 rounded-lg text-xs font-medium transition-colors flex items-center justify-center gap-1.5 border border-neutral-700 cursor-pointer"
                >
                  <span>Ver negocios de {rec.niche}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Comprehensive Statistics Table */}
      {categoriesStats.length > 0 && (
        <div className="rounded-xl border border-neutral-800 bg-neutral-900 overflow-hidden shadow-sm">
          <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
            <h3 className="font-semibold text-xs text-neutral-200 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              Comparativa Completa de Categorías en {zone}
            </h3>
            <span className="text-xs text-neutral-400 font-mono">
              {categoriesStats.length} analizadas
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-neutral-800 text-[11px] uppercase tracking-wider text-neutral-400 bg-neutral-950/60">
                  <th className="py-2.5 px-4 font-semibold">Nicho / Sector</th>
                  <th className="py-2.5 px-4 font-semibold text-center">Negocios</th>
                  <th className="py-2.5 px-4 font-semibold text-center">Sin Web Propia</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Valoración Media</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Reseñas Media</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Acción</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/80">
                {categoriesStats.map((stat) => (
                  <tr key={stat.niche} className="hover:bg-neutral-800/40 transition-colors">
                    <td className="py-3 px-4 font-semibold text-neutral-100 capitalize">
                      {stat.niche}
                    </td>
                    <td className="py-3 px-4 text-center font-mono tabular-nums text-neutral-300">
                      {stat.totalFound}
                    </td>
                    <td className="py-3 px-4 text-center font-mono tabular-nums">
                      <span
                        className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                          stat.withoutOwnWebPercent >= 50
                            ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                            : stat.withoutOwnWebPercent >= 30
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        }`}
                      >
                        {stat.withoutOwnWebPercent}% ({stat.withoutOwnWebCount})
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-amber-400">
                      ★ {stat.avgRating > 0 ? stat.avgRating.toFixed(1) : '-'}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-neutral-300">
                      {stat.avgReviews}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => onExploreNiche(zone, stat.niche)}
                        className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-emerald-500 hover:text-neutral-950 text-neutral-200 border border-neutral-700 text-xs font-medium transition-colors cursor-pointer inline-flex items-center gap-1"
                      >
                        <span>Ver negocios</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
