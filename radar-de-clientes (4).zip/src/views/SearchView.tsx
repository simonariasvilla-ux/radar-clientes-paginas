import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Phone,
  Globe,
  MapPin,
  Star,
  ExternalLink,
  Save,
  CheckSquare,
  Square,
  Play,
  RotateCw,
  LayoutGrid,
  Table as TableIcon,
  AlertCircle,
  Check,
  Eye,
  SlidersHorizontal,
  MessageSquare,
} from 'lucide-react';
import { BusinessLead, UserSettings } from '../types';
import { detectWebsiteType, calculateOpportunityScore } from '../services/scoring';
import { ScoreBadge } from '../components/ScoreBadge';
import { getCachedSearch, setCachedSearch, recordPlacesApiCall, saveLead } from '../services/storage';
import { WhatsAppModal } from '../components/WhatsAppModal';

interface SearchViewProps {
  settings: UserSettings;
  onUpdateSettings: (s: UserSettings) => void;
  onSelectLead: (lead: BusinessLead) => void;
  savedLeadIds: Set<string>;
  onLeadSaved: (lead: BusinessLead) => void;
  initialZone?: string;
  initialNiche?: string;
}

const DEFAULT_NICHES = [
  'talleres mecánicos',
  'clínicas dentales',
  'fisioterapeutas',
  'peluquerías',
  'centros de estética',
  'restaurantes',
  'gimnasios',
  'academias',
  'inmobiliarias',
  'reformas',
  'veterinarios',
  'autoescuelas',
  'ópticas',
  'gestorías',
];

export const SearchView: React.FC<SearchViewProps> = ({
  settings,
  onUpdateSettings,
  onSelectLead,
  savedLeadIds,
  onLeadSaved,
  initialZone,
  initialNiche,
}) => {
  const [zone, setZone] = useState(initialZone || 'Dos Hermanas, Sevilla');
  const [niche, setNiche] = useState(initialNiche || 'talleres mecánicos');

  // React to prop updates from Radar de Nichos
  React.useEffect(() => {
    if (initialZone) setZone(initialZone);
    if (initialNiche) setNiche(initialNiche);
  }, [initialZone, initialNiche]);
  const [results, setResults] = useState<BusinessLead[]>([]);
  const [nextPageToken, setNextPageToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Filters
  const [filterOnlyNoWeb, setFilterOnlyNoWeb] = useState(false);
  const [filterOnlyWithPhone, setFilterOnlyWithPhone] = useState(false);
  const [filterMinRating, setFilterMinRating] = useState<number>(0);
  const [filterMinReviews, setFilterMinReviews] = useState<number>(0);
  const [filterHideClosed, setFilterHideClosed] = useState(true);

  // View mode
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');

  // Batch selection
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [batchAnalyzing, setBatchAnalyzing] = useState(false);
  const [batchProgress, setBatchProgress] = useState<{ current: number; total: number } | null>(
    null
  );

  // WhatsApp Modal
  const [activeWhatsAppLead, setActiveWhatsAppLead] = useState<BusinessLead | null>(null);

  // Perform search
  const handleSearch = async (pageTokenParam?: string) => {
    if (!zone.trim() || !niche.trim()) {
      setErrorMessage('Por favor, indica una zona y un nicho de negocio para buscar.');
      return;
    }

    const isNextPage = Boolean(pageTokenParam);
    if (isNextPage) {
      setLoadingMore(true);
    } else {
      setLoading(true);
      setResults([]);
      setSelectedIds(new Set());
    }
    setErrorMessage(null);

    const query = `${niche.trim()} en ${zone.trim()}`;
    const cacheKey = `search_${query.toLowerCase()}_${pageTokenParam || 'p1'}`;

    try {
      // Check cache first (only for fresh search or pages)
      const cached = await getCachedSearch<{ places: any[]; nextPageToken?: string }>(cacheKey);
      let placesRaw = [];
      let nextToken: string | null = null;

      if (cached) {
        placesRaw = cached.places || [];
        nextToken = cached.nextPageToken || null;
      } else {
        const response = await fetch('/api/places/search', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-google-cloud-key': settings.googleCloudApiKey || '',
          },
          body: JSON.stringify({
            textQuery: query,
            pageToken: pageTokenParam,
            apiKey: settings.googleCloudApiKey,
          }),
        });

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.error || 'Error al consultar Google Places API.');
        }

        placesRaw = data.places || [];
        nextToken = data.nextPageToken || null;

        // Cache result for 24h
        await setCachedSearch(cacheKey, { places: placesRaw, nextPageToken: nextToken });

        // Record Places API usage counter
        const updatedSettings = await recordPlacesApiCall(1);
        onUpdateSettings(updatedSettings);
      }

      // Transform raw Places into BusinessLead
      const transformedLeads: BusinessLead[] = placesRaw.map((p: any) => {
        const webTypeInfo = detectWebsiteType(p.websiteUri);
        const displayName = p.displayName?.text || p.displayName || 'Negocio Local';
        const formattedAddress = p.formattedAddress || 'Dirección no disponible';

        const leadDraft: Partial<BusinessLead> = {
          id: p.id,
          displayName,
          formattedAddress,
          location: p.location,
          nationalPhoneNumber: p.nationalPhoneNumber,
          internationalPhoneNumber: p.internationalPhoneNumber,
          websiteUri: p.websiteUri,
          websiteType: webTypeInfo.type,
          socialOrDirectoryName: webTypeInfo.providerName,
          rating: p.rating,
          userRatingCount: p.userRatingCount,
          primaryTypeDisplayName: p.primaryTypeDisplayName?.text,
          types: p.types,
          googleMapsUri: p.googleMapsUri || `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(displayName + ' ' + formattedAddress)}`,
          businessStatus: p.businessStatus || 'OPERATIONAL',
          searchQueryZone: zone,
          searchQueryNiche: niche,
          crm: {
            status: 'nuevo',
          },
        };

        const scoreInfo = calculateOpportunityScore(leadDraft);

        return {
          ...leadDraft,
          opportunityScore: scoreInfo.score,
          scoreBreakdown: scoreInfo.breakdown,
          isProvisionalScore: scoreInfo.isProvisional,
        } as BusinessLead;
      });

      if (isNextPage) {
        setResults((prev) => [...prev, ...transformedLeads]);
      } else {
        setResults(transformedLeads);
      }
      setNextPageToken(nextToken);
    } catch (err: any) {
      console.error('Error en búsqueda:', err);
      setErrorMessage(err.message || 'Error al conectar con la API de Google Places.');
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  };

  // Filtered results
  const filteredResults = useMemo(() => {
    return results.filter((lead) => {
      if (filterOnlyNoWeb && lead.websiteType === 'own_domain') {
        return false;
      }
      if (filterOnlyWithPhone && !lead.nationalPhoneNumber && !lead.internationalPhoneNumber) {
        return false;
      }
      if (filterMinRating > 0 && (lead.rating || 0) < filterMinRating) {
        return false;
      }
      if (filterMinReviews > 0 && (lead.userRatingCount || 0) < filterMinReviews) {
        return false;
      }
      if (filterHideClosed && lead.businessStatus !== 'OPERATIONAL') {
        return false;
      }
      return true;
    });
  }, [results, filterOnlyNoWeb, filterOnlyWithPhone, filterMinRating, filterMinReviews, filterHideClosed]);

  // Selection toggle
  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filteredResults.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredResults.map((r) => r.id)));
    }
  };

  // Batch Save
  const handleBatchSave = async () => {
    const toSave = filteredResults.filter((r) => selectedIds.has(r.id));
    for (const lead of toSave) {
      const updated = {
        ...lead,
        crm: {
          ...lead.crm,
          savedAt: lead.crm.savedAt || new Date().toISOString(),
        },
      };
      await saveLead(updated);
      onLeadSaved(updated);
    }
  };

  // Batch Analyze (max 2 concurrently)
  const handleBatchAnalyze = async () => {
    const selectedLeads = filteredResults.filter((r) => selectedIds.has(r.id));
    if (selectedLeads.length === 0) return;

    setBatchAnalyzing(true);
    setBatchProgress({ current: 0, total: selectedLeads.length });

    const updatedResults = [...results];

    // Worker pool for concurrency = 2
    let index = 0;
    const analyzeSingle = async (lead: BusinessLead) => {
      try {
        let pageSpeedAudit;
        // PageSpeed only if has own website
        if (lead.websiteUri && lead.websiteType === 'own_domain') {
          try {
            const psRes = await fetch('/api/pagespeed/analyze', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'x-google-cloud-key': settings.googleCloudApiKey || '',
              },
              body: JSON.stringify({
                url: lead.websiteUri,
                apiKey: settings.googleCloudApiKey,
              }),
            });
            if (psRes.ok) {
              const psData = await psRes.json();
              pageSpeedAudit = {
                analyzedAt: psData.analyzedAt,
                scores: psData.scores,
                screenshotBase64: psData.screenshotBase64,
                testedUrl: psData.testedUrl,
              };
            }
          } catch (e) {
            console.warn(`Error PageSpeed en ${lead.displayName}:`, e);
          }
        }

        // Gemini audit
        const geminiRes = await fetch('/api/gemini/analyze-business', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            businessName: lead.displayName,
            category: lead.primaryTypeDisplayName || lead.searchQueryNiche,
            address: lead.formattedAddress,
            phone: lead.nationalPhoneNumber || lead.internationalPhoneNumber,
            websiteUri: lead.websiteUri,
            hasOwnWebsite: lead.websiteType === 'own_domain',
            sellerProfile: settings.sellerProfile,
            pageSpeedScores: pageSpeedAudit?.scores,
            rating: lead.rating,
            reviewsCount: lead.userRatingCount,
          }),
        });

        let aiAudit;
        if (geminiRes.ok) {
          const geminiData = await geminiRes.json();
          aiAudit = geminiData.audit;
        }

        // Recalculate definitive score
        const scoreInfo = calculateOpportunityScore(lead, pageSpeedAudit, aiAudit);

        const updatedLead: BusinessLead = {
          ...lead,
          pageSpeedAudit,
          aiAudit,
          opportunityScore: scoreInfo.score,
          scoreBreakdown: scoreInfo.breakdown,
          isProvisionalScore: scoreInfo.isProvisional,
          crm: {
            ...lead.crm,
            status: lead.crm.status === 'nuevo' ? 'analizado' : lead.crm.status,
            savedAt: lead.crm.savedAt || new Date().toISOString(),
          },
        };

        await saveLead(updatedLead);
        onLeadSaved(updatedLead);

        const rIndex = updatedResults.findIndex((r) => r.id === lead.id);
        if (rIndex !== -1) {
          updatedResults[rIndex] = updatedLead;
        }
      } catch (err) {
        console.error(`Error analizando lead ${lead.id}:`, err);
      } finally {
        setBatchProgress((prev) =>
          prev ? { ...prev, current: prev.current + 1 } : null
        );
      }
    };

    // Run concurrency = 2
    const executing: Promise<void>[] = [];
    for (const lead of selectedLeads) {
      const p = analyzeSingle(lead).then(() => {
        executing.splice(executing.indexOf(p), 1);
      });
      executing.push(p);
      if (executing.length >= 2) {
        await Promise.race(executing);
      }
    }
    await Promise.all(executing);

    setResults(updatedResults);
    setBatchAnalyzing(false);
    setBatchProgress(null);
  };

  return (
    <div className="space-y-6">
      {/* Search Header and Inputs */}
      <div className="p-5 rounded-xl bg-neutral-900 border border-neutral-800 space-y-4 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-800/80 pb-3">
          <div>
            <h2 className="text-base font-semibold text-neutral-100 flex items-center gap-2">
              <Search className="w-4 h-4 text-emerald-400" />
              Búsqueda de Negocios Locales
            </h2>
            <p className="text-xs text-neutral-400 mt-0.5">
              Consulta Google Places API (New) para descubrir negocios, detectar si tienen web y medir su oportunidad.
            </p>
          </div>
          {results.length > 0 && (
            <div className="text-xs font-mono tabular-nums text-neutral-400">
              {filteredResults.length} de {results.length} resultados mostrados
            </div>
          )}
        </div>

        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="md:col-span-6 space-y-1">
            <label className="text-[11px] font-medium text-neutral-300">
              Zona (Ciudad, barrio o código postal)
            </label>
            <div className="relative">
              <MapPin className="w-4 h-4 text-neutral-500 absolute left-3 top-2.5" />
              <input
                type="text"
                value={zone}
                onChange={(e) => setZone(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="Ej. Dos Hermanas, Sevilla o Gràcia, Barcelona"
                className="w-full pl-9 pr-3 py-2 bg-neutral-950 border border-neutral-700 rounded-lg text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-emerald-500/80"
              />
            </div>
          </div>

          <div className="md:col-span-4 space-y-1">
            <label className="text-[11px] font-medium text-neutral-300">Nicho o Categoría</label>
            <input
              type="text"
              value={niche}
              onChange={(e) => setNiche(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              placeholder="Ej. talleres mecánicos, clínicas dentales..."
              className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-lg text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-emerald-500/80"
            />
          </div>

          <div className="md:col-span-2 flex items-end">
            <button
              onClick={() => handleSearch()}
              disabled={loading}
              className="w-full py-2 px-4 bg-emerald-500 hover:bg-emerald-600 disabled:bg-neutral-800 disabled:text-neutral-500 text-neutral-950 font-semibold rounded-lg text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-sm"
            >
              {loading ? (
                <>
                  <RotateCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Buscando...</span>
                </>
              ) : (
                <>
                  <Search className="w-3.5 h-3.5" />
                  <span>Buscar</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Suggested Quick Niches */}
        <div className="space-y-1.5 pt-1">
          <div className="text-[11px] text-neutral-400">Sugerencias rápidas:</div>
          <div className="flex flex-wrap gap-1.5">
            {DEFAULT_NICHES.map((n) => (
              <button
                key={n}
                onClick={() => setNiche(n)}
                className={`text-[11px] px-2.5 py-1 rounded border transition-colors ${
                  niche.toLowerCase() === n.toLowerCase()
                    ? 'bg-neutral-800 text-emerald-300 border-emerald-500/40'
                    : 'bg-neutral-950 text-neutral-400 border-neutral-800 hover:border-neutral-700 hover:text-neutral-200'
                }`}
              >
                {n}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Error Banner */}
      {errorMessage && (
        <div className="p-3.5 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
          <div className="flex-1">
            <span className="font-semibold">Aviso del sistema: </span>
            {errorMessage}
          </div>
        </div>
      )}

      {/* Filter Toolbar */}
      {results.length > 0 && (
        <div className="p-3.5 rounded-xl bg-neutral-900 border border-neutral-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Quick Filters */}
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-neutral-500 flex items-center gap-1 font-medium text-[11px]">
              <SlidersHorizontal className="w-3.5 h-3.5" />
              Filtros:
            </span>

            {/* Solo sin web propia */}
            <label className="flex items-center gap-1.5 cursor-pointer select-none text-neutral-300 hover:text-neutral-100">
              <input
                type="checkbox"
                checked={filterOnlyNoWeb}
                onChange={(e) => setFilterOnlyNoWeb(e.target.checked)}
                className="rounded bg-neutral-950 border-neutral-700 text-emerald-500 focus:ring-0"
              />
              <span>Solo sin web propia</span>
            </label>

            {/* Solo con teléfono */}
            <label className="flex items-center gap-1.5 cursor-pointer select-none text-neutral-300 hover:text-neutral-100">
              <input
                type="checkbox"
                checked={filterOnlyWithPhone}
                onChange={(e) => setFilterOnlyWithPhone(e.target.checked)}
                className="rounded bg-neutral-950 border-neutral-700 text-emerald-500 focus:ring-0"
              />
              <span>Solo con teléfono</span>
            </label>

            {/* Min Rating */}
            <div className="flex items-center gap-1 text-neutral-400">
              <span>Nota min:</span>
              <select
                value={filterMinRating}
                onChange={(e) => setFilterMinRating(Number(e.target.value))}
                className="bg-neutral-950 border border-neutral-800 rounded px-2 py-1 text-xs text-neutral-200 focus:outline-none"
              >
                <option value={0}>Todas</option>
                <option value={3.5}>≥ 3.5 ★</option>
                <option value={4.0}>≥ 4.0 ★</option>
                <option value={4.5}>≥ 4.5 ★</option>
              </select>
            </div>

            {/* Min Reviews */}
            <div className="flex items-center gap-1 text-neutral-400">
              <span>Reseñas min:</span>
              <select
                value={filterMinReviews}
                onChange={(e) => setFilterMinReviews(Number(e.target.value))}
                className="bg-neutral-950 border border-neutral-800 rounded px-2 py-1 text-xs text-neutral-200 focus:outline-none"
              >
                <option value={0}>Todas</option>
                <option value={5}>≥ 5</option>
                <option value={15}>≥ 15</option>
                <option value={30}>≥ 30</option>
              </select>
            </div>

            {/* Hide closed */}
            <label className="flex items-center gap-1.5 cursor-pointer select-none text-neutral-300 hover:text-neutral-100">
              <input
                type="checkbox"
                checked={filterHideClosed}
                onChange={(e) => setFilterHideClosed(e.target.checked)}
                className="rounded bg-neutral-950 border-neutral-700 text-emerald-500 focus:ring-0"
              />
              <span>Ocultar cerrados</span>
            </label>
          </div>

          {/* View mode toggle */}
          <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-lg border border-neutral-800">
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded text-xs transition-colors ${
                viewMode === 'table'
                  ? 'bg-neutral-800 text-emerald-400'
                  : 'text-neutral-500 hover:text-neutral-300'
              }`}
              title="Vista en tabla densa"
            >
              <TableIcon className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setViewMode('cards')}
              className={`p-1.5 rounded text-xs transition-colors ${
                viewMode === 'cards'
                  ? 'bg-neutral-800 text-emerald-400'
                  : 'text-neutral-500 hover:text-neutral-300'
              }`}
              title="Vista en tarjetas"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Batch Action Bar */}
      {selectedIds.size > 0 && (
        <div className="p-3 rounded-lg bg-neutral-800/90 border border-neutral-700 flex flex-wrap items-center justify-between gap-3 text-xs animate-in fade-in duration-150">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-emerald-400 font-mono tabular-nums">
              {selectedIds.size} seleccionados
            </span>
            <span className="text-neutral-400">de {filteredResults.length}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleBatchSave}
              className="px-3 py-1.5 bg-neutral-900 hover:bg-neutral-950 border border-neutral-700 text-neutral-200 rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <Save className="w-3.5 h-3.5 text-emerald-400" />
              <span>Guardar en mis leads</span>
            </button>

            <button
              onClick={handleBatchAnalyze}
              disabled={batchAnalyzing}
              className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 disabled:bg-neutral-700 disabled:text-neutral-400 text-neutral-950 font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {batchAnalyzing ? (
                <>
                  <RotateCw className="w-3.5 h-3.5 animate-spin" />
                  <span>
                    Analizando ({batchProgress?.current}/{batchProgress?.total})...
                  </span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5" />
                  <span>Analizar seleccionados (concurrencia máx. 2)</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Results View */}
      {filteredResults.length > 0 ? (
        viewMode === 'table' ? (
          <div className="overflow-x-auto rounded-xl border border-neutral-800 bg-neutral-900 shadow-sm">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-neutral-800 text-[11px] uppercase tracking-wider text-neutral-400 bg-neutral-950/60 select-none">
                  <th className="py-3 px-3 w-10 text-center">
                    <button onClick={toggleSelectAll} className="text-neutral-400 hover:text-neutral-200">
                      {selectedIds.size === filteredResults.length && filteredResults.length > 0 ? (
                        <CheckSquare className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Square className="w-4 h-4" />
                      )}
                    </button>
                  </th>
                  <th className="py-3 px-3 font-semibold text-neutral-300">Negocio</th>
                  <th className="py-3 px-3 font-semibold text-neutral-300">Contacto</th>
                  <th className="py-3 px-3 font-semibold text-neutral-300">Presencia Web</th>
                  <th className="py-3 px-3 font-semibold text-neutral-300 text-right">Reputación</th>
                  <th className="py-3 px-3 font-semibold text-neutral-300 text-center">Oportunidad</th>
                  <th className="py-3 px-3 font-semibold text-neutral-300 text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/80">
                {filteredResults.map((lead) => {
                  const isSelected = selectedIds.has(lead.id);
                  const isSaved = savedLeadIds.has(lead.id);

                  return (
                    <tr
                      key={lead.id}
                      className={`hover:bg-neutral-800/40 transition-colors ${
                        isSelected ? 'bg-neutral-800/30' : ''
                      }`}
                    >
                      {/* Checkbox */}
                      <td className="py-3 px-3 text-center">
                        <button
                          onClick={() => toggleSelect(lead.id)}
                          className="text-neutral-500 hover:text-neutral-200"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-emerald-400" />
                          ) : (
                            <Square className="w-4 h-4" />
                          )}
                        </button>
                      </td>

                      {/* Negocio */}
                      <td className="py-3 px-3">
                        <div className="font-medium text-neutral-100 flex items-center gap-1.5">
                          <button
                            onClick={() => onSelectLead(lead)}
                            className="hover:text-emerald-400 text-left font-semibold truncate max-w-xs transition-colors"
                          >
                            {lead.displayName}
                          </button>
                          {lead.businessStatus !== 'OPERATIONAL' && (
                            <span className="text-[10px] px-1 rounded bg-rose-500/20 text-rose-300">
                              Cerrado
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-neutral-400 truncate max-w-xs flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3 text-neutral-500 shrink-0" />
                          <span>{lead.formattedAddress}</span>
                        </div>
                        {lead.primaryTypeDisplayName && (
                          <div className="text-[10px] text-neutral-500 mt-0.5">
                            {lead.primaryTypeDisplayName}
                          </div>
                        )}
                      </td>

                      {/* Contacto */}
                      <td className="py-3 px-3">
                        {lead.nationalPhoneNumber ? (
                          <div className="space-y-1">
                            <a
                              href={`tel:${lead.nationalPhoneNumber}`}
                              className="inline-flex items-center gap-1 text-emerald-400 hover:text-emerald-300 font-mono tabular-nums"
                            >
                              <Phone className="w-3 h-3" />
                              <span>{lead.nationalPhoneNumber}</span>
                            </a>
                            <div>
                              <button
                                onClick={() => setActiveWhatsAppLead(lead)}
                                className="px-2 py-0.5 rounded bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30 text-[10px] font-medium inline-flex items-center gap-1 cursor-pointer"
                                title="Escribir mensaje personalizado por WhatsApp"
                              >
                                <MessageSquare className="w-2.5 h-2.5" />
                                <span>WhatsApp</span>
                              </button>
                            </div>
                          </div>
                        ) : (
                          <span className="text-neutral-500 italic text-[11px]">Sin teléfono</span>
                        )}
                        <div className="mt-1">
                          <a
                            href={lead.googleMapsUri}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[11px] text-neutral-400 hover:text-neutral-200 inline-flex items-center gap-1"
                          >
                            <span>Ficha Google Maps</span>
                            <ExternalLink className="w-2.5 h-2.5" />
                          </a>
                        </div>
                      </td>

                      {/* Web */}
                      <td className="py-3 px-3">
                        {lead.websiteType === 'own_domain' ? (
                          <a
                            href={lead.websiteUri}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-neutral-200 hover:text-emerald-300 inline-flex items-center gap-1 max-w-[180px] truncate"
                          >
                            <Globe className="w-3 h-3 text-neutral-400 shrink-0" />
                            <span className="truncate">{lead.websiteUri?.replace(/^https?:\/\/(www\.)?/, '')}</span>
                          </a>
                        ) : lead.websiteType === 'social_or_directory' ? (
                          <div className="space-y-0.5">
                            <span className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-medium">
                              Sin web propia ({lead.socialOrDirectoryName || 'Red social'})
                            </span>
                            {lead.websiteUri && (
                              <div>
                                <a
                                  href={lead.websiteUri}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-[10px] text-neutral-400 hover:text-neutral-200 inline-flex items-center gap-1"
                                >
                                  <span>Abrir enlace</span>
                                  <ExternalLink className="w-2.5 h-2.5" />
                                </a>
                              </div>
                            )}
                          </div>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/20 font-medium">
                            Sin página web
                          </span>
                        )}
                      </td>

                      {/* Reputación */}
                      <td className="py-3 px-3 text-right">
                        {lead.rating ? (
                          <div className="font-mono tabular-nums">
                            <div className="inline-flex items-center gap-1 text-amber-400 font-semibold">
                              <Star className="w-3 h-3 fill-amber-400" />
                              <span>{lead.rating.toFixed(1)}</span>
                            </div>
                            <div className="text-[10px] text-neutral-400">
                              {lead.userRatingCount || 0} reseñas
                            </div>
                          </div>
                        ) : (
                          <span className="text-neutral-500 text-[11px]">Sin reseñas</span>
                        )}
                      </td>

                      {/* Oportunidad */}
                      <td className="py-3 px-3 text-center">
                        <ScoreBadge
                          score={lead.opportunityScore}
                          isProvisional={lead.isProvisionalScore}
                          breakdown={lead.scoreBreakdown}
                          size="sm"
                        />
                      </td>

                      {/* Acciones */}
                      <td className="py-3 px-3 text-right space-x-1.5 whitespace-nowrap">
                        <button
                          onClick={() => {
                            const updated = {
                              ...lead,
                              crm: {
                                ...lead.crm,
                                savedAt: lead.crm.savedAt || new Date().toISOString(),
                              },
                            };
                            saveLead(updated);
                            onLeadSaved(updated);
                          }}
                          className={`p-1.5 rounded-lg border transition-colors ${
                            isSaved
                              ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                              : 'bg-neutral-800 text-neutral-300 border-neutral-700 hover:text-neutral-100 hover:bg-neutral-700'
                          }`}
                          title={isSaved ? 'Guardado en Mis Leads' : 'Guardar lead'}
                        >
                          {isSaved ? <Check className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
                        </button>

                        <button
                          onClick={() => onSelectLead(lead)}
                          className="px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-emerald-500 hover:text-neutral-950 text-neutral-200 border border-neutral-700 font-medium text-xs transition-colors inline-flex items-center gap-1"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Ver Ficha</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          /* Cards View */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredResults.map((lead) => {
              const isSelected = selectedIds.has(lead.id);
              const isSaved = savedLeadIds.has(lead.id);

              return (
                <div
                  key={lead.id}
                  className={`p-4 rounded-xl border transition-all flex flex-col justify-between space-y-3 bg-neutral-900 ${
                    isSelected
                      ? 'border-emerald-500/60 ring-1 ring-emerald-500/30'
                      : 'border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-2">
                        <button
                          onClick={() => toggleSelect(lead.id)}
                          className="mt-0.5 text-neutral-500 hover:text-neutral-200"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-emerald-400" />
                          ) : (
                            <Square className="w-4 h-4" />
                          )}
                        </button>
                        <div>
                          <button
                            onClick={() => onSelectLead(lead)}
                            className="font-semibold text-neutral-100 hover:text-emerald-400 text-left line-clamp-1 transition-colors"
                          >
                            {lead.displayName}
                          </button>
                          <div className="text-[11px] text-neutral-400 line-clamp-1 flex items-center gap-1 mt-0.5">
                            <MapPin className="w-3 h-3 text-neutral-500 shrink-0" />
                            <span>{lead.formattedAddress}</span>
                          </div>
                        </div>
                      </div>

                      <ScoreBadge
                        score={lead.opportunityScore}
                        isProvisional={lead.isProvisionalScore}
                        size="sm"
                      />
                    </div>

                    {/* Web status badge */}
                    <div className="pt-1">
                      {lead.websiteType === 'own_domain' ? (
                        <a
                          href={lead.websiteUri}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[11px] text-neutral-300 hover:text-emerald-300 inline-flex items-center gap-1 truncate max-w-full"
                        >
                          <Globe className="w-3 h-3 text-neutral-400" />
                          <span className="truncate">{lead.websiteUri?.replace(/^https?:\/\/(www\.)?/, '')}</span>
                        </a>
                      ) : lead.websiteType === 'social_or_directory' ? (
                        <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-medium">
                          Sin web propia ({lead.socialOrDirectoryName})
                        </span>
                      ) : (
                        <span className="text-[10px] px-2 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/20 font-medium">
                          Sin página web
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Bottom details */}
                  <div className="pt-2 border-t border-neutral-800 flex items-center justify-between text-xs">
                    <div className="flex flex-wrap items-center gap-2">
                      {lead.nationalPhoneNumber ? (
                        <>
                          <a
                            href={`tel:${lead.nationalPhoneNumber}`}
                            className="text-emerald-400 hover:text-emerald-300 font-mono text-[11px] flex items-center gap-1"
                          >
                            <Phone className="w-3 h-3" />
                            <span>{lead.nationalPhoneNumber}</span>
                          </a>

                          <button
                            onClick={() => setActiveWhatsAppLead(lead)}
                            className="px-2 py-0.5 rounded bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30 text-[10px] font-medium flex items-center gap-1 cursor-pointer"
                            title="Escribir mensaje personalizado por WhatsApp"
                          >
                            <MessageSquare className="w-2.5 h-2.5" />
                            <span>WhatsApp</span>
                          </button>
                        </>
                      ) : (
                        <span className="text-neutral-500 text-[11px] italic">Sin teléfono</span>
                      )}

                      {lead.rating && (
                        <div className="flex items-center gap-1 text-[11px] text-amber-400 font-mono">
                          <Star className="w-3 h-3 fill-amber-400" />
                          <span>{lead.rating.toFixed(1)}</span>
                          <span className="text-neutral-500">({lead.userRatingCount})</span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => {
                          const updated = {
                            ...lead,
                            crm: {
                              ...lead.crm,
                              savedAt: lead.crm.savedAt || new Date().toISOString(),
                            },
                          };
                          saveLead(updated);
                          onLeadSaved(updated);
                        }}
                        className={`p-1.5 rounded-lg border transition-colors ${
                          isSaved
                            ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                            : 'bg-neutral-800 text-neutral-300 border-neutral-700 hover:bg-neutral-700'
                        }`}
                        title={isSaved ? 'Guardado' : 'Guardar lead'}
                      >
                        {isSaved ? <Check className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
                      </button>

                      <button
                        onClick={() => onSelectLead(lead)}
                        className="px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-emerald-500 hover:text-neutral-950 text-neutral-200 border border-neutral-700 font-medium text-xs transition-colors"
                      >
                        Ficha
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )
      ) : results.length > 0 ? (
        <div className="p-12 text-center rounded-xl bg-neutral-900 border border-neutral-800 space-y-2">
          <Filter className="w-8 h-8 text-neutral-500 mx-auto" />
          <h3 className="font-semibold text-sm text-neutral-200">
            Ningún resultado coincide con los filtros activos
          </h3>
          <p className="text-xs text-neutral-400 max-w-sm mx-auto">
            Prueba a desactivar filtros como «Solo sin web propia» o bajar la valoración mínima.
          </p>
        </div>
      ) : (
        <div className="p-16 text-center rounded-xl bg-neutral-900 border border-neutral-800 space-y-3">
          <div className="w-12 h-12 rounded-xl bg-neutral-800 border border-neutral-700 flex items-center justify-center mx-auto text-emerald-400">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="font-semibold text-neutral-100 text-sm">
            Encuentra negocios locales listos para ser contactados
          </h3>
          <p className="text-xs text-neutral-400 max-w-md mx-auto">
            Introduce la localidad que quieras prospectar (ej. «Dos Hermanas, Sevilla») y el nicho de mercado.
            Radar de Clientes evaluará instantáneamente la presencia digital de cada negocio.
          </p>
        </div>
      )}

      {/* Cargar más botón (pageToken) */}
      {nextPageToken && filteredResults.length > 0 && (
        <div className="text-center pt-2 pb-6">
          <button
            onClick={() => handleSearch(nextPageToken)}
            disabled={loadingMore}
            className="px-5 py-2.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 text-xs font-semibold text-neutral-200 hover:text-emerald-300 transition-colors inline-flex items-center gap-2 cursor-pointer shadow-sm"
          >
            {loadingMore ? (
              <>
                <RotateCw className="w-3.5 h-3.5 animate-spin text-emerald-400" />
                <span>Cargando más negocios de Google Places...</span>
              </>
            ) : (
              <>
                <span>Cargar más resultados</span>
                <span className="font-mono text-[10px] text-neutral-400">(hasta 60 máx.)</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* WhatsApp Modal */}
      {activeWhatsAppLead && (
        <WhatsAppModal
          lead={activeWhatsAppLead}
          isOpen={Boolean(activeWhatsAppLead)}
          onClose={() => setActiveWhatsAppLead(null)}
          sellerName={settings.sellerProfile.name}
          onMessageSent={(markContacted) => {
            if (markContacted && activeWhatsAppLead) {
              const updated = {
                ...activeWhatsAppLead,
                crm: {
                  ...activeWhatsAppLead.crm,
                  status: 'contactado' as const,
                  savedAt: activeWhatsAppLead.crm.savedAt || new Date().toISOString(),
                },
              };
              saveLead(updated);
              onLeadSaved(updated);
            }
          }}
        />
      )}
    </div>
  );
};
