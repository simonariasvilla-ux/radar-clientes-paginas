# Radar de Clientes

Aplicación web profesional de prospección comercial para consultores y agencias de servicios digitales (páginas web, agentes de IA por WhatsApp y sistemas de reservas) orientada a negocios locales en España.

Integraciones principales:
- **Google Places API (New)** con `places:searchText`, paginación con `nextPageToken` y filtros optimizados.
- **Google PageSpeed Insights v5** móvil con extracción de notas y captura de pantalla (`final-screenshot`).
- **Gemini 3.8 Flash** con `urlContext` para lectura de páginas web, checklist técnico, detección de problemas y generación de 3 borradores comerciales (guion de 30s, WhatsApp y correo).
- **Almacenamiento local en IndexedDB** con soporte de capturas, embudo Kanban de 7 fases, buscador, exportación a CSV y botón directo de WhatsApp.

---

## Solución al error «Page Not Found» (404) en Vercel

Si subiste el proyecto a GitHub y en Vercel te aparece **«404: NOT_FOUND»** o **«Page Not Found»**, ocurre por una de estas dos razones comunes:

### Causa 1: Subiste el archivo .ZIP directamente a GitHub (o los archivos están dentro de una subcarpeta)
1. **Si subiste el archivo `.zip` suelto a GitHub**: GitHub no descomprime los archivos ZIP automáticamente. Vercel busca el archivo `package.json` en la raíz del repositorio; si solo ve el `.zip`, no compila nada y da 404.
   - **Solución:** Descomprime el archivo `.zip` en tu ordenador.
2. **Si los archivos quedaron dentro de una subcarpeta** (ejemplo: `mi-repo/radar-de-clientes/package.json`):
   - **Solución rápida en Vercel:** Entra en tu proyecto en Vercel > pestaña **Settings** > **General** > busca **Root Directory** > pulsa **Edit** > escribe `radar-de-clientes` (el nombre de la subcarpeta) y pulsa **Save**. Luego ve a la pestaña **Deployments** y pulsa **Redeploy**.
   - **Solución en GitHub:** Asegúrate de que `package.json`, `index.html`, `vite.config.ts`, `src/` y `api/` estén en la raíz principal de tu repositorio, no dentro de otra carpeta.

### Causa 2: Configuración de rutas (ya corregida en este archivo `vercel.json`)
El archivo `vercel.json` ya incluye la regla de enrutamiento SPA:
```json
{
  "rewrites": [
    {
      "source": "/api/(.*)",
      "destination": "/api"
    },
    {
      "source": "/((?!api/).*)",
      "destination": "/index.html"
    }
  ]
}
```
Esto redirige todas las rutas visuales a `index.html` (evitando el 404 de Vite) y las llamadas a `/api/*` a la función serverless de Express.

---

## Despliegue en Vercel Paso a Paso

### Paso 1: Descargar y descomprimir el proyecto
- Puedes descargar el archivo ZIP del proyecto con el botón en la cabecera de la app o directamente desde `/radar-de-clientes.zip`.
- Descomprime el `.zip` en una carpeta en tu ordenador.

### Paso 2: Subir a GitHub
Asegúrate de que los archivos estén en la **raíz** del repositorio:
```
mi-repositorio-github/
├── package.json      <-- Debe estar en la raíz
├── index.html        <-- Debe estar en la raíz
├── vercel.json
├── vite.config.ts
├── api/
│   └── index.ts
└── src/
    ├── App.tsx
    └── ...
```

### Paso 3: Conectar a Vercel
1. Ve a [Vercel](https://vercel.com) e inicia sesión.
2. Pulsa **«Add New...» > «Project»**.
3. Importa tu repositorio de GitHub.
4. En **Framework Preset**, Vercel detectará automáticamente **Vite**.
5. Despliega **Environment Variables** y añade:
   - `GEMINI_API_KEY`: Tu clave de Gemini (obtenida gratis en Google AI Studio).
   - *(Opcional)* `GOOGLE_CLOUD_API_KEY`: Tu clave de Google Cloud con Places API y PageSpeed activadas. Si prefieres, no hace falta ponerla aquí; puedes introducirla en la app desde el menú **Ajustes** y se guardará en tu navegador.
6. Pulsa **«Deploy»**.
7. En menos de 1 minuto tendrás tu enlace activo funcionando sin errores 404.

---

## Ejecución en Local

1. Instalar dependencias:
   ```bash
   npm install
   ```
2. Crear archivo `.env` basándote en `.env.example`:
   ```bash
   GEMINI_API_KEY="tu_clave_de_gemini"
   GOOGLE_CLOUD_API_KEY="tu_clave_de_google_cloud" # opcional si la pones en Ajustes
   ```
3. Iniciar el servidor de desarrollo:
   ```bash
   npm run dev
   ```
4. Abre [http://localhost:3000](http://localhost:3000) en tu navegador.

---

## Estructura del Proyecto

```
├── api/
│   └── index.ts               # Router Express para funciones serverless de Vercel
├── src/
│   ├── components/            # Sidebar, Header, ScoreBadge, PageSpeedGauges, WhatsAppModal
│   ├── services/              # storage.ts (IndexedDB), scoring.ts (Algoritmo 0-100)
│   ├── utils/                 # whatsapp.ts (limpieza de teléfonos y plantillas)
│   ├── views/                 # SearchView, BusinessDetailView, NicheRadarView, MyLeadsView, SettingsView
│   ├── types/                 # Definiciones TypeScript completas
│   ├── App.tsx                # Orquestador de vistas y estado
│   ├── main.tsx               # Entry point de React
│   └── index.css              # Tailwind CSS y reglas de impresión
├── vercel.json                # Configuración de despliegue para Vercel
├── vite.config.ts             # Configuración de Vite y Tailwind
├── server.ts                  # Servidor Express local
└── package.json
```
